@echo off
chcp 65001 >nul
setlocal EnableExtensions

echo ========================================
echo   热血传奇 - 停止服务器
echo ========================================
echo.

echo [INFO] 正在停止所有 Node.js 进程...
echo.

taskkill /F /IM node.exe >nul 2>&1

if errorlevel 1 (
    echo [WARNING] 未找到运行中的 Node.js 进程
) else (
    echo [SUCCESS] 已成功停止服务器
)

echo.
echo 按任意键退出...
pause >nul
exit /b 0
