const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const APP_VERSION = "0.5.5"; // 同步 Backend/package.json 版本号
window.APP_VERSION = APP_VERSION;
$("#app-version") && ($("#app-version").textContent = `Ver ${APP_VERSION}`);

let state = null;
let currentTab = "map";
let logFilter = "all";
let ticking = false;
let displayLogClearedAt = 0;
let lastFrameId = null;
let lastBattleMapId = null;
let lastHudMapId = null;
let lastNotifiedLogId = null;
let didInitNotifyCursor = false;
let CELL = 128;
let hintMessages = [];

const LS_SFX_ENABLED = "setting_sfx_enabled";
function readLocalBool(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    if (v == null) return !!fallback;
    return v === "1" || v === "true";
  } catch {
    return !!fallback;
  }
}

function writeLocalBool(key, value) {
  try {
    localStorage.setItem(key, value ? "1" : "0");
  } catch {}
}

function isSfxEnabled() {
  return readLocalBool(LS_SFX_ENABLED, true);
}

let audioCtx = null;
let slashNoiseBuf = null;

// 音效缓存
const sfxCache = {};

function ensureAudioCtx() {
  if (audioCtx) return audioCtx;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  audioCtx = new Ctx();
  return audioCtx;
}

function ensureAudioRunning() {
  const ctx = ensureAudioCtx();
  if (!ctx) return;
  if (ctx.state === "suspended") {
    ctx.resume().catch(() => {});
  }
}

function getSlashNoiseBuffer(ctx) {
  if (slashNoiseBuf) return slashNoiseBuf;
  const dur = 0.14;
  const sr = ctx.sampleRate || 48000;
  const len = Math.max(1, Math.floor(sr * dur));
  const buf = ctx.createBuffer(1, len, sr);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i += 1) {
    const t = i / len;
    const env = (1 - t) * (1 - t);
    data[i] = (Math.random() * 2 - 1) * env;
  }
  slashNoiseBuf = buf;
  return buf;
}

function playSlashSfx() {
  if (!isSfxEnabled()) return;
  const ctx = ensureAudioCtx();
  if (!ctx || ctx.state !== "running") return;
  const t0 = ctx.currentTime;
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.linearRampToValueAtTime(0.2, t0 + 0.01);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.14);
  master.connect(ctx.destination);

  const osc = ctx.createOscillator();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(220, t0);
  osc.frequency.exponentialRampToValueAtTime(120, t0 + 0.14);
  osc.connect(master);
  osc.start(t0);
  osc.stop(t0 + 0.14);

  const noise = ctx.createBufferSource();
  noise.buffer = getSlashNoiseBuffer(ctx);
  const filter = ctx.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.setValueAtTime(1200, t0);
  filter.Q.setValueAtTime(0.8, t0);
  const ng = ctx.createGain();
  ng.gain.setValueAtTime(0.0001, t0);
  ng.gain.linearRampToValueAtTime(0.12, t0 + 0.008);
  ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.14);
  noise.connect(filter);
  filter.connect(ng);
  ng.connect(master);
  noise.start(t0);
  noise.stop(t0 + 0.14);
}

// 播放职业音效
function playClassSkillSfx(job, skillId, isRanged = false) {
  if (!isSfxEnabled()) return;
  const ctx = ensureAudioCtx();
  if (!ctx) return;
  
  // 确保 AudioContext 是运行状态（解决需要点击才能发声的问题）
  if (ctx.state === "suspended") {
    ctx.resume().catch(() => {});
  }
  
  // 根据职业和技能类型播放不同音效
  const t0 = ctx.currentTime;
  
  if (job === "warrior") {
    // 战士：近战物理攻击
    playWarriorAttack(ctx, t0, skillId);
  } else if (job === "mage") {
    // 法师：魔法攻击
    playMageAttack(ctx, t0, skillId, isRanged);
  } else if (job === "taoist") {
    // 道士：道术攻击
    playTaoistAttack(ctx, t0, skillId, isRanged);
  } else {
    // 默认音效
    playDefaultAttack(ctx, t0);
  }
}

// 战士攻击音效（剑击、烈火等）- 模拟真实的刀剑挥舞声
function playWarriorAttack(ctx, t0, skillId) {
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.linearRampToValueAtTime(0.35, t0 + 0.02);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.35);
  master.connect(ctx.destination);

  // 低频刀风：模拟刀剑划破空气的低沉声音
  const osc1 = ctx.createOscillator();
  osc1.type = "triangle";
  osc1.frequency.setValueAtTime(120, t0);
  osc1.frequency.exponentialRampToValueAtTime(60, t0 + 0.15);
  const osc1Gain = ctx.createGain();
  osc1Gain.gain.setValueAtTime(0.0001, t0);
  osc1Gain.gain.linearRampToValueAtTime(0.25, t0 + 0.02);
  osc1Gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.2);
  osc1.connect(osc1Gain);
  osc1Gain.connect(master);
  osc1.start(t0);
  osc1.stop(t0 + 0.2);

  // 高频金属声：模拟刀刃的锋利金属质感
  const osc2 = ctx.createOscillator();
  osc2.type = "triangle";
  osc2.frequency.setValueAtTime(800, t0);
  osc2.frequency.exponentialRampToValueAtTime(1200, t0 + 0.05);
  osc2.frequency.exponentialRampToValueAtTime(400, t0 + 0.25);
  const osc2Gain = ctx.createGain();
  osc2Gain.gain.setValueAtTime(0.0001, t0);
  osc2Gain.gain.linearRampToValueAtTime(0.18, t0 + 0.03);
  osc2Gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.3);
  osc2.connect(osc2Gain);
  osc2Gain.connect(master);
  osc2.start(t0);
  osc2.stop(t0 + 0.3);

  // 噪声层：模拟刀剑破空的嘶嘶声
  const noise = ctx.createBufferSource();
  noise.buffer = getSlashNoiseBuffer(ctx);
  const filter = ctx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.setValueAtTime(1500, t0);
  filter.Q.setValueAtTime(0.8, t0);
  const ng = ctx.createGain();
  ng.gain.setValueAtTime(0.0001, t0);
  ng.gain.linearRampToValueAtTime(0.15, t0 + 0.02);
  ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.25);
  noise.connect(filter);
  filter.connect(ng);
  ng.connect(master);
  noise.start(t0);
  noise.stop(t0 + 0.25);
}

// 法师攻击音效（火球、雷电等）
function playMageAttack(ctx, t0, skillId, isRanged) {
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.linearRampToValueAtTime(0.3, t0 + 0.03);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.35);
  master.connect(ctx.destination);

  if (isRanged || skillId === "fireball") {
    // 火球术：燃烧声
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(300, t0);
    osc.frequency.linearRampToValueAtTime(600, t0 + 0.15);
    osc.frequency.linearRampToValueAtTime(200, t0 + 0.35);
    osc.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.35);
  } else if (skillId === "thunder") {
    // 雷电术：电流声
    const osc = ctx.createOscillator();
    osc.type = "square";
    osc.frequency.setValueAtTime(800, t0);
    osc.frequency.exponentialRampToValueAtTime(200, t0 + 0.3);
    osc.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  } else {
    // 默认魔法音
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(400, t0);
    osc.frequency.linearRampToValueAtTime(800, t0 + 0.2);
    osc.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  }
}

// 道士攻击音效（灵魂火符、施毒等）
function playTaoistAttack(ctx, t0, skillId, isRanged) {
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.linearRampToValueAtTime(0.28, t0 + 0.03);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.3);
  master.connect(ctx.destination);

  if (isRanged || skillId === "soul_fire") {
    // 灵魂火符：火焰 + 纸张飘动声
    const osc = ctx.createOscillator();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(350, t0);
    osc.frequency.linearRampToValueAtTime(500, t0 + 0.15);
    osc.frequency.linearRampToValueAtTime(250, t0 + 0.3);
    osc.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  } else if (skillId === "poison") {
    // 施毒术：液体飞溅声
    const noise = ctx.createBufferSource();
    noise.buffer = getSlashNoiseBuffer(ctx);
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(600, t0);
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.0001, t0);
    ng.gain.linearRampToValueAtTime(0.15, t0 + 0.02);
    ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.25);
    noise.connect(filter);
    filter.connect(ng);
    ng.connect(master);
    noise.start(t0);
    noise.stop(t0 + 0.25);
  } else {
    // 默认道术音
    const osc = ctx.createOscillator();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(300, t0);
    osc.frequency.linearRampToValueAtTime(450, t0 + 0.2);
    osc.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  }
}

// 默认攻击音效
function playDefaultAttack(ctx, t0) {
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.linearRampToValueAtTime(0.2, t0 + 0.02);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.2);
  master.connect(ctx.destination);

  const osc = ctx.createOscillator();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(220, t0);
  osc.frequency.exponentialRampToValueAtTime(120, t0 + 0.2);
  osc.connect(master);
  osc.start(t0);
  osc.stop(t0 + 0.2);
}

function ensureToastEl() {
  let el = document.querySelector("#toast");
  if (el) return el;
  el = document.createElement("div");
  el.id = "toast";
  el.className = "toast";
  document.body.appendChild(el);
  return el;
}

function showToast(msg) {
  hintMessages.push(String(msg));
  if (hintMessages.length > 50) hintMessages = hintMessages.slice(-50);
  renderRightLogs();
}

function maybeNotifyDrops() {
  const logs = state?.logs ?? [];
  if (logs.length <= 0) return;
  if (!didInitNotifyCursor) {
    lastNotifiedLogId = logs[logs.length - 1]?.id ?? null;
    didInitNotifyCursor = true;
    return;
  }
  let startIdx = -1;
  if (lastNotifiedLogId) {
    startIdx = logs.findIndex((l) => l.id === lastNotifiedLogId);
  }
  const slice = startIdx >= 0 ? logs.slice(startIdx + 1) : logs;
  for (const l of slice) {
    if (l.type !== "loot") continue;
    const text = String(l.text ?? "");
    if (text.includes("掉落")) {
      showToast(text);
    }
  }
  lastNotifiedLogId = logs[logs.length - 1]?.id ?? lastNotifiedLogId;
}

function fmtTime(ts) {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

async function api(path, { method = "GET", body } = {}) {
  const token = localStorage.getItem("authToken") || sessionStorage.getItem("authToken");
  const res = await fetch(path, {
    method,
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { "X-Auth": token } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.ok) {
    const err = data?.error || `请求失败：${res.status}`;
    throw new Error(err);
  }
  return data.data;
}

function showCreateModal(show) {
  const el = $("#modal-create");
  if (!el) return;
  el.classList.toggle("hidden", !show);
  $("#create-hint").textContent = "";
  
  const roles = state?.roles ?? [];
  const currentPlayer = state?.player;
  const sectionRoleList = $("#section-role-list");
  const roleListContainer = $("#role-list-container");
  const sectionCreate = $("#section-create");
  
  if (roles.length > 0) {
    sectionRoleList?.classList.remove("hidden");
    if (roleListContainer) {
      roleListContainer.innerHTML = roles.map(r => {
        const isActive = currentPlayer && r.id === currentPlayer.id;
        return `
          <div class="role-item card ${isActive ? 'active' : ''}" style="display: flex; justify-content: space-between; align-items: center; padding: 10px; margin-bottom: 5px; border: 1px solid ${isActive ? 'var(--primary)' : 'var(--border)'}; background: ${isActive ? 'rgba(var(--primary-rgb), 0.1)' : 'transparent'}">
            <div style="cursor: pointer; flex: 1;" data-action="select-role" data-player-id="${escapeAttr(r.id)}">
              <div style="font-weight: bold;">${escapeHtml(r.name)} ${isActive ? '<span class="badge" style="font-size: 0.7em;">当前</span>' : ''}</div>
              <div class="muted" style="font-size: 0.85em;">Lv.${r.level} ${escapeHtml(jobName(r.job))}</div>
            </div>
            <div class="row" style="gap: 5px;">
              <button class="btn-primary btn-sm" data-action="select-role" data-player-id="${escapeAttr(r.id)}">进入</button>
              <button class="btn-danger btn-sm" data-action="delete-role" data-player-id="${escapeAttr(r.id)}">删除</button>
            </div>
          </div>
        `;
      }).join("");

      $$("#role-list-container [data-action='select-role']").forEach(el => {
        el.addEventListener("click", async () => {
          const playerId = el.dataset.playerId;
          try {
            const newState = await api("/api/player/select", { method: "POST", body: { playerId } });
            state = newState;
            showCreateModal(false);
            render();
          } catch (err) {
            alert(err.message || "选择失败");
          }
        });
      });

      $$("#role-list-container [data-action='delete-role']").forEach(el => {
        el.addEventListener("click", async (e) => {
          e.stopPropagation();
          const playerId = el.dataset.playerId;
          if (!confirm("确定要删除该角色吗？所有进度将永久丢失！")) return;
          try {
            const newState = await api("/api/player/delete", { method: "POST", body: { playerId } });
            state = newState;
            render();
            showCreateModal(true);
          } catch (err) {
            alert(err.message || "删除失败");
          }
        });
      });
    }
  } else {
    sectionRoleList?.classList.add("hidden");
    sectionCreate?.classList.remove("hidden");
  }
}

function showAuthModal(show) {
  $("#modal-auth").classList.toggle("hidden", !show);
  $("#auth-hint").textContent = "";
}

function showTownModal(show) {
  $("#modal-town")?.classList.toggle("hidden", !show);
}

function closeTownModal() {
  $("#modal-town")?.classList.add("hidden");
}

/**
 * 渲染仓库格子
 * @param {Array} items - 物品数组
 * @param {number} cols - 列数
 * @param {number} rows - 行数
 * @param {string} actionType - 操作类型："store" 存入 或 "take" 取出
 */
function renderWarehouseGrid(items, cols, rows, actionType) {
  const totalSlots = cols * rows;
  
  // 排序：装备按评分，其他按类型
  const sortedItems = [...items].sort((a, b) => {
    if (a.type === "equip" && b.type !== "equip") return -1;
    if (a.type !== "equip" && b.type === "equip") return 1;
    if (a.type === "equip" && b.type === "equip") {
      return (b.score ?? 0) - (a.score ?? 0);
    }
    return 0;
  });
  
  const gridSlots = [];
  for (let i = 0; i < totalSlots; i++) {
    gridSlots[i] = sortedItems[i] || null;
  }
  
  return gridSlots.map((item, index) => {
    if (!item) {
      return `<div class="inventory-grid-slot empty" data-slot-index="${index}"></div>`;
    }
    
    const equipped = !!item.equipped;
    const icon = getEquipIcon(item.slot) || getItemIcon(item.type, item);
    const rarity = item.rarity || "white";
    const stackCount = item.stackCount || 1;
    const showStack = stackCount > 1 && (item.type === "potion" || item.type === "skill_book");
    
    // 根据操作类型设置按钮文本
    const actionText = actionType === "store" ? "存入" : "取出";
    const actionClass = actionType === "store" ? "btn-secondary" : "btn-primary";
    
    return `
      <div class="inventory-grid-slot ${equipped ? "equipped" : ""} ${rarity}" 
           data-item-id="${escapeAttr(item.id)}" 
           data-slot-index="${index}"
           data-rarity="${escapeAttr(rarity)}"
           data-action-type="${actionType}">
        <div class="grid-slot-icon">${icon}</div>
        ${showStack ? `<span class="grid-slot-count">${stackCount}</span>` : ""}
        ${equipped ? `<span class="equipped-badge">已穿戴</span>` : ""}
      </div>
    `;
  }).join("");
}

function openTownModal(kind) {
  const titleEl = $("#town-title");
  const bodyEl = $("#town-body");
  if (!titleEl || !bodyEl) return;
  const p = state?.player;
  if (!p) return;

  if (kind === "weapon") {
    titleEl.textContent = "武器店";
    const items = (state.shopItems ?? []).filter((x) => x.grantEquipSlot);
    
    // 渲染商店格子
    const shopGridHtml = items.map((it, index) => {
      const rarity = it.rarity || "white";
      const icon = getEquipIcon(it.grantEquipSlot) || "🎒";
      return `
        <div class="shop-grid-slot ${rarity}" 
             data-item-id="${escapeAttr(it.id)}" 
             data-item-name="${escapeAttr(it.name)}"
             data-item-price="${Number(it.priceGold ?? 0)}"
             data-slot-index="${index}">
          <div class="grid-slot-icon">${icon}</div>
          <div class="shop-slot-info">
            <div class="shop-slot-name">${escapeHtml(it.name)}</div>
            <div class="shop-slot-price">💰 ${Number(it.priceGold ?? 0)}</div>
          </div>
          <div class="shop-slot-actions">
            <button class="btn-shop-buy" data-action="town-buy" data-item-id="${escapeAttr(it.id)}" title="购买 1 个">买</button>
          </div>
        </div>
      `;
    }).join("");
    
    bodyEl.innerHTML = `
      <div style="margin-bottom: 12px;">
        <div class="warehouse-panel-title">
          🔨 武器商店
          <span class="warehouse-panel-subtitle">（商品：${items.length} 件）</span>
        </div>
      </div>
      <div class="inventory-grid-container" style="padding: 8px; min-width: auto;">
        <div class="inventory-grid-8x10">
          ${shopGridHtml}
        </div>
      </div>
      
      <!-- 关闭按钮 -->
      <div style="display: flex; justify-content: flex-end; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line);">
        <button id="btn-town-close" class="btn-secondary">关闭</button>
      </div>
    `;
  } else if (kind === "potion") {
    titleEl.textContent = "药品店";
    const items = (state.shopItems ?? []).filter((x) => Number(x.healHp ?? 0) > 0 || Number(x.healMp ?? 0) > 0);
    
    // 渲染商店格子
    const shopGridHtml = items.map((it, index) => {
      const heal = `${it.healHp ? `HP+${it.healHp}` : ""}${it.healHp && it.healMp ? " · " : ""}${it.healMp ? `MP+${it.healMp}` : ""}`;
      const icon = getItemIcon("potion", it) || "🧪";
      return `
        <div class="shop-grid-slot potion" 
             data-item-id="${escapeAttr(it.id)}" 
             data-item-name="${escapeAttr(it.name)}"
             data-item-heal="${escapeAttr(heal)}"
             data-item-price="${Number(it.priceGold ?? 0)}"
             data-slot-index="${index}">
          <div class="grid-slot-icon">${icon}</div>
          <div class="shop-slot-info">
            <div class="shop-slot-name">${escapeHtml(it.name)}</div>
            <div class="shop-slot-heal">${escapeHtml(heal)}</div>
            <div class="shop-slot-price">💰 ${Number(it.priceGold ?? 0)}</div>
          </div>
          <div class="shop-slot-actions">
            <button class="btn-shop-buy" data-action="town-buy" data-item-id="${escapeAttr(it.id)}" title="购买 1 个">买</button>
            <button class="btn-shop-bulk" data-action="town-buy-10" data-item-id="${escapeAttr(it.id)}" title="购买 10 个">×10</button>
            <button class="btn-shop-bulk" data-action="town-buy-100" data-item-id="${escapeAttr(it.id)}" title="购买 100 个">×100</button>
          </div>
        </div>
      `;
    }).join("");
    
    bodyEl.innerHTML = `
      <div style="margin-bottom: 12px;">
        <div class="warehouse-panel-title">
          🧪 药品商店
          <span class="warehouse-panel-subtitle">（商品：${items.length} 件）</span>
        </div>
      </div>
      <div class="inventory-grid-container" style="padding: 8px; min-width: auto;">
        <div class="inventory-grid-8x10">
          ${shopGridHtml}
        </div>
      </div>
      
      <!-- 关闭按钮 -->
      <div style="display: flex; justify-content: flex-end; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line);">
        <button id="btn-town-close" class="btn-secondary">关闭</button>
      </div>
    `;
  } else if (kind === "warehouse") {
    titleEl.textContent = "仓库";
    
    const inv = (p.inventory ?? []).filter((it) => it.type === "equip" || it.type === "potion");
    const wh = p.warehouse ?? [];
    
    // 过滤已穿戴装备
    const canStore = inv.filter((it) => !(it.type === "equip" && it.equipped));
    
    // 渲染背包格子（8x10）
    const invGridHtml = renderWarehouseGrid(canStore, 8, 10, "store");
    
    // 渲染仓库格子（8x10）
    const whGridHtml = renderWarehouseGrid(wh, 8, 10, "take");
    
    bodyEl.innerHTML = `
      <div class="warehouse-panels">
        <!-- 背包面板 -->
        <div class="warehouse-panel">
          <div class="warehouse-panel-title">
            🎒 背包
            <span class="warehouse-panel-subtitle">（可存放：${canStore.length} 件）</span>
          </div>
          <div class="inventory-grid-container" style="padding: 8px; min-width: auto;">
            <div class="inventory-grid-8x10">
              ${invGridHtml}
            </div>
          </div>
        </div>
        
        <!-- 仓库面板 -->
        <div class="warehouse-panel">
          <div class="warehouse-panel-title">
            🏦 仓库
            <span class="warehouse-panel-subtitle">（容量：${wh.length} / 80）</span>
          </div>
          <div class="inventory-grid-container" style="padding: 8px; min-width: auto;">
            <div class="inventory-grid-8x10">
              ${whGridHtml}
            </div>
          </div>
        </div>
      </div>
      
      <!-- 关闭按钮 -->
      <div style="display: flex; justify-content: flex-end; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line);">
        <button id="btn-warehouse-close" class="btn-secondary">关闭</button>
      </div>
    `;
  } else {
    titleEl.textContent = "城市设施";
    bodyEl.innerHTML = `<div class="muted">未知设施</div>`;
  }

  showTownModal(true);

  // 商店购买事件
  $$("#modal-town [data-action='town-buy']").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const itemId = btn.dataset.itemId;
      await actionShopBuy(itemId);
      openTownModal(kind);
    });
  });
  
  // 药品批量购买事件（×10, ×100）
  if (kind === "potion") {
    $$("#modal-town [data-action='town-buy-10']").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const itemId = btn.dataset.itemId;
        for (let i = 0; i < 10; i++) {
          await actionShopBuy(itemId);
        }
        openTownModal(kind);
      });
    });
    
    $$("#modal-town [data-action='town-buy-100']").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const itemId = btn.dataset.itemId;
        for (let i = 0; i < 100; i++) {
          await actionShopBuy(itemId);
        }
        openTownModal(kind);
      });
    });
  }
  
  // 关闭按钮事件（适用于所有商店）
  $("#btn-town-close")?.addEventListener("click", () => {
    closeTownModal();
  });
  
  // 仓库格子点击事件
  if (kind === "warehouse") {
    $$("#modal-town .inventory-grid-slot:not(.empty)").forEach((slot) => {
      slot.addEventListener("click", async (e) => {
        e.stopPropagation();
        const itemId = slot.dataset.itemId;
        const actionType = slot.dataset.actionType;
        
        if (!itemId) return;
        
        // 根据操作类型执行不同动作
        if (actionType === "store") {
          await actionWarehouseStore(itemId);
          openTownModal(kind);
        } else if (actionType === "take") {
          await actionWarehouseTake(itemId);
          openTownModal(kind);
        }
      });
    });
    
    // 关闭按钮事件
    $("#btn-warehouse-close")?.addEventListener("click", () => {
      closeTownModal();
    });
  }
}

function setActiveTab(tab) {
  currentTab = tab;
  $$(".nav-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $("#view-map").classList.toggle("hidden", tab !== "map");
  $("#view-bag").classList.toggle("hidden", tab !== "bag");
  $("#view-forge").classList.toggle("hidden", tab !== "forge");
  $("#view-shop").classList.toggle("hidden", tab !== "shop");
  $("#view-attr")?.classList.toggle("hidden", tab !== "attr");
  $("#view-skills")?.classList.toggle("hidden", tab !== "skills");
}

function setActiveLogFilter(filter) {
  logFilter = filter === "loot" ? "loot" : "all";
  $$(".chip").forEach((b) => b.classList.toggle("active", b.dataset.log === filter));
  renderRightLogs();
}

function jobName(job) {
  return { warrior: "战士", mage: "法师", taoist: "道士" }[job] ?? job;
}

function jobAttackLabel(job) {
  return { warrior: "攻击", mage: "魔法", taoist: "道术" }[job] ?? "攻击";
}

function jobIcon(job) {
  return { warrior: "🗡️", mage: "🪄", taoist: "📿" }[job] ?? "🧑";
}

function monsterIcon(monsterId) {
  return (
    {
      chicken: "🐔",
      deer: "🦌",
      scarecrow: "🌾",
      rake_cat: "🐱",
      half_orc: "👺",
      multi_hook_cat: "🐾",
      forest_snowman: "⛄",
      wooma_soldier: "🗿",
      wooma_fighter: "🗿",
      red_snake: "🐍",
      tiger_snake: "🐍",
      wolf: "🐺",
      sand_worm: "🪱",
      shell_nipper: "🪲",
      zombie: "🧟",
      zombie_king: "🧟",
      red_boar: "🐗",
      black_boar: "🐗",
      moth: "🦋",
      centipede: "🐛",
      bee: "🐝",
      tongs: "🦂",
      evil_tongs: "🦂",
      zuma_statue: "🗿",
      zuma_guardian: "🗿",
      zuma_archer: "🏹",
      skeleton: "💀",
      axe_skeleton: "💀",
      hongmo_boar_guard: "🐗",
      hongmo_scorpion_guard: "🦂",
      moon_spider: "🕷️",
      kiss_spider: "🕷️",
      fang_spider: "🕷️",
      bone_demon: "💀",
      minotaur_warrior: "🐮",
      minotaur_mage: "🐮"
    }[monsterId] ?? "👾"
  );
}

function calcPowerScore(atk, def, hpMax) {
  return Math.floor(atk * 6 + def * 4 + hpMax * 0.6);
}

function render() {
  if (!state) return;
  document.querySelector("#toast")?.remove();
  const player = state.player;
  if (!player) {
    // 如果没有活跃角色且没有打开创建面板，则强制打开
    const modal = $("#modal-create");
    if (modal && modal.classList.contains("hidden")) {
      showCreateModal(true);
    }
    // 即使没有角色也需要渲染左侧状态为空或提示
    renderLeftStatusEmpty();
    renderStartStopUI();
    return;
  }
  showCreateModal(false);
  renderHintsCard();
  renderAttrView();
  renderSkillsView();
  renderMapView();
  renderBagView();
  renderForgeView();
  renderShopView();
  renderBattleView();
  renderRightLogs();
  renderConsumablesCard();
  maybeNotifyDrops();
  $("#setting-auto-equip") && ($("#setting-auto-equip").checked = !!player.settings?.autoEquip);
  $("#setting-auto-recycle") && ($("#setting-auto-recycle").checked = !!player.settings?.autoRecycle);
  $("#setting-sfx") && ($("#setting-sfx").checked = isSfxEnabled());
  $("#setting-recycle-threshold") &&
    ($("#setting-recycle-threshold").value = String(player.settings?.recycleRarityThreshold ?? "white"));
  $("#setting-auto-hp") && ($("#setting-auto-hp").value = String(player.settings?.autoHpPotionPct ?? 35));
  $("#setting-auto-mp") && ($("#setting-auto-mp").value = String(player.settings?.autoMpPotionPct ?? 35));
  renderLeftStatus();
  renderStartStopUI();
}

function renderHintsCard() {
  const el = $("#card-hints");
  if (!el) return;
  const latest = hintMessages.slice(-8).reverse();
  const html = `
    <div class="card-title">提示</div>
    <div class="list">
      ${
        latest.length
          ? latest
              .map((t) => {
                return `<div class="list-item" style="color: var(--danger); font-weight: 800;">${escapeHtml(t)}</div>`;
              })
              .join("")
          : `<div class="muted">暂无提示</div>`
      }
    </div>
  `;
  el.innerHTML = html;
}
function renderPlayerCard() {
  const player = state.player;
  const map = state.currentMap;
  const expPct = player.expToNext > 0 ? Math.floor((player.exp / player.expToNext) * 100) : 0;
  const html = `
    <div class="card-title">角色</div>
    <div class="kv">
      <div class="k">名字</div><div class="v">${escapeHtml(player.name)}</div>
      <div class="k">职业</div><div class="v">${escapeHtml(jobName(player.job))}</div>
      <div class="k">等级</div><div class="v">Lv.${player.level}</div>
      <div class="k">经验</div><div class="v">${player.exp}/${player.expToNext}（${expPct}%）</div>
      <div class="k">生命</div><div class="v">${player.hp}/${player.hpMax}</div>
      <div class="k">魔法</div><div class="v">${player.mp}/${player.mpMax}</div>
      <div class="k">${jobAttackLabel(player.job)}</div><div class="v">${player.atk}</div>
      <div class="k">防御</div><div class="v">${player.def}</div>
      <div class="k">金币</div><div class="v">${player.gold}</div>
      <div class="k">地图</div><div class="v">${escapeHtml(map?.name ?? "-")}</div>
      <div class="k">挂机</div><div class="v">${state.runtime?.isRunning ? "进行中" : "停止"}</div>
    </div>
    <div class="muted" style="margin-top:8px;">地图推荐战力：${map?.recommendPower ?? "-"}</div>
  `;
  $("#card-player").innerHTML = html;
}

function renderEquipCard() {
  const p = state.player;
  const eq = p.equipped ?? {};
  const slots = (state.equipSlots ?? []).map((id) => ({ id, name: slotName(id) }));
  const html = `
    <div class="card-title">已穿戴</div>
    <div class="list">
      ${slots
        .map((s) => {
          const item = eq[s.id];
          if (!item) {
            return `<div class="list-item"><div class="list-item-title">${s.name}</div><div class="list-item-sub">未穿戴</div></div>`;
          }
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(item.name)}${item.strengthenLevel ? ` +${item.strengthenLevel}` : ""}</div>
              <div class="list-item-sub">攻${item.stats?.atk ?? 0} 术${item.stats?.tao ?? 0} 魔${item.stats?.magic ?? 0} 防${item.stats?.def ?? 0} 血${item.stats?.hpMax ?? 0} · 评分 ${item.score}</div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#card-equip").innerHTML = html;
}

function renderSkillsCard() {
  const el = $("#card-skills");
  if (!el) return;
  const p = state.player;
  const defs = state.skillDefs ?? [];
  const levels = p.skills?.levels ?? {};
  const activeId = p.skills?.activeId ?? null;

  const findDef = (id) => defs.find((d) => d.id === id);
  const fmtLv = (id) => {
    const info = levels[id];
    if (!info) return "Lv.1";
    return `Lv.${info.level ?? 1}（熟练 ${info.exp ?? 0}）`;
  };

  const activeList = Array.from(new Set(p.skills?.activeIds ?? []));
  const passiveList = Array.from(new Set(p.skills?.passiveIds ?? []));
  const books = (p.inventory ?? []).filter((it) => it.type === "skill_book");

  const html = `
    <div class="card-title">技能</div>
    <div class="muted">当前主动：${escapeHtml(findDef(activeId)?.name ?? "普攻")}</div>
    <div class="list" style="margin-top:10px;">
      ${activeList.length
        ? activeList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              const isCur = id === activeId;
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}${isCur ? "（已选）" : ""}</div>
                  <div class="list-item-sub">${escapeHtml(d.style === "ranged" ? "远程" : "近战")} · MP ${d.mpCost ?? 0} · 距离 ${d.range ?? 1} · 学习等级 ${d.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-secondary" data-action="skill-set" data-skill-id="${escapeAttr(id)}" ${isCur ? "disabled" : ""}>设为主动</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习主动技能（当前使用普攻）</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">被动技能（自动生效，不消耗MP）</div>
    <div class="list" style="margin-top:8px;">
      ${passiveList.length
        ? passiveList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}</div>
                  <div class="list-item-sub">学习等级 ${d.learnLevel ?? 1}</div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习被动技能</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">技能书</div>
    <div class="list" style="margin-top:8px;">
      ${books.length
        ? books
            .map((b) => {
              return `
                <div class="list-item">
                  <div class="list-item-title">《${escapeHtml(b.skillName)}》</div>
                  <div class="list-item-sub">需求等级 ${b.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-primary" data-action="book-use" data-item-id="${escapeAttr(b.id)}">学习</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">暂无技能书</div>`}
    </div>
  `;
  el.innerHTML = html;

  $$("#card-skills [data-action='skill-set']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionSetActiveSkill(btn.dataset.skillId);
    });
  });
  $$("#card-skills [data-action='book-use']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionUseSkillBook(btn.dataset.itemId);
    });
  });
}

function renderMapView() {
  const curMap = state.currentMap ?? null;
  const exits = state.mapExits ?? {};
  const cells = Array.from({ length: 9 }, () => null);
  cells[1] = exits.up ?? null;
  cells[5] = exits.right ?? null;
  cells[7] = exits.down ?? null;
  cells[3] = exits.left ?? null;
  cells[4] = "CENTER";

  const renderCell = (m, isCenter) => {
    if (!m && !isCenter) return `<div class="map-cell"></div>`;
    const townAttr = isCenter ? (curMap?.isTown ? ' data-is-town="1"' : "") : (m?.isTown ? ' data-is-town="1"' : "");
    if (isCenter) {
      return `
        <div class="map-cell current"${townAttr}>
          <div class="map-title">${escapeHtml(curMap?.name ?? "-")}（当前）</div>
          <div class="map-sub"></div>
        </div>
      `;
    }
    const canGo = !!m?.canGo;
    const reason = canGo ? null : (m?.reason ?? "无法前往");
    return `
      <div class="map-cell" data-locked="${canGo ? "0" : "1"}"${townAttr}>
        <div class="map-title">${escapeHtml(m?.name ?? "-")}</div>
        <div class="map-sub">推荐战力 ${m?.recommendPower ?? "-"}${reason ? ` · <span class="locked-reason">${escapeHtml(reason)}</span>` : ""}</div>
        <div class="map-actions">
          <button class="btn-secondary ${canGo ? "" : "is-disabled"}" data-action="map-go" data-map-id="${escapeAttr(m.id)}">前往</button>
        </div>
      </div>
    `;
  };

  const html = `
    <div class="card-title">地图</div>
    <div class="map-grid">
      ${cells
        .map((c) => {
          if (c === "CENTER") return renderCell(curMap, true);
          if (c == null) return renderCell(null, false);
          return renderCell(c, false);
        })
        .join("")}
    </div>
  `;
  $("#view-map").innerHTML = html;
  $$("#view-map [data-action='map-go']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const mapId = btn.dataset.mapId;
      const item = btn.closest(".map-cell");
      const locked = item?.dataset.locked === "1";
      if (locked) {
        const reasonEl = item.querySelector(".locked-reason");
        if (reasonEl) {
          reasonEl.classList.add("flash");
          setTimeout(() => reasonEl.classList.remove("flash"), 800);
        }
        return;
      }
      try {
        await actionSetMap(mapId);
        triggerBattleRefresh();
      } catch {}
    });
  });
}

function renderBagView() {
  const inv = state.player.inventory ?? [];
  const equips = inv.filter((it) => it.type === "equip");
  const books = inv.filter((it) => it.type === "skill_book");
  const potions = inv.filter((it) => it.type === "potion");
  
  // 创建 8x10 的格子数组
  const GRID_ROWS = 10;
  const GRID_COLS = 8;
  const totalSlots = GRID_ROWS * GRID_COLS;
  
  // 所有物品按类型排序：装备 > 技能书 > 药水
  const allItems = [
    ...equips.sort((a, b) => (b.score ?? 0) - (a.score ?? 0)),
    ...books,
    ...potions
  ];
  
  // 合并相同物品（仅消耗品和技能书）
  const stackedItems = [];
  for (const item of allItems) {
    if (item.type === "equip") {
      // 装备不叠加，每个都是独立的
      stackedItems.push({ ...item, stackCount: 1 });
    } else {
      // 消耗品和技能书查找是否已存在
      // 药水：根据 potionId 或 (name + healHp + healMp) 判断是否相同
      // 技能书：根据 skillId 或 skillName 判断是否相同
      const existing = stackedItems.find(it => {
        if (it.type !== item.type) return false;
        
        if (it.type === "potion") {
          // 药水：使用 potionId 或名称 + 属性判断
          // 1. 如果都有 potionId，比较 potionId
          if (it.potionId && item.potionId) {
            return it.potionId === item.potionId;
          }
          // 2. 如果都没有 potionId，比较 name + healHp + healMp
          if (!it.potionId && !item.potionId) {
            return it.name === item.name && 
                   it.healHp === item.healHp && 
                   it.healMp === item.healMp;
          }
          // 3. 一个有 potionId 一个没有，比较 name（兼容旧数据）
          return it.name === item.name;
        }
        
        if (it.type === "skill_book") {
          // 技能书：优先比较 skillId，其次比较技能名称
          if (it.skillId && item.skillId) {
            return it.skillId === item.skillId;
          }
          return it.skillName === item.skillName;
        }
        
        // 其他类型：比较 ID（默认行为）
        return it.id === item.id;
      });
      
      if (existing) {
        existing.stackCount = (existing.stackCount || 1) + 1;
      } else {
        stackedItems.push({ ...item, stackCount: 1 });
      }
    }
  }
  const gridSlots = [];
  for (let i = 0; i < totalSlots; i++) {
    gridSlots[i] = stackedItems[i] || null;
  }
  const html = `
    <div class="card-title">背包（装备 ${equips.length} · 技能书 ${books.length} · 药水 ${potions.length}）</div>
    <div class="row">
      <button class="btn-secondary" id="btn-recycle-selected">回收选中</button>
      <button class="btn-secondary" id="btn-recycle-auto">一键回收</button>
    </div>
    
    <!-- 背包格子区域 -->
    <div class="inventory-grid-container" style="margin-top:10px;">
      <div class="inventory-grid-8x10">
        ${gridSlots.map((item, index) => {
          if (!item) {
            return `<div class="inventory-grid-slot empty" data-slot-index="${index}"></div>`;
          }
          const equipped = !!item.equipped;
          const icon = getEquipIcon(item.slot) || getItemIcon(item.type, item);
          const rarity = item.rarity || "white";
          const stackCount = item.stackCount || 1;
          const showStack = stackCount > 1 && (item.type === "potion" || item.type === "skill_book");
          
          return `
            <div class="inventory-grid-slot ${equipped ? "equipped" : ""} ${rarity}" 
                 data-item-id="${escapeAttr(item.id)}" 
                 data-slot-index="${index}"
                 data-rarity="${escapeAttr(rarity)}">
              <div class="grid-slot-icon">${icon}</div>
              ${showStack ? `<span class="grid-slot-count">${stackCount}</span>` : ""}
              ${equipped ? `<span class="equipped-badge">已穿戴</span>` : ""}
            </div>
          `;
        }).join("")}
      </div>
    </div>
    
    <!-- 物品详情面板 -->
    <div id="item-detail-panel" class="item-detail-panel hidden">
      <div class="item-detail-header">
        <span id="detail-icon" class="detail-icon"></span>
        <div>
          <div id="detail-name" class="detail-name"></div>
          <div id="detail-type" class="detail-type"></div>
        </div>
      </div>
      <div id="detail-stats" class="detail-stats"></div>
      <div id="detail-desc" class="detail-desc"></div>
      <div id="detail-actions" class="detail-actions"></div>
      <button class="btn-close-detail" onclick="closeItemDetail()">关闭</button>
    </div>
  `;
  $("#view-bag").innerHTML = html;
  
  // 绑定格子点击事件 - 显示装备对比窗口
  $$("#view-bag .inventory-grid-slot:not(.empty)").forEach((slot) => {
    slot.addEventListener("click", (e) => {
      e.stopPropagation();
      const itemId = slot.dataset.itemId;
      const item = stackedItems.find(it => it.id === itemId);
      if (!item) return;
      
      // 只有装备才显示对比窗口
      if (item.type === "equip") {
        showEquipCompareWindow(item, slot);
        return;
      }
      
      // 非装备物品（药水、技能书），显示堆叠信息
      if (item.stackCount > 1) {
        showItemTooltip(item, slot, item.stackCount);
      }
    });
  });
  $("#btn-recycle-selected")?.addEventListener("click", async () => {
    const ids = $$("#view-bag [data-recycle-id]:checked").map((c) => c.dataset.recycleId);
    if (ids.length <= 0) return;
    await actionRecycle(ids);
    renderBagView(); // 回收后重新渲染，自动排序
  });
  $("#btn-recycle-auto")?.addEventListener("click", async () => {
    const th = String(state.player?.settings?.recycleRarityThreshold ?? "white");
    const order = ["white", "green", "blue", "purple", "orange"];
    const thIdx = Math.max(0, order.indexOf(th));
    const ids = (state.player.inventory ?? [])
      .filter((it) => it.type === "equip" && !it.equipped && !it.locked)
      .filter((it) => Math.max(0, order.indexOf(String(it.rarity ?? "white"))) <= thIdx)
      .map((it) => it.id);
    if (ids.length <= 0) return;
    await actionRecycle(ids);
    renderBagView(); // 回收后重新渲染，自动排序
  });
}

// 显示装备对比窗口
function showEquipCompareWindow(item, slotEl) {
  // 防止重复打开
  const existingWindow = document.getElementById('equip-compare-window');
  if (existingWindow) {
    closeEquipCompareWindow();
    return;
  }
  
  // 获取当前身上穿戴的同部位装备
  const currentEquip = state.player.equipped?.[item.slot] || null;
  
  // 创建对比窗口 HTML
  const compareHtml = `
    <div id="equip-compare-window" class="equip-compare-window" style="position: fixed; z-index: 1000;">
      <div class="equip-compare-content">
        <div class="compare-title">装备对比</div>
        
        <div class="compare-container">
          <!-- 当前穿戴的装备 -->
          <div class="compare-panel">
            <div class="compare-panel-header">当前装备</div>
            ${currentEquip ? renderEquipDetail(currentEquip, item) : '<div class="empty-tip">未穿戴</div>'}
          </div>
          
          <!-- 选中的装备 -->
          <div class="compare-panel selected">
            <div class="compare-panel-header">选中装备</div>
            ${renderEquipDetail(item, currentEquip)}
          </div>
        </div>
        
        <div class="compare-actions">
          ${currentEquip && currentEquip.id === item.id 
            ? `<button id="btn-unequip" class="btn-secondary">卸下装备</button>`
            : `<button id="btn-equip" class="btn-primary">穿戴此装备</button>`
          }
          <button id="btn-close-compare" class="btn-secondary">关闭</button>
        </div>
      </div>
    </div>
  `;
  
  // 添加到页面
  document.body.insertAdjacentHTML('beforeend', compareHtml);
  
  // 定位窗口（在点击位置附近）
  const rect = slotEl.getBoundingClientRect();
  const windowEl = document.getElementById('equip-compare-window');
  const contentEl = windowEl?.querySelector('.equip-compare-content');
  
  if (windowEl && contentEl) {
    const contentWidth = 320; // 减小宽度
    const contentHeight = 400;
    
    // 计算位置：让窗口出现在点击位置的右上方
    let left = rect.left - 160; // 向左偏移，使窗口中心对准格子
    let top = rect.top - 420;   // 向上偏移，避免遮挡视线
    
    // 确保不超出屏幕左边界
    if (left < 10) {
      left = 10;
    }
    
    // 确保不超出屏幕右边界
    if (left + contentWidth > window.innerWidth - 10) {
      left = window.innerWidth - contentWidth - 10;
    }
    
    // 确保不超出屏幕上边界
    if (top < 10) {
      top = 10;
    }
    
    // 如果下方空间更多，就显示在下方
    if (top + contentHeight > window.innerHeight - 10 && rect.top > window.innerHeight / 2) {
      top = rect.bottom + 10;
    }
    
    windowEl.style.left = '0';
    windowEl.style.top = '0';
    contentEl.style.position = 'fixed';
    contentEl.style.left = left + 'px';
    contentEl.style.top = top + 'px';
  }
  
  // 绑定事件
  setTimeout(() => {
    $("#btn-equip")?.addEventListener("click", async (e) => {
      e.stopPropagation();
      await actionEquip(item.id);
      closeEquipCompareWindow();
    });
    
    $("#btn-unequip")?.addEventListener("click", async (e) => {
      e.stopPropagation();
      await actionUnequip(item.id);
      closeEquipCompareWindow();
    });
    
    $("#btn-close-compare")?.addEventListener("click", (e) => {
      e.stopPropagation();
      closeEquipCompareWindow();
    });
    
    // 点击其他地方关闭窗口 - 使用捕获阶段确保能正确触发
    setTimeout(() => {
      document.addEventListener('click', closeEquipCompareWindowHandler, { capture: true });
    }, 50);
  }, 10);
}

// 渲染装备详情（带对比高亮）
function renderEquipDetail(item, compareItem) {
  if (!item) return '';
  
  const stats = item.stats || {};
  const rarityColors = {
    white: '#9ca3af',
    green: '#22c55e',
    blue: '#3b82f6',
    purple: '#a855f7',
    orange: '#f97316'
  };
  
  const rarityColor = rarityColors[item.rarity] || rarityColors.white;
  const compareScore = compareItem?.score || 0;
  const isBetter = item.score > compareScore;
  
  // 辅助函数：判断属性是否更高并添加样式
  const formatStat = (label, value, compareValue) => {
    if (!value) return '';
    const isHigher = compareValue != null && value > compareValue;
    const style = isHigher ? 'style="color: #ef4444; font-weight: 800;"' : '';
    return `<div class="stat-row" ${style}>${label}: +${value}</div>`;
  };
  
  // 获取对比装备的属性
  const compareStats = compareItem?.stats || {};
  
  return `
    <div class="equip-detail">
      <div class="equip-name" style="color: ${rarityColor};">${escapeHtml(item.name)}</div>
      <div class="equip-sub">${item.slot} · 评分 <span style="color: ${isBetter ? '#ef4444' : 'inherit'}; font-weight: ${isBetter ? '800' : '400'};">${item.score}</span></div>
      <div class="equip-stats">
        ${formatStat('攻击', stats.atk, compareStats.atk)}
        ${formatStat('魔法', stats.magic, compareStats.magic)}
        ${formatStat('道术', stats.tao, compareStats.tao)}
        ${formatStat('防御', stats.def, compareStats.def)}
        ${formatStat('生命', stats.hpMax, compareStats.hpMax)}
      </div>
      ${item.strengthenLevel > 0 ? `<div class="strengthen-level">强化等级：+${item.strengthenLevel}</div>` : ''}
    </div>
  `;
}

// 关闭装备对比窗口
let closeEquipCompareWindowHandler = null;

function closeEquipCompareWindow() {
  const windowEl = document.getElementById('equip-compare-window');
  if (windowEl) {
    windowEl.remove();
  }
  // 移除所有相关的事件监听器（包括捕获和冒泡阶段）
  if (closeEquipCompareWindowHandler) {
    document.removeEventListener('click', closeEquipCompareWindowHandler, { capture: true });
    document.removeEventListener('click', closeEquipCompareWindowHandler);
    closeEquipCompareWindowHandler = null;
  }
}

// 创建全局的关闭处理器
closeEquipCompareWindowHandler = function(e) {
  const windowEl = document.getElementById('equip-compare-window');
  if (windowEl && !windowEl.contains(e.target)) {
    closeEquipCompareWindow();
  }
};

// 获取装备图标
function getEquipIcon(slot) {
  // 兼容不同的命名方式
  const slotMapping = {
    weapon: "weapon",      // 利剑
    armor: "armor",        // 盔甲/战袍
    helmet: "helmet",      // 军用头盔
    head: "helmet",        // 兼容：头 → 头盔
    necklace: "necklace",  // 护身符
    ring: "ring",          // 戒指
    bracelet: "bracelet",  // 佛珠/念珠
    boots: "boots",        // 靴子
    shoes: "boots",        // 兼容：鞋 → 靴子
    medal: "medal"         // 勋章/奖牌
  };
  
  const icons = {
    weapon: "🗡️",      // 利剑
    armor: "🥋",       // 盔甲/战袍
    helmet: "🪖",      // 军用头盔
    necklace: "🧿",    // 护身符
    ring: "💍",        // 戒指
    bracelet: "📿",    // 佛珠/念珠
    boots: "👢",       // 靴子
    medal: "🏅"        // 勋章/奖牌
  };
  
  // 如果 slot 不存在或没有对应图标，返回 null 让 getItemIcon 处理
  if (!slot || !slotMapping[slot]) {
    return null;
  }
  
  const mappedSlot = slotMapping[slot];
  return icons[mappedSlot];
}

function renderShopView() {
  const items = state.shopItems ?? [];
  const html = `
    <div class="card-title">商店（药品购买后自动使用）</div>
    ${
      items.length
        ? `<div class="list">
      ${items
        .map((it) => {
          const isEquip = !!it.grantEquipSlot;
          const desc = isEquip
            ? `金币 ${it.priceGold} · 装备（${slotName(it.grantEquipSlot)} · ${it.grantRarity ?? "white"}）`
            : `金币 ${it.priceGold} · +HP ${it.healHp ?? 0} · +MP ${it.healMp ?? 0}`;
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(it.name)}</div>
              <div class="list-item-sub">${escapeHtml(desc)}</div>
              <div class="list-item-actions">
                <button class="btn-primary" data-action="shop-buy" data-item-id="${escapeAttr(it.id)}">购买</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>`
        : `<div class="muted">当前地图不可购买（请前往主城）</div>`
    }
  `;
  $("#view-shop").innerHTML = html;
  $$("#view-shop [data-action='shop-buy']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionShopBuy(btn.dataset.itemId);
    });
  });
}

function renderForgeView() {
  const slots = (state.equipSlots ?? []).map((id) => ({ id, name: slotName(id) }));
  const eq = state.player.equipped ?? {};
  const html = `
    <div class="card-title">强化</div>
    <div class="list">
      ${slots
        .map((s) => {
          const item = eq[s.id];
          if (!item) {
            return `
              <div class="list-item">
                <div class="list-item-title">${s.name}</div>
                <div class="list-item-sub">未穿戴装备</div>
              </div>
            `;
          }
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(item.name)} +${item.strengthenLevel ?? 0}</div>
              <div class="list-item-sub">攻${item.stats?.atk ?? 0} 防${item.stats?.def ?? 0} 血${item.stats?.hpMax ?? 0} · 评分 ${item.score}</div>
              <div class="list-item-actions">
                <button class="btn-primary" data-action="strengthen" data-slot="${escapeAttr(s.id)}">强化 +1</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#view-forge").innerHTML = html;
  $$("#view-forge [data-action='strengthen']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionStrengthen(btn.dataset.slot);
    });
  });
}

function renderLeftStatusEmpty() {
  const el = $("#left-status");
  if (!el) return;
  el.innerHTML = `
    <div class="card-title">状态</div>
    <div class="muted" style="padding: 10px; text-align: center;">请选择或创建角色</div>
  `;
}

function renderLeftStatus() {
  const el = $("#left-status");
  if (!el) return;
  const p = state.player;
  const hpPct = Math.max(0, Math.min(100, Math.floor((p.hp / Math.max(1, p.hpMax)) * 100)));
  const mpPct = Math.max(0, Math.min(100, Math.floor((p.mp / Math.max(1, p.mpMax)) * 100)));
  const expPct = p.expToNext > 0 ? Math.max(0, Math.min(100, Math.floor((p.exp / p.expToNext) * 100))) : 0;
  const html = `
    <div class="card-title">状态</div>
    <div class="stat">
      <div class="stat-label">HP ${p.hp}/${p.hpMax}</div>
      <div class="statbar"><div style="width:${hpPct}%"></div></div>
    </div>
    <div class="stat" style="margin-top:8px;">
      <div class="stat-label">MP ${p.mp}/${p.mpMax}</div>
      <div class="statbar mp"><div style="width:${mpPct}%"></div></div>
    </div>
    <div class="stat" style="margin-top:8px;">
      <div class="stat-label">EXP ${p.exp}/${p.expToNext}</div>
      <div class="expbar"><div style="width:${expPct}%"></div></div>
    </div>
  `;
  el.innerHTML = html;
}
function renderBattleView() {
  const el = $("#battle");
  if (!el) return;
  const player = state.player;
  const runtime = state.runtime;
  const board = runtime?.board;
  const frame = runtime?.lastFrame;
  ensureBattleSkeleton(el);
  syncCellSize();

  const theme = state.currentMap?.themeColor ?? null;
  if (theme) {
    el.style.setProperty("--map-theme", theme);
  }
  const mapId = state.currentMap?.id ?? null;
  if (mapId && mapId !== lastBattleMapId) {
    triggerBattleRefresh();
    lastBattleMapId = mapId;
  }

  const mapName = state.currentMap?.name ?? "-";
  const power = calcPowerScore(player.atk, player.def, player.hpMax);
  const statusBadge = runtime?.isRunning ? "挂机中" : "已停止";

  const hudLeft = el.querySelector("#battle-hud-left");
  const hudRight = el.querySelector("#battle-hud-right");
  if (hudLeft) {
    hudLeft.innerHTML = `
      <span class="badge badge-map" id="badge-map">地图：${escapeHtml(mapName)}</span>
      <span class="badge">状态：${statusBadge}</span>
      <span class="badge">坐标：${board ? `${board.player.x + 1},${board.player.y + 1}` : "-"}</span>
    `;
    if (mapId && mapId !== lastHudMapId) {
      const badge = hudLeft.querySelector("#badge-map");
      if (badge) {
        badge.classList.add("flash-badge");
        setTimeout(() => badge.classList.remove("flash-badge"), 800);
      }
      lastHudMapId = mapId;
    }
  }
  if (hudRight) {
    hudRight.innerHTML = `
      <span class="badge badge-power">战力：${power}</span>
      <span class="badge">金币：${player.gold}</span>
      <span class="badge">魔法：${player.mp}/${player.mpMax}</span>
    `;
  }

  const entitiesRoot = el.querySelector("#battle-entities");
  const layer = el.querySelector("#battle-layer");
  const uiRoot = el.querySelector("#battle-ui");
  if (!entitiesRoot || !layer) return;

  if (!board) {
    entitiesRoot.innerHTML = "";
    if (uiRoot) uiRoot.innerHTML = "";
    return;
  }

  if (uiRoot) {
    if (state.currentMap?.isTown) {
      renderTownBuildings(uiRoot);
    } else {
      uiRoot.innerHTML = "";
    }
  }

  const moved = new Map();
  const attacks = [];
  const deads = [];
  const revives = [];
  const isNewFrame = frame?.id && frame.id !== lastFrameId;
  if (isNewFrame) {
    for (const ev of frame.events ?? []) {
      if (ev.type === "move") moved.set(ev.entityId, ev);
      if (ev.type === "attack") attacks.push(ev);
      if (ev.type === "dead") deads.push(ev);
      if (ev.type === "revive") revives.push(ev);
    }
    lastFrameId = frame.id;
  }

  const desired = new Map();
  desired.set("player", {
    kind: "player",
    id: "player",
    x: board.player.x,
    y: board.player.y,
    hp: player.hp,
    hpMax: player.hpMax,
    name: player.name,
    level: player.level,
    avatar: jobIcon(player.job),
    sub: jobName(player.job)
  });
  for (const m of board.monsters ?? []) {
    const tag = `${m.isElite ? "精" : ""}${m.isRanged ? "远" : ""}`;
    desired.set(m.id, {
      kind: "monster",
      id: m.id,
      x: m.x,
      y: m.y,
      hp: m.hp,
      hpMax: m.hpMax,
      name: m.name,
      level: m.level,
      avatar: monsterIcon(m.monsterId),
      tag
    });
  }

  const existing = new Map();
  Array.from(entitiesRoot.children).forEach((c) => {
    const id = c.dataset.entityId;
    if (id) existing.set(id, c);
  });

  for (const [id, ent] of desired) {
    let node = existing.get(id);
    if (!node) {
      node = document.createElement("div");
      node.dataset.entityId = id;
      node.className = `ent ${ent.kind === "player" ? "player" : "monster"}`;
      node.innerHTML = `
        <div class="ent-top">
          <span class="ent-lv">Lv.${escapeHtml(ent.level)}</span>
          <span class="ent-tag">${escapeHtml(ent.tag ?? "")}</span>
        </div>
        <div class="ent-avatar">${ent.avatar}</div>
        <div class="ent-name">${escapeHtml(ent.name)}</div>
        <div class="ent-sub">${escapeHtml(ent.sub ?? "")}</div>
        <div class="ent-hp"><div></div></div>
      `;
      entitiesRoot.appendChild(node);
    } else {
      const nameEl = node.querySelector(".ent-name");
      const subEl = node.querySelector(".ent-sub");
      const lvEl = node.querySelector(".ent-lv");
      const tagEl = node.querySelector(".ent-tag");
      const avatarEl = node.querySelector(".ent-avatar");
      if (nameEl) nameEl.textContent = ent.name;
      if (subEl) subEl.textContent = ent.sub ?? "";
      if (lvEl) lvEl.textContent = `Lv.${ent.level}`;
      if (tagEl) tagEl.textContent = ent.tag ?? "";
      if (avatarEl) avatarEl.textContent = ent.avatar;
    }
    const hpPct = Math.max(0, Math.min(100, Math.floor((ent.hp / Math.max(1, ent.hpMax)) * 100)));
    const hpFill = node.querySelector(".ent-hp > div");
    if (hpFill) hpFill.style.width = `${hpPct}%`;
  }

  for (const [id, node] of existing) {
    if (!desired.has(id)) node.remove();
  }

  const setPos = (id, pos, instant) => {
    const node = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(id)}"]`);
    if (!node) return;
    node.style.transition = instant ? "none" : "";
    node.style.left = `${pos.x * CELL}px`;
    node.style.top = `${pos.y * CELL}px`;
    if (instant) {
      node.getBoundingClientRect();
      node.style.transition = "";
    }
  };

  if (isNewFrame) {
    for (const [id, ent] of desired) {
      const mv = moved.get(id);
      if (mv) setPos(id, mv.from, true);
      else setPos(id, { x: ent.x, y: ent.y }, true);
    }
    requestAnimationFrame(() => {
      for (const [id, ent] of desired) {
        const mv = moved.get(id);
        if (mv) setPos(id, mv.to, false);
        else setPos(id, { x: ent.x, y: ent.y }, false);
      }
      for (const ev of attacks) animateAttack(entitiesRoot, layer, ev);
      for (const ev of deads) animateDead(entitiesRoot, ev.entityId);
      for (const ev of revives) animateRevive(entitiesRoot, ev.entityId);
    });
  } else {
    for (const [id, ent] of desired) setPos(id, { x: ent.x, y: ent.y }, false);
  }
}

function syncCellSize() {
  const board = document.querySelector(".battle-board");
  if (!board) return;
  const v = parseInt(getComputedStyle(board).getPropertyValue("--cell"));
  if (!Number.isNaN(v) && v > 0) CELL = v;
}
function triggerBattleRefresh() {
  const board = document.querySelector(".battle-board");
  if (!board) return;
  board.classList.add("refresh");
  setTimeout(() => board.classList.remove("refresh"), 480);
}

function renderAttrView() {
  const el = $("#view-attr");
  if (!el) return;
  const p = state.player;
  const map = state.currentMap;
  const expPct = p.expToNext > 0 ? Math.floor((p.exp / p.expToNext) * 100) : 0;
  const hpPct = Math.floor((p.hp / p.hpMax) * 100);
  const mpPct = Math.floor((p.mp / p.mpMax) * 100);
  const html = `
    <div class="card-title">角色属性</div>
    <div class="attr-table">
      <div class="attr-row">
        <div class="attr-label">名字</div>
        <div class="attr-value">${escapeHtml(p.name)}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">职业</div>
        <div class="attr-value">${escapeHtml(jobName(p.job))}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">等级</div>
        <div class="attr-value">Lv.${p.level}</div>
      </div>
      <div class="attr-bar-row">
        <div class="attr-bar-label">生命</div>
        <div class="attr-bar-container">
          <div class="attr-bar hp-bar" style="width: ${hpPct}%"></div>
        </div>
        <div class="attr-bar-value">${p.hp}/${p.hpMax}</div>
      </div>
      <div class="attr-bar-row">
        <div class="attr-bar-label">魔法</div>
        <div class="attr-bar-container">
          <div class="attr-bar mp-bar" style="width: ${mpPct}%"></div>
        </div>
        <div class="attr-bar-value">${p.mp}/${p.mpMax}</div>
      </div>
      <div class="attr-bar-row">
        <div class="attr-bar-label">经验</div>
        <div class="attr-bar-container">
          <div class="attr-bar exp-bar" style="width: ${expPct}%"></div>
        </div>
        <div class="attr-bar-value">${p.exp}/${p.expToNext}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">攻击</div>
        <div class="attr-value">${p.atk}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">防御</div>
        <div class="attr-value">${p.def}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">金币</div>
        <div class="attr-value gold-value">${p.gold}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">当前地图</div>
        <div class="attr-value">${escapeHtml(map?.name ?? "-")}</div>
      </div>
      <div class="attr-row">
        <div class="attr-label">推荐战力</div>
        <div class="attr-value">${map?.recommendPower ?? "-"}</div>
      </div>
    </div>
  `;
  el.innerHTML = html;
}

function renderSkillsView() {
  const el = $("#view-skills");
  if (!el) return;
  const p = state.player;
  const defs = state.skillDefs ?? [];
  const levels = p.skills?.levels ?? {};
  const activeId = p.skills?.activeId ?? null;
  const findDef = (id) => defs.find((d) => d.id === id);
  
  // 计算技能熟练度进度（每级需要 40 点熟练度）
  const calcSkillExpPct = (id) => {
    const info = levels[id];
    if (!info || info.level == null) return 0;
    const currentLevel = info.level ?? 1;
    const exp = info.exp ?? 0;
    const expNeeded = currentLevel >= 3 ? 0 : 40; // 3 级满级
    if (expNeeded === 0) return 100;
    return Math.min(100, Math.floor((exp / expNeeded) * 100));
  };
  
  const activeList = Array.from(new Set(p.skills?.activeIds ?? []));
  const passiveList = Array.from(new Set(p.skills?.passiveIds ?? []));
  const books = (p.inventory ?? []).filter((it) => it.type === "skill_book");
  
  // 生成技能卡片 HTML
  const generateSkillCard = (id, isPassive = false) => {
    const d = findDef(id);
    if (!d) return "";
    const info = levels[id];
    const skillLevel = info?.level ?? 1;
    const skillExp = info?.exp ?? 0;
    const expPct = calcSkillExpPct(id);
    const isMaxLevel = skillLevel >= 3;
    const isCurActive = id === activeId;
    
    return `
      <div class="skill-item ${isCurActive && !isPassive ? 'skill-item-active' : ''}">
        <div class="skill-header">
          <div class="skill-name">
            ${escapeHtml(d.name)}
            ${isCurActive && !isPassive ? '<span class="skill-badge">当前主动</span>' : ''}
            ${isPassive ? '<span class="skill-badge passive">被动</span>' : ''}
          </div>
          <div class="skill-level">Lv.${skillLevel}${isMaxLevel ? ' (MAX)' : ''}</div>
        </div>
        <div class="skill-info">
          ${!isPassive ? `
            <span class="skill-tag">${escapeHtml(d.style === "ranged" ? "远程" : "近战")}</span>
            <span class="skill-dot">•</span>
            <span>MP ${d.mpCost ?? 0}</span>
            <span class="skill-dot">•</span>
            <span>距离 ${d.range ?? 1}</span>
          ` : ''}
          <span class="skill-dot">•</span>
          <span>学习等级 ${d.learnLevel ?? 1}</span>
        </div>
        ${!isPassive ? `
        <div class="skill-desc">${escapeHtml(d.description || '主动技能')}</div>
        ` : ''}
        <div class="skill-exp-row">
          <div class="skill-exp-header">
            <span class="skill-exp-label">熟练度</span>
            <span class="skill-exp-value">${skillExp} / ${isMaxLevel ? 'MAX' : '40'}</span>
          </div>
          <div class="skill-exp-bar-container">
            <div class="skill-exp-bar" style="width: ${expPct}%"></div>
          </div>
        </div>
        ${!isPassive ? `
        <div class="skill-actions">
          <button class="btn-secondary btn-sm" data-action="skill-set" data-skill-id="${escapeAttr(id)}" ${isCurActive ? "disabled" : ""}>设为主动</button>
        </div>
        ` : ''}
      </div>
    `;
  };
  
  const html = `
    <div class="card-title">技能</div>
    
    <div class="skill-section">
      <div class="skill-section-header">
        <span class="skill-section-title">当前主动技能</span>
        <span class="skill-section-value">${escapeHtml(findDef(activeId)?.name ?? "普攻")}</span>
      </div>
    </div>
    
    <div class="skill-section">
      <div class="skill-section-title">主动技能 ${activeList.length > 0 ? `(${activeList.length})` : ''}</div>
      <div class="skill-list" style="margin-top:8px;">
        ${activeList.length
          ? activeList.map((id) => generateSkillCard(id, false)).join("")
          : `<div class="skill-empty">尚未学习主动技能（当前使用普攻）</div>`}
      </div>
    </div>
    
    <div class="skill-section">
      <div class="skill-section-title">被动技能 ${passiveList.length > 0 ? `(${passiveList.length})` : ''}</div>
      <div class="skill-list" style="margin-top:8px;">
        ${passiveList.length
          ? passiveList.map((id) => generateSkillCard(id, true)).join("")
          : `<div class="skill-empty">尚未学习被动技能</div>`}
      </div>
    </div>
    
    <div class="skill-section">
      <div class="skill-section-title">技能书 ${books.length > 0 ? `(${books.length})` : ''}</div>
      <div class="list" style="margin-top:8px;">
        ${books.length
          ? books
              .map((b) => {
                return `
                  <div class="list-item">
                    <div class="list-item-title">《${escapeHtml(b.skillName)}》</div>
                    <div class="list-item-sub">需求等级 ${b.learnLevel ?? 1}</div>
                    <div class="list-item-actions">
                      <button class="btn-primary" data-action="book-use" data-item-id="${escapeAttr(b.id)}">学习</button>
                    </div>
                  </div>
                `;
              })
              .join("")
          : `<div class="skill-empty">暂无技能书</div>`}
      </div>
    </div>
  `;
  el.innerHTML = html;
  const skillSetBtns = $("#view-skills [data-action='skill-set']");
  if (skillSetBtns) {
    skillSetBtns.forEach((btn) => {
      btn.addEventListener("click", async () => {
        await actionSetActiveSkill(btn.dataset.skillId);
      });
    });
  }
  const bookUseBtns = $("#view-skills [data-action='book-use']");
  if (bookUseBtns) {
    bookUseBtns.forEach((btn) => {
      btn.addEventListener("click", async () => {
        await actionUseSkillBook(btn.dataset.itemId);
      });
    });
  }
}
function ensureBattleSkeleton(root) {
  if (root.dataset.inited === "1") return;
  const cells = Array.from({ length: 36 }, (_, i) => {
    const x = i % 6;
    const y = Math.floor(i / 6);
    return `<div class="battle-cell" data-x="${x}" data-y="${y}"></div>`;
  }).join("");
  root.innerHTML = `
    <div class="battle-hud">
      <div class="battle-hud-left" id="battle-hud-left"></div>
      <div class="battle-hud-right" id="battle-hud-right"></div>
    </div>
    <div class="battle-board">
      <div class="battle-grid">${cells}</div>
      <div class="battle-entities" id="battle-entities"></div>
      <div class="battle-layer" id="battle-layer"></div>
      <div class="battle-ui" id="battle-ui"></div>
    </div>
  `;
  root.dataset.inited = "1";
}

function animateAttack(entitiesRoot, layer, ev) {
  const attackerId = ev.attackerId;
  const attackerEl = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(attackerId)}"]`);
  if (!attackerEl) return;
  const dx = (ev.to.x - ev.from.x) * CELL;
  const dy = (ev.to.y - ev.from.y) * CELL;

  try {
    if (ev.style === "ranged") {
      // 远程攻击：根据职业使用不同特效
      attackerEl.animate(
        [
          { transform: "translate3d(0,0,0)" },
          { transform: "translate3d(0,-10px,0)" },
          { transform: "translate3d(0,0,0)" }
        ],
        { duration: 240, easing: "cubic-bezier(.2,.8,.2,1)" }
      );
      
      // 根据职业和技能生成不同投射物
      if (state?.player?.job === "taoist") {
        // 道士：符纸效果
        spawnTaoistFu(layer, ev.from, ev.to);
      } else if (state?.player?.job === "mage") {
        // 法师：根据技能类型选择火球或雷电
        if (ev.skillId === "thunder") {
          spawnThunderBolt(layer, ev.from, ev.to);
        } else {
          spawnFireball(layer, ev.from, ev.to);
        }
      } else {
        // 默认投射物
        spawnProjectile(layer, ev.from, ev.to);
      }
    } else {
      // 近战攻击：战士刀光效果
      attackerEl.animate(
        [
          { transform: "translate3d(0,0,0)" },
          { transform: "translate3d(0,-12px,0)" },
          { transform: `translate3d(${dx}px,${dy - 12}px,0)` },
          { transform: `translate3d(${dx}px,${dy}px,0)` },
          { transform: "translate3d(0,0,0)" }
        ],
        { duration: 360, easing: "cubic-bezier(.2,.8,.2,1)" }
      );
      
      // 战士近战刀光效果
      spawnWarriorSlash(layer, ev.to, attackerEl);
      
      // 播放职业音效
      if (ev.attackerId === "player" && state?.player) {
        playClassSkillSfx(state.player.job, ev.skillId || "basic", ev.style === "ranged");
      }
    }
  } catch {}

  const fx = ev.to.x * CELL + CELL / 2;
  const fy = ev.to.y * CELL + 18;
  const type = ev.targetId === "player" ? "monster" : "player";
  const isCrit = !!ev.isCrit;
  if (isCrit) shakeBattle();
  spawnFloat(layer, type, `${isCrit ? "暴击 " : ""}-${ev.damage}`, fx, fy, isCrit ? "crit" : "");
}

function spawnSlash(layer, pos) {
  const el = document.createElement("div");
  el.className = "slash";
  el.style.left = `${pos.x * CELL + CELL / 2}px`;
  el.style.top = `${pos.y * CELL + 18}px`;
  layer.appendChild(el);
  setTimeout(() => el.remove(), 260);
}

// 战士刀光效果（近战）
function spawnWarriorSlash(layer, pos, attackerEl) {
  const el = document.createElement("div");
  el.className = "warrior-slash";
  el.style.left = `${pos.x * CELL + CELL / 2}px`;
  el.style.top = `${pos.y * CELL + 18}px`;
  
  // 根据攻击方向旋转刀光
  const attackerRect = attackerEl?.getBoundingClientRect();
  if (attackerRect) {
    const targetX = pos.x * CELL + CELL / 2;
    const targetY = pos.y * CELL + 18;
    const angle = Math.atan2(targetY - (attackerRect.top + attackerRect.height / 2), targetX - (attackerRect.left + attackerRect.width / 2));
    el.style.transform = `translate(-50%, -50%) rotate(${angle}rad)`;
  }
  
  layer.appendChild(el);
  setTimeout(() => el.remove(), 300);
}

// 道士符纸效果（远程）
function spawnTaoistFu(layer, from, to) {
  const el = document.createElement("div");
  el.className = "taoist-fu";
  const sx = from.x * CELL + CELL / 2;
  const sy = from.y * CELL + 18;
  const tx = to.x * CELL + CELL / 2;
  const ty = to.y * CELL + 18;
  el.style.left = `${sx}px`;
  el.style.top = `${sy}px`;
  layer.appendChild(el);
  
  try {
    el.animate(
      [
        { 
          transform: "translate3d(0,0,0) rotate(0deg) scale(1)",
          opacity: 1
        },
        { 
          transform: `translate3d(${tx - sx}px,${ty - sy}px,0) rotate(720deg) scale(0.8)`,
          opacity: 1
        },
        {
          transform: `translate3d(${tx - sx}px,${ty - sy}px,0) rotate(720deg) scale(1.2)`,
          opacity: 0
        }
      ],
      { duration: 400, easing: "cubic-bezier(.2,.8,.2,1)" }
    );
  } catch {}
  setTimeout(() => el.remove(), 450);
}

// 法师火球术（远程）
function spawnFireball(layer, from, to) {
  const el = document.createElement("div");
  el.className = "mage-fireball";
  const sx = from.x * CELL + CELL / 2;
  const sy = from.y * CELL + 18;
  const tx = to.x * CELL + CELL / 2;
  const ty = to.y * CELL + 18;
  el.style.left = `${sx}px`;
  el.style.top = `${sy}px`;
  layer.appendChild(el);
  
  try {
    el.animate(
      [
        { 
          transform: "translate3d(0,0,0) scale(0.5)",
          opacity: 0.8
        },
        { 
          transform: `translate3d(${tx - sx}px,${ty - sy}px,0) scale(1.2)`,
          opacity: 1
        },
        {
          transform: `translate3d(${tx - sx}px,${ty - sy}px,0) scale(1.5)`,
          opacity: 0
        }
      ],
      { duration: 350, easing: "cubic-bezier(.2,.8,.2,1)" }
    );
  } catch {}
  setTimeout(() => el.remove(), 400);
}

// 法师雷电术（远程）
function spawnThunderBolt(layer, from, to) {
  const el = document.createElement("div");
  el.className = "mage-thunderbolt";
  const sx = from.x * CELL + CELL / 2;
  const sy = from.y * CELL + 18;
  const tx = to.x * CELL + CELL / 2;
  const ty = to.y * CELL + 18;
  
  // 创建闪电路径（折线）
  const midX = (sx + tx) / 2;
  const midY = (sy + ty) / 2;
  const offsetX = (Math.random() - 0.5) * 40;
  const offsetY = (Math.random() - 0.5) * 40;
  
  el.style.left = `${sx}px`;
  el.style.top = `${sy}px`;
  el.style.width = `${Math.abs(tx - sx)}px`;
  el.style.height = `${Math.abs(ty - sy)}px`;
  
  layer.appendChild(el);
  
  try {
    el.animate(
      [
        { 
          opacity: 0,
          transform: "scale(0.5)"
        },
        { 
          opacity: 1,
          transform: "scale(1)"
        },
        {
          opacity: 0,
          transform: "scale(1.2)"
        }
      ],
      { duration: 200, easing: "cubic-bezier(.2,.8,.2,1)" }
    );
  } catch {}
  setTimeout(() => el.remove(), 250);
}

function spawnProjectile(layer, from, to) {
  const el = document.createElement("div");
  el.className = "projectile";
  const sx = from.x * CELL + CELL / 2;
  const sy = from.y * CELL + 18;
  const tx = to.x * CELL + CELL / 2;
  const ty = to.y * CELL + 18;
  el.style.left = `${sx}px`;
  el.style.top = `${sy}px`;
  layer.appendChild(el);
  try {
    el.animate([{ transform: "translate3d(0,0,0)" }, { transform: `translate3d(${tx - sx}px,${ty - sy}px,0)` }], {
      duration: 260,
      easing: "cubic-bezier(.2,.8,.2,1)"
    });
  } catch {}
  setTimeout(() => el.remove(), 300);
}
function animateDead(entitiesRoot, entityId) {
  const el = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(entityId)}"]`);
  if (!el) return;
  try {
    el.animate([{ opacity: 1, transform: "scale(1)" }, { opacity: 0, transform: "scale(0.9)" }], { duration: 240, easing: "ease-out" });
  } catch {}
  setTimeout(() => el.remove(), 260);
  if (entityId === "player") spawnDeathOverlay();
}

function animateRevive(entitiesRoot, entityId) {
  const el = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(entityId)}"]`);
  if (!el) return;
  try {
    el.animate(
      [
        { boxShadow: "0 0 0 rgba(16,185,129,0)" },
        { boxShadow: "0 0 18px rgba(16,185,129,0.45)" },
        { boxShadow: "0 0 0 rgba(16,185,129,0)" }
      ],
      { duration: 520, easing: "ease-out" }
    );
  } catch {}
}

function spawnFloat(layer, type, text, x, y, extraClass = "") {
  const div = document.createElement("div");
  div.className = `float-dmg ${type}${extraClass ? ` ${extraClass}` : ""}`;
  div.textContent = text;
  div.style.left = `${x}px`;
  div.style.top = `${y}px`;
  layer.appendChild(div);
  setTimeout(() => div.remove(), 900);
}

function shakeBattle() {
  const board = document.querySelector(".battle-board");
  if (!board) return;
  board.classList.add("shake");
  setTimeout(() => board.classList.remove("shake"), 360);
}

function spawnDeathOverlay() {
  const ov = document.createElement("div");
  ov.className = "death-overlay";
  ov.innerHTML = `<div class="death-text">死</div>`;
  document.body.appendChild(ov);
  setTimeout(() => ov.remove(), 5000);
}

function renderTownBuildings(uiRoot) {
  const buildings = [
    { kind: "weapon", label: "武器店", ico: "🗡️", x: 1, y: 1 },
    { kind: "potion", label: "药品店", ico: "🧪", x: 4, y: 1 },
    { kind: "warehouse", label: "仓库", ico: "🏦", x: 2, y: 4 }
  ];
  uiRoot.innerHTML = buildings
    .map((b) => {
      return `<div class="building" data-kind="${escapeAttr(b.kind)}" style="left:${b.x * CELL}px;top:${b.y * CELL}px;"><div class="ico">${b.ico}</div><div class="label">${escapeHtml(b.label)}</div></div>`;
    })
    .join("");
  Array.from(uiRoot.querySelectorAll(".building")).forEach((el) => {
    el.addEventListener("click", () => {
      const kind = el.dataset.kind;
      el.classList.add("flash");
      setTimeout(() => el.classList.remove("flash"), 560);
      setTimeout(() => openTownModal(kind), 220);
    });
  });
}

function renderRightLogs() {
  const logs = state?.logs ?? [];
  const filteredRaw = logs.filter((l) => l.ts >= displayLogClearedAt);
  const filtered =
    logFilter === "loot"
      ? filteredRaw.filter((l) => l.type === "loot")
      : filteredRaw.filter((l) => {
          if (l.type !== "battle") return true;
          const t = String(l.text ?? "");
          return t.includes("复活") || t.includes("被击败");
        });
  const el = $("#card-hints");
  if (!el) return;
  const latest = filtered.slice(-50); // 保留最近50条，按时间正序显示
  const content = latest
    .map((l) => {
      return `<div class="log-item ${escapeAttr(l.type)}"><span class="meta">${fmtTime(l.ts)} · ${escapeHtml(l.type)}</span>${escapeHtml(l.text)}</div>`;
    })
    .join("");
  const html = `
    <div class="card-title">提示</div>
    <div class="list hints-scroll">
      ${content || `<div class="muted">暂无日志</div>`}
    </div>
  `;
  el.innerHTML = html;
  const sc = el.querySelector(".hints-scroll");
  if (sc) {
    try {
      sc.scrollTop = sc.scrollHeight; // 滚动到底部
    } catch {}
  }
}

function renderConsumablesCard() {
  const el = $("#card-consumables");
  if (!el) return;
  
  // 从背包中统计真实的药水数量
  const inv = state?.player?.inventory ?? [];
  
  // 按类型分组统计
  const hpPotions = inv.filter(i => i.type === "potion" && i.healHp > 0 && i.healMp === 0);
  const mpPotions = inv.filter(i => i.type === "potion" && i.healMp > 0 && i.healHp === 0);
  const hybridPotions = inv.filter(i => i.type === "potion" && i.healHp > 0 && i.healMp > 0);
  
  const items = [];
  
  // HP 药水（金创药）
  if (hpPotions.length > 0) {
    items.push({
      icon: "🩸",  // 血滴图标
      name: "金创药",
      count: hpPotions.length,
      key: 0  // 排序键
    });
  }
  
  // MP 药水（魔法药）
  if (mpPotions.length > 0) {
    items.push({
      icon: "🔹",  // 蓝钻图标
      name: "魔法药",
      count: mpPotions.length,
      key: 1
    });
  }
  
  // 万能药（双恢复）
  if (hybridPotions.length > 0) {
    items.push({
      icon: "❤️",  // 红心图标
      name: "万能药",
      count: hybridPotions.length,
      key: 2
    });
  }
  
  // 按 HP → MP → 万能 排序（与背包图标顺序一致）
  items.sort((a, b) => a.key - b.key);
  
  const html = `
    <div class="card-title">药品</div>
    <div class="consumables-grid">
      ${items.length > 0 
        ? items.map(item => 
            `<div class="consumable" title="${escapeAttr(item.name)}">
              <span class="ico">${item.icon}</span>
              <span class="cnt">x${item.count}</span>
            </div>`
          ).join("")
        : `<div class="muted">暂无</div>`
      }
    </div>
  `;
  el.innerHTML = html;
}

function slotName(slot) {
  const names = state?.equipSlotNames ?? null;
  if (names && names[slot]) return names[slot];
  return slot;
}

async function refreshState() {
  try {
    const data = await api("/api/state");
    state = data;
    showAuthModal(false);
    render();
  } catch (err) {
    const msg = String(err?.message ?? err);
    if (msg.includes("未登录")) {
      showAuthModal(true);
      return;
    }
    console.error(err);
  }
}

async function actionCreatePlayer() {
  const name = $("#create-name").value.trim();
  const job = $("#create-job").value;
  if (!name) {
    $("#create-hint").textContent = "请输入角色名字";
    return;
  }
  $("#create-hint").textContent = "正在创建...";
  try {
    state = await api("/api/player/create", { method: "POST", body: { name, job } });
    // 创建后后端已自动设为当前角色并返回完整 state
    showCreateModal(false);
    render();
    // 自动开始
    await actionStart();
  } catch (err) {
    $("#create-hint").textContent = err?.message ?? String(err);
  }
}

async function actionResume() {
  try {
    state = await api("/api/game/start", { method: "POST" });
    render();
    maybeStartTickLoop();
    showCreateModal(false);
  } catch (err) {
    $("#create-hint").textContent = err?.message ?? String(err);
  }
}

async function actionStart() {
  if (!state?.player) {
    showToast("请先选择或创建角色");
    showCreateModal(true);
    return;
  }
  try {
    if (!state?.runtime?.isRunning) {
      state = await api("/api/game/start", { method: "POST" });
      console.log("[DEBUG] 开始挂机后状态:", state.runtime);
    } else {
      state = await api("/api/game/stop", { method: "POST" });
      console.log("[DEBUG] 停止挂机后状态:", state.runtime);
    }
    render();
    maybeStartTickLoop();
    console.log("[DEBUG] maybeStartTickLoop 已调用，ticking:", ticking, "isRunning:", state?.runtime?.isRunning);
  } catch (err) {
    showToast(err.message || "操作失败");
  }
}

async function actionStop() {
  state = await api("/api/game/stop", { method: "POST" });
  render();
}

async function actionTick() {
  const data = await api("/api/game/tick", { method: "POST", body: { count: 1 } });
  state = data.state;
  render();
}

async function actionSetMap(mapId) {
  state = await api("/api/map/set", { method: "POST", body: { mapId } });
  render();
}

async function actionEquip(itemId) {
  state = await api("/api/equip/equip", { method: "POST", body: { itemId } });
  render();
}

async function actionUnequip(itemId) {
  state = await api("/api/equip/unequip", { method: "POST", body: { itemId } });
  render();
}

async function actionRecycle(itemIds) {
  const data = await api("/api/inventory/recycle", { method: "POST", body: { itemIds } });
  state = data.state;
  render();
}

async function actionStrengthen(slot) {
  const data = await api("/api/forge/strengthen", { method: "POST", body: { slot } });
  state = data.state;
  render();
}

async function actionAutoEquipToggle(enabled) {
  state = await api("/api/settings/auto-equip", { method: "POST", body: { enabled } });
  render();
}

async function actionAutoRecycleToggle(enabled) {
  state = await api("/api/settings/auto-recycle", { method: "POST", body: { enabled } });
  render();
}

async function actionRecycleThresholdUpdate(threshold) {
  state = await api("/api/settings/recycle-threshold", { method: "POST", body: { threshold } });
  render();
}

async function actionAutoDrinkUpdate(hpPct, mpPct) {
  state = await api("/api/settings/auto-drink", { method: "POST", body: { hpPct, mpPct } });
  render();
}

async function actionUseSkillBook(itemId) {
  state = await api("/api/skills/use-book", { method: "POST", body: { itemId } });
  render();
}

async function actionSetActiveSkill(skillId) {
  state = await api("/api/skills/set-active", { method: "POST", body: { skillId } });
  render();
}

async function actionShopBuy(itemId) {
  state = await api("/api/shop/buy", { method: "POST", body: { itemId } });
  render();
}

async function actionWarehouseStore(itemId) {
  state = await api("/api/warehouse/store", { method: "POST", body: { itemId } });
  render();
}

async function actionWarehouseTake(itemId) {
  state = await api("/api/warehouse/take", { method: "POST", body: { itemId } });
  render();
}

function maybeStartTickLoop() {
  console.log("[DEBUG] maybeStartTickLoop 检查:", { ticking, isRunning: state?.runtime?.isRunning });
  if (ticking) {
    console.log("[DEBUG] ticking 为 true，直接返回");
    return;
  }
  if (!state?.runtime?.isRunning) {
    console.log("[DEBUG] isRunning 为 false，不启动循环");
    return;
  }
  ticking = true;
  console.log("[DEBUG] 启动 tick 循环");
  const loop = async () => {
    if (!state?.runtime?.isRunning) {
      console.log("[DEBUG] isRunning 变为 false，停止循环");
      ticking = false;
      return;
    }
    try {
      await actionTick();
    } catch (err) {
      console.error("[DEBUG] tick 错误:", err);
      ticking = false;
      return;
    }
    setTimeout(loop, 1500);
  };
  setTimeout(loop, 200);
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttr(s) {
  return escapeHtml(s).replaceAll(" ", "_");
}

function bindEvents() {
  document.addEventListener("pointerdown", ensureAudioRunning, { once: true });
  $$(".nav-btn").forEach((b) => {
    b.addEventListener("click", () => setActiveTab(b.dataset.tab));
  });
  $$(".chip").forEach((b) => {
    b.addEventListener("click", () => setActiveLogFilter(b.dataset.log));
  });
  $("#btn-clear-log").addEventListener("click", () => {
    displayLogClearedAt = Date.now();
    renderRightLogs();
  });
  $("#btn-create").addEventListener("click", async () => {
    const name = $("#create-name").value.trim();
    const job = $("#create-job").value;
    if (!name) {
      $("#create-hint").textContent = "请输入名字";
      return;
    }
    try {
      state = await api("/api/player/create", { method: "POST", body: { name, job } });
      showCreateModal(false);
      render();
      maybeStartTickLoop();
    } catch (err) {
      $("#create-hint").textContent = err?.message ?? String(err);
    }
  });
  $("#btn-cancel-create")?.addEventListener("click", () => {
    if (state?.player) {
      showCreateModal(false);
    } else if (state?.roles && state.roles.length > 0) {
      // 只要有角色，就可以关闭面板返回到地图或已选角色
      showCreateModal(false);
    } else {
      $("#create-hint").textContent = "请先创建或选择角色";
    }
  });
  $("#btn-logout-from-create")?.addEventListener("click", () => {
    localStorage.removeItem("authToken");
    sessionStorage.removeItem("authToken");
    showCreateModal(false);
    showAuthModal(true);
  });
  $("#btn-start").addEventListener("click", async () => {
    ensureAudioRunning();
    await actionStart();
  });
  $("#btn-stop").addEventListener("click", actionStop);
  $("#btn-reset-player").addEventListener("click", async () => {
    try {
      state = await api("/api/player/reset", { method: "POST" });
      render();
      showCreateModal(true);
    } catch (err) {
      console.error(err);
    }
  });
  $("#btn-town-close")?.addEventListener("click", () => showTownModal(false));
  $("#toggle-settings")?.addEventListener("click", () => {
    const box = $("#card-settings-content");
    if (!box) return;
    const hidden = box.classList.toggle("hidden");
    try {
      localStorage.setItem("settings_collapsed", hidden ? "1" : "0");
    } catch {}
  });
  $("#setting-auto-equip")?.addEventListener("change", async (e) => {
    await actionAutoEquipToggle(e.target.checked);
  });
  $("#setting-auto-recycle")?.addEventListener("change", async (e) => {
    await actionAutoRecycleToggle(e.target.checked);
  });
  $("#setting-sfx")?.addEventListener("change", (e) => {
    writeLocalBool(LS_SFX_ENABLED, e.target.checked);
    if (e.target.checked) ensureAudioRunning();
  });
  $("#setting-recycle-threshold")?.addEventListener("change", async (e) => {
    await actionRecycleThresholdUpdate(e.target.value);
  });
  const syncAutoDrink = async () => {
    const hpPct = Number($("#setting-auto-hp")?.value ?? 0);
    const mpPct = Number($("#setting-auto-mp")?.value ?? 0);
    await actionAutoDrinkUpdate(hpPct, mpPct);
  };
  $("#setting-auto-hp")?.addEventListener("change", syncAutoDrink);
  $("#setting-auto-mp")?.addEventListener("change", syncAutoDrink);
  $("#btn-login").addEventListener("click", async () => {
    const username = $("#auth-username").value.trim();
    const password = $("#auth-password").value.trim();
    const remember = $("#auth-remember").checked;
    try {
      const data = await api("/api/auth/login", { method: "POST", body: { username, password } });
      if (remember) {
        localStorage.setItem("authToken", data.token);
        sessionStorage.removeItem("authToken");
      } else {
        sessionStorage.setItem("authToken", data.token);
        localStorage.removeItem("authToken");
      }
      $("#auth-hint").textContent = "";
      $("#modal-auth").classList.add("hidden");
      await refreshState();
      maybeStartTickLoop();
    } catch (err) {
      $("#auth-hint").textContent = err?.message ?? String(err);
    }
  });
  $("#btn-register").addEventListener("click", async () => {
    const username = $("#auth-username").value.trim();
    const password = $("#auth-password").value.trim();
    const remember = $("#auth-remember").checked;
    try {
      const data = await api("/api/auth/register", { method: "POST", body: { username, password } });
      if (remember) {
        localStorage.setItem("authToken", data.token);
        sessionStorage.removeItem("authToken");
      } else {
        sessionStorage.setItem("authToken", data.token);
        localStorage.removeItem("authToken");
      }
      $("#auth-hint").textContent = "";
      $("#modal-auth").classList.add("hidden");
      await refreshState();
    } catch (err) {
      $("#auth-hint").textContent = err?.message ?? String(err);
    }
  });
}

bindEvents();
setActiveTab("map");
setActiveLogFilter("all");
refreshState().then(() => maybeStartTickLoop());

// 初始化音效系统（解决需要点击才能发声的问题）
window.addEventListener('click', () => {
  ensureAudioRunning();
}, { once: true });

function renderStartStopUI() {
  const running = !!state?.runtime?.isRunning;
  const btn = $("#btn-start");
  if (!btn) return;
  btn.textContent = running ? "停止挂机" : "开始挂机";
  btn.classList.toggle("btn-danger", running);
  const collapsed = localStorage.getItem("settings_collapsed") === "1";
  const box = $("#card-settings-content");
  if (box) box.classList.toggle("hidden", collapsed);
}

// ========== 背包格子布局辅助函数 ==========

// 获取物品图标
function getItemIcon(type, item) {
  if (type === "potion") {
    // 药水：根据恢复属性返回不同图标
    if (item && item.healHp > 0 && item.healMp > 0) return "❤️";  // 万能药（红心）
    if (item && item.healHp > 0) return "🩸";  // HP 药水（血滴）
    if (item && item.healMp > 0) return "🔹";  // MP 药水（蓝钻）
    return "🧪";  // 默认药水（试管）
  }
  if (type === "skill_book") return "📕";  // 红色书籍（更醒目）
  if (type === "equip") return "📦";  // 礼物盒（通用物品）
  return "📦";
}

// 显示物品 Tooltip（半透明小框，鼠标移开消失）
function showItemTooltip(item, slotElement, stackCount = 1) {
  // 移除旧的 tooltip
  hideItemTooltip();
  
  // 创建 tooltip 元素
  const tooltip = document.createElement("div");
  tooltip.id = "item-tooltip";
  tooltip.className = "item-tooltip";
  
  // 填充内容
  const icon = getEquipIcon(item.slot) || getItemIcon(item.type, item);
  const rarityNames = {
    white: "普通",
    green: "优秀",
    blue: "精良",
    purple: "史诗",
    orange: "传说"
  };
  
  let content = `
    <div class="tooltip-header">
      <span class="tooltip-icon">${icon}</span>
      <span class="tooltip-name ${item.rarity}">${item.name}${item.strengthenLevel ? ` +${item.strengthenLevel}` : ""}</span>
    </div>
  `;
  
  if (item.type === "equip") {
    const slotNames = { weapon: "武器", armor: "衣服", helmet: "头盔", necklace: "项链", ring: "戒指", bracelet: "手镯", boots: "鞋子", medal: "勋章" };
    const slotName = slotNames[item.slot] || "装备";
    const stats = item.stats || {};
    content += `
      <div class="tooltip-stats">
        <div>${slotName} · ${rarityNames[item.rarity] || "普通"}</div>
        ${stats.atk ? `<div>攻击：+${stats.atk}</div>` : ""}
        ${stats.def ? `<div>防御：+${stats.def}</div>` : ""}
        ${stats.magic ? `<div>魔法：+${stats.magic}</div>` : ""}
        ${stats.tao ? `<div>道术：+${stats.tao}</div>` : ""}
        ${stats.hpMax ? `<div>生命：+${stats.hpMax}</div>` : ""}
        ${item.score ? `<div style="margin-top:4px;color:#fbbf24;">评分：${item.score}</div>` : ""}
      </div>
    `;
  } else if (item.type === "potion") {
    const potionType = item.healHp > 0 ? (item.healMp > 0 ? "万能药" : "生命药水") : (item.healMp > 0 ? "魔法药水" : "药水");
    content += `
      <div class="tooltip-stats">
        <div>${potionType}</div>
        ${item.healHp ? `<div>恢复生命：+${item.healHp}</div>` : ""}
        ${item.healMp ? `<div>恢复魔法：+${item.healMp}</div>` : ""}
        ${stackCount > 1 ? `<div style="margin-top:4px;color:#fbbf24;">数量：${stackCount}</div>` : ""}
      </div>
    `;
  } else if (item.type === "skill_book") {
    content += `
      <div class="tooltip-stats">
        <div>技能书</div>
        <div>技能：${item.skillName || "未知"}</div>
        ${item.learnLevel ? `<div>需求等级：Lv.${item.learnLevel}</div>` : ""}
        ${stackCount > 1 ? `<div style="margin-top:4px;color:#fbbf24;">数量：${stackCount}</div>` : ""}
      </div>
    `;
  }
  
  tooltip.innerHTML = content;
  document.body.appendChild(tooltip);
  
  // 定位 tooltip
  const rect = slotElement.getBoundingClientRect();
  tooltip.style.left = (rect.right + 8) + "px";
  tooltip.style.top = rect.top + "px";
  
  // 鼠标移开时隐藏
  slotElement.addEventListener("mouseleave", hideItemTooltip, { once: true });
}

// 隐藏物品 Tooltip
function hideItemTooltip() {
  const tooltip = document.getElementById("item-tooltip");
  if (tooltip) {
    tooltip.remove();
  }
}

// 关闭物品详情面板（保留用于兼容）
function closeItemDetail() {
  hideItemTooltip();
  const panel = $("#item-detail-panel");
  if (panel) {
    panel.classList.add("hidden");
  }
  $$("#view-bag .inventory-grid-slot").forEach(s => s.classList.remove("selected"));
}

// 获取装备描述
function getEquipDescription(item) {
  const slotNames = {
    weapon: "武器",
    armor: "衣服",
    helmet: "头盔",
    necklace: "项链",
    ring: "戒指",
    bracelet: "手镯",
    boots: "鞋子",
    medal: "勋章"
  };
  
  const slotName = slotNames[item.slot] || "装备";
  const stats = item.stats || {};
  
  let desc = `${slotName}。`;
  if (stats.atk) desc += `增加攻击力 ${stats.atk}。`;
  if (stats.def) desc += `增加防御力 ${stats.def}。`;
  if (stats.magic) desc += `增加魔法力 ${stats.magic}。`;
  if (stats.tao) desc += `增加道术 ${stats.tao}。`;
  if (stats.hpMax) desc += `增加生命值 ${stats.hpMax}。`;
  
  return desc;
}
