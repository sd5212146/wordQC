import crypto from "node:crypto";
import { loadDropConfigs, rollMonsterDrops, createEquipWithQuality, getQualityRates, pickQuality, getSkillBook, formatEquipStats } from "./dropSystem.js";

const RARITY_ORDER = ["white", "green", "blue", "purple", "orange"];

// 全局游戏配置 (由 server.js 加载)
let GAME_CONFIG = null;

// 初始化游戏配置
export function initGameConfig(config) {
  GAME_CONFIG = config;
}

// 获取配置的辅助函数
function getConfig() {
  return GAME_CONFIG || DEFAULT_CONFIG;
}

// 获取 save 中的配置 (优先使用 GAME_CONFIG，向后兼容 save.config)
function getSaveConfig(save) {
  return GAME_CONFIG || save.config || DEFAULT_CONFIG;
}

const DEFAULT_CONFIG = {
  tickMs: 1500,
  logMax: 300,
  offlineMaxSeconds: 4 * 60 * 60,
  elite: { chance: 0.05, hpMul: 1.6, atkMul: 1.25, defMul: 1.2 },
  jobs: {
    warrior: { name: "战士", hpMax: 120, atk: 8, magic: 0, tao: 0, def: 5 },
    mage: { name: "法师", hpMax: 95, atk: 0, magic: 10, tao: 0, def: 4 },
    taoist: { name: "道士", hpMax: 110, atk: 0, magic: 0, tao: 9, def: 4 }
  },
  jobMpMax: { warrior: 40, mage: 90, taoist: 70 },
  jobRegen: {
    warrior: { hp: 3, mp: 2 },
    mage: { hp: 2, mp: 4 },
    taoist: { hp: 3, mp: 3 }
  },
  jobGrowth: {
    warrior: { hpMax: 12, atk: 3, magic: 0, tao: 0, def: 2, mpMax: 1 },
    mage: { hpMax: 8, atk: 0, magic: 4, tao: 0, def: 1, mpMax: 4 },
    taoist: { hpMax: 10, atk: 0, magic: 0, tao: 4, def: 1, mpMax: 3 }
  },
  potionDefs: {
    hp_small: { name: "小金创药", healHp: 35, healMp: 0 },
    hp_mid: { name: "中金创药", healHp: 120, healMp: 0 },
    mp_small: { name: "小魔法药", healHp: 0, healMp: 40 },
    mp_mid: { name: "中魔法药", healHp: 0, healMp: 140 }
  },
  shopItems: [
    { id: "hp_small", name: "小金创药", priceGold: 25, healHp: 35, healMp: 0 },
    { id: "hp_mid", name: "中金创药", priceGold: 90, healHp: 120, healMp: 0 },
    { id: "mp_small", name: "小魔法药", priceGold: 30, healHp: 0, healMp: 40 },
    { id: "mp_mid", name: "中魔法药", priceGold: 110, healHp: 0, healMp: 140 }
  ],
  shopByTown: {
    novice_village: [
      { id: "nv_hp_small", name: "小金创药", priceGold: 25, healHp: 35 },
      { id: "nv_mp_small", name: "小魔法药", priceGold: 30, healMp: 40 },
      { id: "nv_hp_mid", name: "中金创药", priceGold: 90, healHp: 120 },
      { id: "nv_weapon_green", name: "青铜剑", priceGold: 120, grantEquipSlot: "weapon", grantRarity: "green" },
      { id: "nv_armor_white", name: "布衣", priceGold: 60, grantEquipSlot: "armor", grantRarity: "white" }
    ],
    bichi_city: [
      { id: "bc_hp_mid", name: "中金创药", priceGold: 90, healHp: 120 },
      { id: "bc_mp_mid", name: "中魔法药", priceGold: 110, healMp: 140 },
      { id: "bc_weapon_green", name: "战刃", priceGold: 260, grantEquipSlot: "weapon", grantRarity: "green" },
      { id: "bc_armor_green", name: "皮甲", priceGold: 240, grantEquipSlot: "armor", grantRarity: "green" }
    ],
    mengzhong_city: [
      { id: "mz_hp_big", name: "大金创药", priceGold: 220, healHp: 220 },
      { id: "mz_mp_big", name: "大魔法药", priceGold: 240, healMp: 280 },
      { id: "mz_weapon_blue", name: "战刃·蓝", priceGold: 680, grantEquipSlot: "weapon", grantRarity: "blue" },
      { id: "mz_armor_blue", name: "重甲·蓝", priceGold: 620, grantEquipSlot: "armor", grantRarity: "blue" }
    ],
    fengmo_valley: [
      { id: "fm_hp_big", name: "大金创药", priceGold: 220, healHp: 220 },
      { id: "fm_mp_big", name: "大魔法药", priceGold: 240, healMp: 280 },
      { id: "fm_weapon_purple", name: "炼狱·紫", priceGold: 2600, grantEquipSlot: "weapon", grantRarity: "purple" },
      { id: "fm_armor_purple", name: "战甲·紫", priceGold: 2400, grantEquipSlot: "armor", grantRarity: "purple" }
    ]
  },
  skills: {
    warrior: [
      { id: "slaying", name: "攻杀剑术", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.15, learnLevel: 19, trainNeed: { 1: 40, 2: 120, 3: 260 } },
      { id: "thrusting", name: "刺杀剑术", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.25, learnLevel: 25, trainNeed: { 1: 60, 2: 180, 3: 360 } },
      { id: "halfmoon", name: "半月弯刀", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.18, learnLevel: 28, trainNeed: { 1: 80, 2: 220, 3: 420 } },
      { id: "flame_sword", name: "烈火剑法", type: "active", style: "melee", mpCost: 12, range: 1, dmgMul: 1.6, learnLevel: 35, trainNeed: { 1: 120, 2: 360, 3: 720 } },
      { id: "fencing", name: "基本剑术", type: "passive", style: "passive", mpCost: 0, learnLevel: 7, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { atk: 1 } }
    ],
    mage: [
      { id: "fireball", name: "火球术", type: "active", style: "ranged", mpCost: 4, range: 3, dmgMul: 1.15, learnLevel: 7, trainNeed: { 1: 40, 2: 120, 3: 240 } },
      { id: "lightning", name: "雷电术", type: "active", style: "ranged", mpCost: 10, range: 4, dmgMul: 1.55, learnLevel: 17, trainNeed: { 1: 80, 2: 240, 3: 520 } },
      { id: "firewall", name: "火墙", type: "active", style: "ranged", mpCost: 18, range: 4, dmgMul: 1.25, learnLevel: 24, trainNeed: { 1: 120, 2: 360, 3: 760 } },
      { id: "ice_storm", name: "冰咆哮", type: "active", style: "ranged", mpCost: 28, range: 4, dmgMul: 1.75, learnLevel: 35, trainNeed: { 1: 160, 2: 520, 3: 980 } },
      { id: "magic_mastery", name: "魔法掌握", type: "passive", style: "passive", mpCost: 0, learnLevel: 9, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { atk: 1 } }
    ],
    taoist: [
      { id: "poisoning", name: "施毒术", type: "active", style: "ranged", mpCost: 8, range: 3, dmgMul: 1.05, learnLevel: 14, trainNeed: { 1: 60, 2: 180, 3: 360 } },
      { id: "soul_fireball", name: "灵魂火符", type: "active", style: "ranged", mpCost: 6, range: 3, dmgMul: 1.25, learnLevel: 18, trainNeed: { 1: 80, 2: 240, 3: 520 } },
      { id: "summon", name: "召唤神兽", type: "active", style: "ranged", mpCost: 22, range: 3, dmgMul: 1.4, learnLevel: 35, trainNeed: { 1: 180, 2: 520, 3: 980 } },
      { id: "discipline", name: "修行", type: "passive", style: "passive", mpCost: 0, learnLevel: 7, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { def: 1 } }
    ],
    monster: {
      melee: { id: "claw", name: "撕咬", style: "melee", dmgMul: 1.0 },
      ranged: { id: "shoot", name: "远程攻击", style: "ranged", dmgMul: 1.0 }
    }
  },
  maps: [
    {
      id: "novice_village",
      name: "新手村",
      recommendPower: 0,
      themeColor: "#22c55e",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { down: "bichi_outskirts" },
      monsterAtkMul: 0.65,
      unlockBy: null,
      monsters: [
        { id: "chicken", weight: 35 },
        { id: "deer", weight: 20 },
        { id: "scarecrow", weight: 25 },
        { id: "rake_cat", weight: 20 }
      ],
      drops: { goldMin: 1, goldMax: 2, equipChance: 0.0005, maxRarity: "white", potionChance: 0.08 }
    },
    {
      id: "bichi_city",
      name: "比奇",
      recommendPower: 60,
      themeColor: "#3b82f6",
      isTown: true,
      returnTownId: "bichi_city",
      exits: { up: "bichi_outskirts", left: "wooma_forest", right: "snake_valley", down: "skeleton_cave" },
      unlockBy: { type: "mapClear", mapId: "novice_village" },
      monsters: [],
      drops: { goldMin: 0, goldMax: 0, equipChance: 0, maxRarity: "white", potionChance: 0.0 }
    },
    {
      id: "skeleton_cave",
      name: "骷髅洞",
      recommendPower: 90,
      themeColor: "#94a3b8",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { up: "bichi_city" },
      minLevel: 6,
      unlockBy: null,
      monsters: [
        { id: "skeleton", weight: 70 },
        { id: "axe_skeleton", weight: 30 }
      ],
      drops: { goldMin: 2, goldMax: 7, equipChance: 0.0013, maxRarity: "blue", potionChance: 0.14 }
    },
    {
      id: "bichi_outskirts",
      name: "比奇城郊",
      recommendPower: 0,
      themeColor: "#06b6d4",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { up: "novice_village", down: "bichi_city" },
      monsterAtkMul: 0.65,
      unlockBy: null,
      monsters: [
        { id: "half_orc", weight: 30 },
        { id: "multi_hook_cat", weight: 25 },
        { id: "forest_snowman", weight: 20 },
        { id: "rake_cat", weight: 25 }
      ],
      drops: { goldMin: 1, goldMax: 3, equipChance: 0.0008, maxRarity: "green", potionChance: 0.1 }
    },
    {
      id: "mengzhong_path",
      name: "盟重小径",
      recommendPower: 120,
      themeColor: "#14b8a6",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { left: "snake_valley", right: "mengzhong_city", down: "bairimen" },
      minLevel: 6,
      unlockBy: { type: "mapClear", mapId: "snake_valley" },
      monsters: [
        { id: "wolf", weight: 40 },
        { id: "sand_worm", weight: 30 },
        { id: "shell_nipper", weight: 30 }
      ],
      drops: { goldMin: 2, goldMax: 7, equipChance: 0.0013, maxRarity: "blue", potionChance: 0.12 }
    },
    {
      id: "mengzhong_city",
      name: "盟重",
      recommendPower: 220,
      themeColor: "#f59e0b",
      isTown: true,
      returnTownId: "mengzhong_city",
      exits: { left: "mengzhong_path", right: "sabac_castle", down: "pig_cave_1" },
      unlockBy: { type: "mapClear", mapId: "mengzhong_path" },
      monsters: [],
      drops: { goldMin: 0, goldMax: 0, equipChance: 0, maxRarity: "white", potionChance: 0.0 }
    },
    {
      id: "wooma_forest",
      name: "沃玛森林",
      recommendPower: 180,
      themeColor: "#16a34a",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { right: "bichi_city" },
      minLevel: 8,
      unlockBy: { type: "mapClear", mapId: "bichi_outskirts" },
      monsters: [
        { id: "forest_snowman", weight: 25 },
        { id: "wooma_soldier", weight: 45 },
        { id: "wooma_fighter", weight: 30 }
      ],
      drops: { goldMin: 3, goldMax: 9, equipChance: 0.0015, maxRarity: "blue", potionChance: 0.14 }
    },
    {
      id: "luye_plain",
      name: "鹿野平原",
      recommendPower: 160,
      themeColor: "#10b981",
      isTown: false,
      returnTownId: "bichi_city",
      neighbors: ["bichi_outskirts"],
      unlockBy: { type: "mapClear", mapId: "bichi_outskirts" },
      monsters: [
        { id: "deer", weight: 30 },
        { id: "wolf", weight: 40 },
        { id: "multi_hook_cat", weight: 30 }
      ],
      drops: { goldMin: 3, goldMax: 8, equipChance: 0.0015, maxRarity: "blue", potionChance: 0.14 }
    },
    {
      id: "snake_valley",
      name: "毒蛇山谷",
      recommendPower: 220,
      themeColor: "#8b5cf6",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { left: "bichi_city", right: "mengzhong_path", up: "mine" },
      minLevel: 10,
      unlockBy: { type: "mapClear", mapId: "wooma_forest" },
      monsters: [
        { id: "red_snake", weight: 55 },
        { id: "tiger_snake", weight: 45 }
      ],
      drops: { goldMin: 3, goldMax: 10, equipChance: 0.0015, maxRarity: "blue", potionChance: 0.15 }
    },
    {
      id: "mengzhong_outskirts",
      name: "盟重土城郊外",
      recommendPower: 320,
      themeColor: "#eab308",
      isTown: false,
      returnTownId: "mengzhong_city",
      neighbors: ["mengzhong_city", "mine"],
      minLevel: 12,
      unlockBy: { type: "mapClear", mapId: "snake_valley" },
      monsters: [
        { id: "wolf", weight: 30 },
        { id: "sand_worm", weight: 35 },
        { id: "shell_nipper", weight: 35 }
      ],
      drops: { goldMin: 4, goldMax: 14, equipChance: 0.0018, maxRarity: "blue", potionChance: 0.16 }
    },
    {
      id: "mine",
      name: "矿洞",
      recommendPower: 380,
      themeColor: "#64748b",
      isTown: false,
      returnTownId: "bichi_city",
      exits: { down: "snake_valley", up: "molong_city" },
      minLevel: 15,
      unlockBy: { type: "mapClear", mapId: "snake_valley" },
      monsters: [
        { id: "zombie", weight: 70 },
        { id: "zombie_king", weight: 30 }
      ],
      drops: { goldMin: 5, goldMax: 18, equipChance: 0.002, maxRarity: "blue", potionChance: 0.18 }
    },
    {
      id: "molong_city",
      name: "魔龙城",
      recommendPower: 760,
      themeColor: "#ef4444",
      isTown: false,
      returnTownId: "fengmo_valley",
      exits: { down: "mine", right: "fengmo_valley" },
      minLevel: 28,
      unlockBy: null,
      monsters: [
        { id: "evil_tongs", weight: 55 },
        { id: "zuma_statue", weight: 45 }
      ],
      drops: { goldMin: 7, goldMax: 26, equipChance: 0.0022, maxRarity: "purple", potionChance: 0.22 }
    },
    {
      id: "bairimen",
      name: "白日门",
      recommendPower: 420,
      themeColor: "#22c55e",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { up: "mengzhong_path", down: "chiyue_canyon" },
      minLevel: 18,
      unlockBy: null,
      monsters: [
        { id: "wolf", weight: 35 },
        { id: "sand_worm", weight: 35 },
        { id: "zombie", weight: 30 }
      ],
      drops: { goldMin: 5, goldMax: 18, equipChance: 0.002, maxRarity: "blue", potionChance: 0.18 }
    },
    {
      id: "sabac_castle",
      name: "沙巴克",
      recommendPower: 520,
      themeColor: "#fca5a5",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { left: "mengzhong_city", right: "zuma_temple", up: "centipede_cave" },
      minLevel: 22,
      unlockBy: null,
      monsters: [
        { id: "red_boar", weight: 45 },
        { id: "black_boar", weight: 35 },
        { id: "moth", weight: 20 }
      ],
      drops: { goldMin: 6, goldMax: 22, equipChance: 0.0022, maxRarity: "purple", potionChance: 0.2 }
    },
    {
      id: "pig_cave_1",
      name: "猪洞",
      recommendPower: 520,
      themeColor: "#fb7185",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { up: "mengzhong_city" },
      minLevel: 20,
      unlockBy: null,
      monsters: [
        { id: "red_boar", weight: 45 },
        { id: "black_boar", weight: 35 },
        { id: "moth", weight: 20 }
      ],
      drops: { goldMin: 6, goldMax: 22, equipChance: 0.0022, maxRarity: "purple", potionChance: 0.2 }
    },
    {
      id: "centipede_cave",
      name: "蜈蚣洞",
      recommendPower: 680,
      themeColor: "#84cc16",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { down: "sabac_castle" },
      minLevel: 26,
      unlockBy: { type: "mapClear", mapId: "pig_cave_1" },
      monsters: [
        { id: "centipede", weight: 35 },
        { id: "bee", weight: 25 },
        { id: "tongs", weight: 25 },
        { id: "evil_tongs", weight: 15 }
      ],
      drops: { goldMin: 7, goldMax: 26, equipChance: 0.0024, maxRarity: "purple", potionChance: 0.22 }
    },
    {
      id: "zuma_temple",
      name: "祖玛",
      recommendPower: 920,
      themeColor: "#6366f1",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { left: "sabac_castle" },
      minLevel: 32,
      unlockBy: { type: "mapClear", mapId: "sabac_castle" },
      monsters: [
        { id: "zuma_statue", weight: 40 },
        { id: "zuma_guardian", weight: 35 },
        { id: "zuma_archer", weight: 25 }
      ],
      drops: { goldMin: 8, goldMax: 30, equipChance: 0.0026, maxRarity: "purple", potionChance: 0.24 }
    },
    {
      id: "fengmo_valley",
      name: "封魔谷",
      recommendPower: 1150,
      themeColor: "#f43f5e",
      isTown: true,
      returnTownId: "fengmo_valley",
      exits: { left: "molong_city", up: "cangyue_island" },
      minLevel: 35,
      unlockBy: { type: "mapClear", mapId: "molong_city" },
      monsters: [],
      drops: { goldMin: 0, goldMax: 0, equipChance: 0, maxRarity: "white", potionChance: 0.0 }
    },
    {
      id: "chiyue_canyon",
      name: "赤月",
      recommendPower: 1450,
      themeColor: "#f97316",
      isTown: false,
      returnTownId: "mengzhong_city",
      exits: { up: "bairimen" },
      minLevel: 45,
      unlockBy: { type: "mapClear", mapId: "bairimen" },
      monsters: [
        { id: "moon_spider", weight: 35 },
        { id: "kiss_spider", weight: 35 },
        { id: "fang_spider", weight: 30 }
      ],
      drops: { goldMin: 12, goldMax: 45, equipChance: 0.0024, maxRarity: "orange", potionChance: 0.28 }
    },
    {
      id: "cangyue_island",
      name: "苍月岛",
      recommendPower: 1750,
      themeColor: "#a855f7",
      isTown: false,
      returnTownId: "fengmo_valley",
      exits: { down: "fengmo_valley", right: "niumo_cave" },
      minLevel: 50,
      unlockBy: null,
      monsters: [
        { id: "bone_demon", weight: 70 },
        { id: "moon_spider", weight: 15 },
        { id: "fang_spider", weight: 15 }
      ],
      drops: { goldMin: 14, goldMax: 55, equipChance: 0.0022, maxRarity: "orange", potionChance: 0.3 }
    },
    {
      id: "niumo_cave",
      name: "牛魔洞",
      recommendPower: 1900,
      themeColor: "#7c3aed",
      isTown: false,
      returnTownId: "fengmo_valley",
      exits: { left: "cangyue_island" },
      minLevel: 55,
      unlockBy: null,
      monsters: [
        { id: "minotaur_warrior", weight: 65 },
        { id: "minotaur_mage", weight: 35 }
      ],
      drops: { goldMin: 14, goldMax: 55, equipChance: 0.0022, maxRarity: "orange", potionChance: 0.3 }
    }
  ],
  monsters: {
    chicken: { name: "鸡", level: 1, hp: 18, atk: 4, def: 0, exp: 1, range: 1 },
    deer: { name: "鹿", level: 1, hp: 22, atk: 5, def: 1, exp: 1, range: 1 },
    scarecrow: { name: "稻草人", level: 2, hp: 30, atk: 6, def: 1, exp: 1, range: 1 },
    rake_cat: { name: "钉耙猫", level: 3, hp: 34, atk: 7, def: 2, exp: 2, range: 1 },
    half_orc: { name: "半兽人", level: 5, hp: 55, atk: 10, def: 3, exp: 3, range: 1 },
    multi_hook_cat: { name: "多钩猫", level: 5, hp: 50, atk: 10, def: 2, exp: 3, range: 1 },
    forest_snowman: { name: "森林雪人", level: 6, hp: 70, atk: 12, def: 3, exp: 4, range: 1 },
    skeleton: { name: "骷髅", level: 7, hp: 90, atk: 14, def: 4, exp: 5, range: 1 },
    axe_skeleton: { name: "骷髅战士", level: 8, hp: 110, atk: 16, def: 5, exp: 6, range: 1, skillBookChance: 0.0003 },
    wooma_soldier: { name: "沃玛战士", level: 10, hp: 120, atk: 18, def: 6, exp: 6, range: 1, skillBookChance: 0.0004 },
    wooma_fighter: { name: "沃玛勇士", level: 12, hp: 150, atk: 22, def: 7, exp: 7, range: 1, skillBookChance: 0.0006 },
    red_snake: { name: "红蛇", level: 13, hp: 160, atk: 24, def: 8, exp: 8, range: 1, skillBookChance: 0.0005 },
    tiger_snake: { name: "虎蛇", level: 15, hp: 185, atk: 26, def: 9, exp: 9, range: 1, skillBookChance: 0.0005 },
    wolf: { name: "狼", level: 16, hp: 200, atk: 28, def: 10, exp: 9, range: 1 },
    sand_worm: { name: "沙虫", level: 17, hp: 220, atk: 30, def: 10, exp: 10, range: 1 },
    shell_nipper: { name: "盔甲虫", level: 18, hp: 240, atk: 31, def: 11, exp: 10, range: 1 },
    zombie: { name: "僵尸", level: 20, hp: 280, atk: 34, def: 12, exp: 11, range: 1 },
    zombie_king: { name: "尸王", level: 25, hp: 520, atk: 46, def: 16, exp: 18, range: 1, skillBookChance: 0.002 },
    red_boar: { name: "红野猪", level: 28, hp: 520, atk: 52, def: 18, exp: 20, range: 1, skillBookChance: 0.0008 },
    black_boar: { name: "黑野猪", level: 29, hp: 560, atk: 56, def: 19, exp: 21, range: 1, skillBookChance: 0.0008 },
    moth: { name: "楔蛾", level: 30, hp: 420, atk: 45, def: 16, exp: 18, range: 1 },
    centipede: { name: "蜈蚣", level: 32, hp: 620, atk: 60, def: 20, exp: 22, range: 1 },
    bee: { name: "跳跳蜂", level: 33, hp: 520, atk: 58, def: 19, exp: 22, range: 1 },
    tongs: { name: "钳虫", level: 34, hp: 720, atk: 66, def: 22, exp: 24, range: 1 },
    evil_tongs: { name: "邪恶钳虫", level: 36, hp: 900, atk: 78, def: 25, exp: 28, range: 1, skillBookChance: 0.0012 },
    zuma_statue: { name: "祖玛雕像", level: 40, hp: 1100, atk: 92, def: 28, exp: 32, range: 1, skillBookChance: 0.001 },
    zuma_guardian: { name: "祖玛卫士", level: 41, hp: 1250, atk: 98, def: 30, exp: 34, range: 1, skillBookChance: 0.001 },
    zuma_archer: { name: "祖玛弓箭手", level: 42, hp: 980, atk: 90, def: 26, exp: 34, range: 4, skillBookChance: 0.001 },
    hongmo_boar_guard: { name: "虹魔猪卫", level: 45, hp: 1500, atk: 110, def: 34, exp: 40, range: 1, skillBookChance: 0.0011 },
    hongmo_scorpion_guard: { name: "虹魔蝎卫", level: 46, hp: 1600, atk: 116, def: 35, exp: 42, range: 1, skillBookChance: 0.0011 },
    moon_spider: { name: "月魔蜘蛛", level: 50, hp: 1750, atk: 128, def: 38, exp: 50, range: 1, skillBookChance: 0.001 },
    kiss_spider: { name: "花吻蜘蛛", level: 51, hp: 1650, atk: 126, def: 37, exp: 50, range: 1, skillBookChance: 0.001 },
    fang_spider: { name: "钢牙蜘蛛", level: 52, hp: 1900, atk: 135, def: 40, exp: 56, range: 1, skillBookChance: 0.001 },
    bone_demon: { name: "骨魔", level: 55, hp: 2100, atk: 148, def: 44, exp: 62, range: 1, skillBookChance: 0.001 },
    minotaur_warrior: { name: "牛魔战士", level: 56, hp: 2250, atk: 156, def: 46, exp: 66, range: 1, skillBookChance: 0.001 },
    minotaur_mage: { name: "牛魔法师", level: 57, hp: 1950, atk: 150, def: 42, exp: 66, range: 4, skillBookChance: 0.001 }
  },
  equipSlots: ["weapon", "armor", "shoes", "head", "ring", "bracelet", "necklace", "medal"],
  equipSlotNames: { weapon: "武器", armor: "装甲", shoes: "脚部", head: "头部", ring: "戒指", bracelet: "护腕", necklace: "项链", medal: "勋章" },
  rarityWeights: { white: 700, green: 220, blue: 70, purple: 9, orange: 1 },
  rarityName: { white: "白", green: "绿", blue: "蓝", purple: "紫", orange: "橙" },
  equipBaseBySlot: {}, // 不再使用统一的基础值，改为每个装备独立属性
  // 热血传奇经典装备固定属性表（白装状态）
  equipmentStats: {
    // ==================== 武器篇 ====================
    // 初级武器 (白色)
    "木剑": { atk: 4, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "乌木剑": { atk: 8, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "短剑": { atk: 6, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "铁剑": { atk: 5, magic: 0, tao: 0, def: 1, hpMax: 0 },
    "青铜剑": { atk: 7, magic: 0, tao: 0, def: 1, hpMax: 0 },
    "鹤嘴锄": { atk: 10, magic: 0, tao: 0, def: 0, hpMax: 0 },
    // 中级武器 (绿色/蓝色)
    "凝霜": { atk: 13, magic: 0, tao: 0, def: 2, hpMax: 0 },
    "修罗": { atk: 0, magic: 12, tao: 0, def: 0, hpMax: 0 },
    "炼狱": { atk: 25, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "井中月": { atk: 22, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "魔杖": { atk: 5, magic: 10, tao: 0, def: 0, hpMax: 0 },
    "银蛇": { atk: 14, magic: 0, tao: 12, def: 0, hpMax: 0 },
    "铜锤": { atk: 12, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "无极棍": { atk: 16, magic: 0, tao: 14, def: 0, hpMax: 0 },
    // 高级武器 (紫色)
    "裁决之杖": { atk: 30, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "骨玉权杖": { atk: 6, magic: 2, tao: 0, def: 0, hpMax: 0 },
    "龙纹剑": { atk: 8, magic: 0, tao: 3, def: 0, hpMax: 0 },
    "血饮": { atk: 5, magic: 12, tao: 0, def: 0, hpMax: 0 },
    "逍遥扇": { atk: 5, magic: 0, tao: 4, def: 0, hpMax: 0 },
    "命运之刃": { atk: 12, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "封魔剑": { atk: 18, magic: 0, tao: 0, def: 0, hpMax: 0 },
    // 顶级武器 (橙色)
    "屠龙": { atk: 35, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "嗜魂法杖": { atk: 6, magic: 2, tao: 0, def: 0, hpMax: 0 },
    "怒斩": { atk: 26, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "龙牙": { atk: 10, magic: 3, tao: 0, def: 0, hpMax: 0 },
    "开天": { atk: 40, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "镇天": { atk: 7, magic: 5, tao: 0, def: 0, hpMax: 0 },
    "玄天": { atk: 8, magic: 0, tao: 5, def: 0, hpMax: 0 },
    "赤血魔剑": { atk: 20, magic: 10, tao: 0, def: 0, hpMax: 0 },
    
    // ==================== 衣服篇 ====================
    // 初级盔甲 (白色)
    "布衣": { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 8 },
    "轻型盔甲": { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 15 },
    "中型盔甲": { atk: 0, magic: 0, tao: 0, def: 4, hpMax: 20 },
    "重盔甲": { atk: 0, magic: 0, tao: 0, def: 5, hpMax: 25 },
    "魔法长袍": { atk: 0, magic: 1, tao: 0, def: 3, hpMax: 12 },
    "灵魂战衣": { atk: 0, magic: 0, tao: 1, def: 3, hpMax: 12 },
    // 中级盔甲 (绿色/蓝色)
    "战神盔甲": { atk: 1, magic: 0, tao: 0, def: 6, hpMax: 30 },
    "幽灵战衣": { atk: 0, magic: 1, tao: 0, def: 5, hpMax: 25 },
    "恶魔长袍": { atk: 0, magic: 2, tao: 0, def: 4, hpMax: 20 },
    "地狱火焰": { atk: 0, magic: 2, tao: 0, def: 5, hpMax: 25 },
    "天蝉法袍": { atk: 0, magic: 3, tao: 0, def: 5, hpMax: 30 },
    // 高级盔甲 (紫色)
    "天魔神甲": { atk: 1, magic: 0, tao: 0, def: 12, hpMax: 50 },
    "霓裳羽衣": { atk: 0, magic: 2, tao: 0, def: 9, hpMax: 40 },
    "天师长袍": { atk: 0, magic: 0, tao: 2, def: 9, hpMax: 40 },
    "雷霆战甲": { atk: 1, magic: 0, tao: 0, def: 12, hpMax: 50 },
    "烈焰魔衣": { atk: 0, magic: 3, tao: 0, def: 12, hpMax: 45 },
    "光芒道袍": { atk: 0, magic: 0, tao: 3, def: 12, hpMax: 45 },
    // 顶级盔甲 (橙色)
    "凤天魔甲": { atk: 2, magic: 3, tao: 3, def: 12, hpMax: 60 },
    "凰天魔衣": { atk: 2, magic: 3, tao: 3, def: 12, hpMax: 60 },
    "星王战甲": { atk: 2, magic: 0, tao: 0, def: 15, hpMax: 80 },
    "预言战甲": { atk: 0, magic: 4, tao: 4, def: 13, hpMax: 70 },
    
    // ==================== 鞋子篇 ====================
    // 初级鞋子 (白色)
    "草鞋": { atk: 0, magic: 0, tao: 0, def: 1, hpMax: 5 },
    "布鞋": { atk: 0, magic: 0, tao: 0, def: 1, hpMax: 8 },
    "鹿皮靴": { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 10 },
    "兽皮靴": { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 12 },
    // 中级鞋子 (绿色/蓝色)
    "皮靴": { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 15 },
    "追风靴": { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 18 },
    "疾风靴": { atk: 0, magic: 0, tao: 0, def: 4, hpMax: 20 },
    // 高级鞋子 (紫色)
    "铁靴": { atk: 0, magic: 0, tao: 0, def: 5, hpMax: 25 },
    "战靴": { atk: 0, magic: 0, tao: 0, def: 5, hpMax: 30 },
    "紫绸靴": { atk: 0, magic: 1, tao: 0, def: 4, hpMax: 25 },
    "避魂靴": { atk: 0, magic: 1, tao: 0, def: 5, hpMax: 30 },
    // 顶级鞋子 (橙色)
    "星王战靴": { atk: 0, magic: 0, tao: 0, def: 8, hpMax: 50 },
    "传说魔靴": { atk: 0, magic: 2, tao: 0, def: 6, hpMax: 40 },
    
    // ==================== 头盔篇 ====================
    // 初级头盔 (白色)
    "青铜头盔": { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 10 },
    "魔法头盔": { atk: 0, magic: 1, tao: 0, def: 2, hpMax: 8 },
    "道士头盔": { atk: 0, magic: 0, tao: 1, def: 2, hpMax: 8 },
    "骷髅头盔": { atk: 0, magic: 0, tao: 0, def: 4, hpMax: 12 },
    "虎齿项链": { atk: 0, magic: 0, tao: 2, def: 0, hpMax: 0 },
    // 中级头盔 (绿色/蓝色)
    "战士头盔": { atk: 1, magic: 0, tao: 0, def: 4, hpMax: 15 },
    "黑铁头盔": { atk: 0, magic: 0, tao: 0, def: 5, hpMax: 20 },
    "黄金头盔": { atk: 1, magic: 0, tao: 0, def: 5, hpMax: 18 },
    // 高级头盔 (紫色)
    "圣战头盔": { atk: 2, magic: 0, tao: 0, def: 5, hpMax: 25 },
    "法神头盔": { atk: 0, magic: 1, tao: 0, def: 4, hpMax: 20 },
    "天尊头盔": { atk: 0, magic: 0, tao: 1, def: 4, hpMax: 20 },
    // 顶级头盔 (橙色)
    "星王战盔": { atk: 3, magic: 0, tao: 0, def: 7, hpMax: 35 },
    "星王法盔": { atk: 0, magic: 3, tao: 0, def: 6, hpMax: 30 },
    "星王道盔": { atk: 0, magic: 0, tao: 3, def: 6, hpMax: 30 },
    "预言头盔": { atk: 1, magic: 2, tao: 2, def: 6, hpMax: 35 },
    
    // ==================== 戒指篇 ====================
    // 初级戒指 (白色)
    "古铜戒指": { atk: 1, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "银戒指": { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "珍珠戒指": { atk: 0, magic: 1, tao: 0, def: 0, hpMax: 0 },
    "道德戒指": { atk: 0, magic: 0, tao: 1, def: 0, hpMax: 0 },
    "玻璃戒指": { atk: 0, magic: 0, tao: 0, def: 1, hpMax: 5 },
    // 中级戒指 (绿色/蓝色)
    "红宝石戒指": { atk: 0, magic: 2, tao: 0, def: 0, hpMax: 0 },
    "生铁戒指": { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 15 },
    "珊瑚戒指": { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "蓝翡翠戒指": { atk: 0, magic: 2, tao: 0, def: 1, hpMax: 0 },
    // 高级戒指 (紫色)
    "龙之戒指": { atk: 3, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "力量戒指": { atk: 4, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "紫金戒指": { atk: 0, magic: 3, tao: 0, def: 0, hpMax: 0 },
    "泰坦戒指": { atk: 0, magic: 0, tao: 3, def: 0, hpMax: 0 },
    "心灵戒指": { atk: 0, magic: 0, tao: 2, def: 1, hpMax: 10 },
    "三眼戒指": { atk: 0, magic: 2, tao: 0, def: 1, hpMax: 10 },
    // 顶级戒指 (橙色)
    "圣战戒指": { atk: 5, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "法神戒指": { atk: 0, magic: 4, tao: 0, def: 0, hpMax: 0 },
    "天尊戒指": { atk: 0, magic: 0, tao: 4, def: 0, hpMax: 0 },
    "狂战戒指": { atk: 6, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "混世戒指": { atk: 4, magic: 4, tao: 0, def: 0, hpMax: 0 },
    "太极戒指": { atk: 0, magic: 3, tao: 3, def: 0, hpMax: 0 },
    "战神戒指": { atk: 5, magic: 0, tao: 0, def: 1, hpMax: 15 },
    "圣魔戒指": { atk: 0, magic: 5, tao: 0, def: 0, hpMax: 0 },
    "真魂戒指": { atk: 0, magic: 3, tao: 3, def: 1, hpMax: 20 },
    
    // ==================== 手镯篇 ====================
    // 初级手镯 (白色)
    "铁手镯": { atk: 1, magic: 0, tao: 0, def: 1, hpMax: 3 },
    "铜手镯": { atk: 0, magic: 1, tao: 0, def: 0, hpMax: 0 },
    "银手镯": { atk: 0, magic: 0, tao: 1, def: 0, hpMax: 0 },
    "金手镯": { atk: 1, magic: 0, tao: 0, def: 1, hpMax: 5 },
    "凤凰明珠": { atk: 0, magic: 0, tao: 1, def: 1, hpMax: 5 },
    // 中级手镯 (绿色/蓝色)
    "道士手镯": { atk: 0, magic: 0, tao: 2, def: 1, hpMax: 5 },
    "黑檀手镯": { atk: 0, magic: 1, tao: 0, def: 1, hpMax: 5 },
    "蓝宝石手镯": { atk: 0, magic: 2, tao: 0, def: 0, hpMax: 0 },
    "玛瑙手镯": { atk: 1, magic: 0, tao: 0, def: 1, hpMax: 8 },
    "辟邪手镯": { atk: 0, magic: 0, tao: 1, def: 2, hpMax: 10 },
    "夏普儿手镯": { atk: 1, magic: 0, tao: 0, def: 2, hpMax: 10 },
    // 高级手镯 (紫色)
    "龙之手镯": { atk: 2, magic: 0, tao: 0, def: 2, hpMax: 10 },
    "骑士手镯": { atk: 3, magic: 0, tao: 0, def: 1, hpMax: 10 },
    "心灵手镯": { atk: 0, magic: 0, tao: 2, def: 2, hpMax: 15 },
    "三眼护腕": { atk: 0, magic: 2, tao: 0, def: 2, hpMax: 15 },
    "思贝尔手镯": { atk: 0, magic: 3, tao: 0, def: 1, hpMax: 10 },
    "铃铛手镯": { atk: 0, magic: 0, tao: 3, def: 1, hpMax: 10 },
    // 顶级手镯 (橙色)
    "圣战手镯": { atk: 4, magic: 0, tao: 0, def: 2, hpMax: 15 },
    "法神手镯": { atk: 0, magic: 4, tao: 0, def: 1, hpMax: 10 },
    "天尊手镯": { atk: 0, magic: 0, tao: 4, def: 1, hpMax: 10 },
    "狂战护腕": { atk: 5, magic: 0, tao: 0, def: 2, hpMax: 20 },
    "混世手镯": { atk: 3, magic: 3, tao: 0, def: 1, hpMax: 15 },
    "太极手镯": { atk: 0, magic: 3, tao: 3, def: 1, hpMax: 15 },
    "战神手镯": { atk: 4, magic: 0, tao: 0, def: 3, hpMax: 20 },
    "圣魔手镯": { atk: 0, magic: 5, tao: 0, def: 1, hpMax: 15 },
    "真魂手镯": { atk: 0, magic: 3, tao: 3, def: 2, hpMax: 25 },
    
    // ==================== 项链篇 ====================
    // 初级项链 (白色)
    "传统项链": { atk: 1, magic: 0, tao: 0, def: 0, hpMax: 0 },
    "蓝色水晶项链": { atk: 0, magic: 1, tao: 0, def: 0, hpMax: 0 },
    "黄色水晶项链": { atk: 0, magic: 0, tao: 1, def: 0, hpMax: 0 },
    "魔鬼项链": { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 },
    // 中级项链 (绿色/蓝色)
    "记忆项链": { atk: 0, magic: 0, tao: 2, def: 1, hpMax: 10 },
    "绿色项链": { atk: 2, magic: 0, tao: 0, def: 1, hpMax: 0 },
    "灵魂项链": { atk: 0, magic: 0, tao: 2, def: 0, hpMax: 0 },
    "生命项链": { atk: 0, magic: 2, tao: 0, def: 0, hpMax: 0 },
    "如意项链": { atk: 0, magic: 0, tao: 2, def: 1, hpMax: 10 },
    "狂风项链": { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 },
    // 高级项链 (紫色)
    "圣战项链": { atk: 3, magic: 0, tao: 0, def: 1, hpMax: 0 },
    "法神项链": { atk: 0, magic: 3, tao: 0, def: 0, hpMax: 0 },
    "天尊项链": { atk: 0, magic: 0, tao: 3, def: 0, hpMax: 0 },
    "白虎齿项链": { atk: 0, magic: 0, tao: 3, def: 1, hpMax: 15 },
    "幸运项链": { atk: 1, magic: 1, tao: 1, def: 0, hpMax: 0 },
    "技巧项链": { atk: 2, magic: 0, tao: 0, def: 1, hpMax: 0 },
    "探测项链": { atk: 1, magic: 1, tao: 1, def: 1, hpMax: 10 },
    // 顶级项链 (橙色)
    "雷霆项链": { atk: 4, magic: 0, tao: 0, def: 2, hpMax: 0 },
    "烈焰项链": { atk: 0, magic: 4, tao: 0, def: 1, hpMax: 0 },
    "光芒项链": { atk: 0, magic: 0, tao: 4, def: 1, hpMax: 0 },
    "强化雷霆项链": { atk: 5, magic: 0, tao: 0, def: 2, hpMax: 10 },
    "强化烈焰项链": { atk: 0, magic: 5, tao: 0, def: 1, hpMax: 10 },
    "强化光芒项链": { atk: 0, magic: 0, tao: 5, def: 1, hpMax: 10 },
    "圣魔项链": { atk: 0, magic: 5, tao: 0, def: 1, hpMax: 15 },
    "真魂项链": { atk: 0, magic: 3, tao: 3, def: 2, hpMax: 20 },
    
    // ==================== 勋章篇 ====================
    // 初级勋章 (白色)
    "铜勋章": { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 15 },
    "铁勋章": { atk: 1, magic: 0, tao: 0, def: 2, hpMax: 15 },
    "银勋章": { atk: 0, magic: 1, tao: 0, def: 2, hpMax: 15 },
    "金勋章": { atk: 0, magic: 0, tao: 1, def: 2, hpMax: 15 },
    // 中级勋章 (绿色/蓝色)
    "荣誉勋章 1 号": { atk: 1, magic: 0, tao: 0, def: 3, hpMax: 20 },
    "荣誉勋章 5 号": { atk: 0, magic: 1, tao: 0, def: 3, hpMax: 20 },
    "荣誉勋章 10 号": { atk: 0, magic: 0, tao: 1, def: 3, hpMax: 20 },
    "祈祷徽章": { atk: 0, magic: 1, tao: 1, def: 2, hpMax: 25 },
    // 高级勋章 (紫色)
    "荣誉勋章 23 号": { atk: 2, magic: 0, tao: 0, def: 4, hpMax: 30 },
    "荣誉勋章 33 号": { atk: 0, magic: 2, tao: 0, def: 4, hpMax: 30 },
    "荣誉勋章 43 号": { atk: 0, magic: 0, tao: 2, def: 4, hpMax: 30 },
    "圣战纹章": { atk: 3, magic: 0, tao: 0, def: 4, hpMax: 35 },
    "法神纹章": { atk: 0, magic: 3, tao: 0, def: 4, hpMax: 35 },
    "天尊纹章": { atk: 0, magic: 0, tao: 3, def: 4, hpMax: 35 },
    // 顶级勋章 (橙色)
    "银星勋章": { atk: 2, magic: 2, tao: 2, def: 5, hpMax: 40 },
    "荣誉勋章 53 号": { atk: 4, magic: 0, tao: 0, def: 5, hpMax: 45 },
    "荣誉勋章 54 号": { atk: 0, magic: 4, tao: 0, def: 5, hpMax: 45 },
    "荣誉勋章 55 号": { atk: 0, magic: 0, tao: 4, def: 5, hpMax: 45 }
  },
  // 装备品质倍率（参考热血传奇装备等级差距）
  equipRarityMultiplier: {
    white: 1.0,   // 普通装备：基础属性
    green: 1.25,  // 优秀装备：+25%
    blue: 1.6,    // 精良装备：+60%（如裁决、骨玉等）
    purple: 2.2,  // 史诗装备：+120%（如屠龙、嗜魂等）
    orange: 3.0   // 传说装备：+200%（如开天、镇天、玄天）
  },
  strengthen: {
    baseGoldCost: 30,
    goldCostGrowth: 1.25,
    maxLevel: 10,
    successRate: 1.0,
    gainBySlot: {
      weapon: { atk: 2, def: 0, hpMax: 0 },
      armor: { atk: 0, def: 2, hpMax: 10 },
      shoes: { atk: 0, def: 1, hpMax: 6 },
      head: { atk: 0, def: 2, hpMax: 8 },
      ring: { atk: 1, def: 0, hpMax: 0 },
      bracelet: { atk: 1, def: 1, hpMax: 4 },
      necklace: { atk: 1, def: 0, hpMax: 0 },
      medal: { atk: 0, def: 2, hpMax: 12 }
    }
  },
  mapClearRule: {
    killsToClear: 15
  }
};

/**
 * @deprecated 使用 loadSave() 直接加载存档，不再使用此函数
 */
export function createNewSave({ config = DEFAULT_CONFIG } = {}) {
  console.warn("createNewSave is deprecated, use loadSave() instead");
  return {
    accounts: {},  // 支持多角色
    config: JSON.parse(JSON.stringify(config)),
    runtime: {
      isRunning: false,
      lastTickAt: Date.now(),
      lastBattle: null,
      board: null,
      lastFrame: null,
      pendingReviveAt: null,
      pendingReviveTownId: null,
      sessions: {}
    },
    logs: []
  };
}

export function migrateSave(save) {
  if (!save || typeof save !== "object") return false;
  
  let changed = false;
  
  // 智能合并 config：保留现有配置，只补全缺失项
  if (!save.config) {
    // 如果没有 config，创建默认配置
    save.config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    changed = true;
  } else {
    // 如果有 config，递归补全缺失项（不覆盖已有项）
    function deepMerge(target, source) {
      for (const key in source) {
        if (!(key in target)) {
          target[key] = JSON.parse(JSON.stringify(source[key]));
          changed = true;
        } else if (typeof source[key] === "object" && source[key] !== null && !Array.isArray(source[key])) {
          if (typeof target[key] !== "object" || target[key] === null) {
            target[key] = JSON.parse(JSON.stringify(source[key]));
            changed = true;
          } else {
            deepMerge(target[key], source[key]);
          }
        }
      }
    }
    deepMerge(save.config, DEFAULT_CONFIG);
  }

  // 强制确保关键数组/对象包含所有默认项
  for (const key of ["equipSlots"]) {
    if (Array.isArray(DEFAULT_CONFIG[key])) {
      if (!Array.isArray(save.config[key])) {
        save.config[key] = [...DEFAULT_CONFIG[key]];
        changed = true;
      } else {
        for (const item of DEFAULT_CONFIG[key]) {
          if (!save.config[key].includes(item)) {
            save.config[key].push(item);
            changed = true;
          }
        }
      }
    }
  }
  // 特殊处理 equipSlotNames, strengthen.gainBySlot 等对象
  if (DEFAULT_CONFIG.equipSlotNames) {
    save.config.equipSlotNames ??= {};
    for (const k in DEFAULT_CONFIG.equipSlotNames) {
      if (!(k in save.config.equipSlotNames)) {
        save.config.equipSlotNames[k] = DEFAULT_CONFIG.equipSlotNames[k];
        changed = true;
      }
    }
  }
  if (DEFAULT_CONFIG.strengthen?.gainBySlot) {
    save.config.strengthen ??= {};
    save.config.strengthen.gainBySlot ??= {};
    for (const k in DEFAULT_CONFIG.strengthen.gainBySlot) {
      if (!(k in save.config.strengthen.gainBySlot)) {
        save.config.strengthen.gainBySlot[k] = JSON.parse(JSON.stringify(DEFAULT_CONFIG.strengthen.gainBySlot[k]));
        changed = true;
      }
    }
  }

  // 如果存在旧版的全局 progress，尝试迁移到玩家身上（如果玩家存在）
  if (save.progress && save.player) {
    save.player.progress = save.progress;
    delete save.progress;
    changed = true;
  }
  // 如果玩家不存在但有全局 progress，也删除它，防止影响新角色
  if (save.progress && !save.player) {
    delete save.progress;
    changed = true;
  }

  // 对所有账号的玩家进行迁移
  if (save.accounts) {
    for (const u in save.accounts) {
      const acc = save.accounts[u];
      // 迁移单角色到多角色列表
      if (acc.player && !acc.roles) {
        acc.roles = [acc.player];
        delete acc.player;
        changed = true;
      }
      if (!acc.roles) {
        acc.roles = [];
        changed = true;
      }
      // 迁移所有角色
      for (const p of acc.roles) {
        if (migratePlayer(save, p)) changed = true;
      }
    }
  }

  save.runtime ??= { isRunning: false, lastTickAt: Date.now() };
  if (!("lastBattle" in save.runtime)) {
    save.runtime.lastBattle = null;
    changed = true;
  }
  if (!("board" in save.runtime)) {
    save.runtime.board = null;
    changed = true;
  }
  if (!("lastFrame" in save.runtime)) {
    save.runtime.lastFrame = null;
    changed = true;
  }
  if (!("pendingReviveAt" in save.runtime)) {
    save.runtime.pendingReviveAt = null;
    changed = true;
  }
  if (!("pendingReviveTownId" in save.runtime)) {
    save.runtime.pendingReviveTownId = null;
    changed = true;
  }
  
  return changed;
}

function migratePlayer(save, p) {
  let changed = false;
  if (!p) return false;
  
  if (!Array.isArray(p.inventory)) {
    p.inventory = [];
    changed = true;
  }
  if (!Array.isArray(p.warehouse)) {
    p.warehouse = [];
    changed = true;
  }
  p.settings ??= {};
  if (p.settings.autoEquip == null) {
    p.settings.autoEquip = true;
    changed = true;
  }
  if (p.settings.autoRecycle == null) {
    p.settings.autoRecycle = false;
    changed = true;
  }
  if (!RARITY_ORDER.includes(String(p.settings.recycleRarityThreshold ?? ""))) {
    p.settings.recycleRarityThreshold = "white";
    changed = true;
  }
  if (p.settings.autoHpPotionPct == null) {
    p.settings.autoHpPotionPct = 35;
    changed = true;
  }
  if (p.settings.autoMpPotionPct == null) {
    p.settings.autoMpPotionPct = 35;
    changed = true;
  }
  p.settings.autoHpPotionPct = clampPct(p.settings.autoHpPotionPct);
  p.settings.autoMpPotionPct = clampPct(p.settings.autoMpPotionPct);
  
  if (p.mpMax == null) {
    p.mpMax = save.config.jobMpMax?.[p.job] ?? 50;
    changed = true;
  }
  if (p.mp == null) {
    p.mp = p.mpMax;
    changed = true;
  }
  
  p.skills ??= { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  if (!("activeId" in p.skills)) {
    p.skills.activeId = null;
    changed = true;
  }
  p.skills.activeIds ??= [];
  p.skills.passiveIds ??= [];
  p.skills.levels ??= {};
  
  p.progress ??= { currentMapId: save.config.maps[0].id, mapKills: {}, mapCleared: {} };
  
  p.equipped ??= {};
  for (const slot of save.config.equipSlots) {
    if (!(slot in p.equipped)) {
      p.equipped[slot] = null;
      changed = true;
    }
  }
  
  // 重新计算派生属性以确保正确性
  recomputeDerivedStatsForPlayer(save, p);
  
  return changed;
}

function recomputeDerivedStatsForPlayer(save, player) {
  if (!player) return;
  refreshEquipScoresForPlayer(save, player);
  const jobDef = save.config.jobs[player.job];
  const g = (save.config.jobGrowth?.[player.job] ?? DEFAULT_CONFIG.jobGrowth?.[player.job]) ?? {};
  const lv = Math.max(1, Number(player.level ?? 1));
  const lvStep = lv - 1;
  const base = {
    hpMax: jobDef.hpMax + lvStep * Number(g.hpMax ?? 8),
    atk: (jobDef.atk ?? 0) + lvStep * Number(g.atk ?? 2),
    magic: (jobDef.magic ?? 0) + lvStep * Number(g.magic ?? 2),
    tao: (jobDef.tao ?? 0) + lvStep * Number(g.tao ?? 2),
    def: jobDef.def + lvStep * Number(g.def ?? 1)
  };

  let extraHpMax = 0;
  let extraAtk = 0;
  let extraMagic = 0;
  let extraTao = 0;
  let extraDef = 0;

  for (const slot of save.config.equipSlots) {
    const eq = player.equipped[slot];
    if (!eq) continue;
    extraHpMax += eq.stats.hpMax ?? 0;
    extraAtk += eq.stats.atk ?? 0;
    extraMagic += eq.stats.magic ?? 0;
    extraTao += eq.stats.tao ?? 0;
    extraDef += eq.stats.def ?? 0;
    const gain = save.config.strengthen.gainBySlot[slot];
    if (gain && eq.strengthenLevel > 0) {
      extraHpMax += (gain.hpMax ?? 0) * eq.strengthenLevel;
      extraAtk += (gain.atk ?? 0) * eq.strengthenLevel;
      extraDef += (gain.def ?? 0) * eq.strengthenLevel;
    }
  }

  const prevHpMax = player.hpMax;
  player.hpMax = base.hpMax + extraHpMax;
  const mainKey = player.job === "mage" ? "magic" : player.job === "taoist" ? "tao" : "atk";
  const baseMain = base[mainKey] ?? 0;
  const extraMain =
    mainKey === "magic" ? extraMagic : mainKey === "tao" ? extraTao : extraAtk;
  player.atk = baseMain + extraMain + getPassiveBonusForPlayer(save, player, "atk");
  player.def = base.def + extraDef;
  if (player.hp > player.hpMax || player.hp === prevHpMax) player.hp = player.hpMax;
  const baseMpMax = save.config.jobMpMax?.[player.job] ?? 50;
  player.mpMax = Math.max(1, Math.floor(baseMpMax + lvStep * Number(g.mpMax ?? 0)));
  if (player.mp > player.mpMax) player.mp = player.mpMax;
}

function refreshEquipScoresForPlayer(save, p) {
  if (!p) return;
  const job = p.job;
  const seen = new Map();
  for (const it of p.inventory ?? []) {
    if (it?.type !== "equip" || !it.id) continue;
    seen.set(it.id, it);
  }
  for (const slot of save.config.equipSlots ?? DEFAULT_CONFIG.equipSlots) {
    const eq = p.equipped?.[slot];
    if (eq?.type !== "equip" || !eq.id) continue;
    seen.set(eq.id, eq);
  }
  for (const it of seen.values()) {
    it.score = calcEquipScoreForJob(job, it.stats);
  }
}

function getPassiveBonusForPlayer(save, p, key) {
  if (!p) return 0;
  const ids = p.skills?.passiveIds ?? [];
  let sum = 0;
  for (const id of ids) {
    const s = (save.config.skills?.[p.job] ?? []).find((x) => x.id === id);
    if (!s || s.type !== "passive") continue;
    if (p.level < (s.learnLevel ?? 1)) continue;
    const bonus = s.bonus ?? {};
    const lv = Math.max(1, Math.min(3, Number(p.skills?.levels?.[id]?.level ?? 1)));
    sum += Number(bonus[key] ?? 0) * lv;
  }
  return sum;
}

export function canEnterMap(save, player, mapId) {
  if (!player) return { ok: true };
  const map = save.config.maps.find((m) => m.id === mapId);
  if (!map) return { ok: false, reason: "地图不存在" };
  if (player.level < (map.minLevel ?? 0)) {
    return { ok: false, reason: `等级不足（需 Lv.${map.minLevel}）` };
  }
  const power = calcPowerScore(player.atk, player.def, player.hpMax);
  if (power < (map.recommendPower ?? 0)) {
    return { ok: false, reason: "战力不足" };
  }
  if (!map.unlockBy) return { ok: true };
  if (map.unlockBy.type === "mapClear") {
    const cleared = !!player.progress?.mapCleared?.[map.unlockBy.mapId];
    return cleared ? { ok: true } : { ok: false, reason: "未解锁" };
  }
  return { ok: false, reason: "未解锁" };
}

function listAdjacentMapIds(config, fromMapId) {
  const maps = config?.maps ?? [];
  const from = maps.find((m) => m?.id === fromMapId);
  if (!from) return new Set();
  const neighbors = new Set();

  const exits = from.exits ?? null;
  if (exits && typeof exits === "object") {
    for (const id of Object.values(exits)) {
      if (id) neighbors.add(String(id));
    }
  }

  return neighbors;
}

function canTravelToMap(save, player, mapId) {
  if (!player) return { ok: true };
  const curId = player.progress?.currentMapId;
  if (!curId) return { ok: true };
  if (curId === mapId) return { ok: true };
  const neighbors = listAdjacentMapIds(save.config, curId);
  return neighbors.has(mapId) ? { ok: true } : { ok: false, reason: "需要逐步前往" };
}

export function createPlayer(save, { name, job }) {
  const jobDef = save.config.jobs[job];
  if (!jobDef) throw new Error("未知职业");
  
  const trimmedName = String(name || "").trim().slice(0, 12);
  if (!trimmedName) throw new Error("角色名字不能为空");

  // 检查重名（全局）
  if (save.accounts) {
    for (const u in save.accounts) {
      if (save.accounts[u].player && save.accounts[u].player.name === trimmedName) {
        throw new Error("角色名字已存在，请换一个名字");
      }
    }
  }

  const playerId = crypto.randomUUID();
  const player = {
    id: playerId,
    name: trimmedName,
    job,
    level: 1,
    exp: 0,
    expToNext: 50,
    hpMax: jobDef.hpMax,
    hp: jobDef.hpMax,
    mpMax: (save.config.jobMpMax?.[job] ?? 50),
    mp: (save.config.jobMpMax?.[job] ?? 50),
    atk: jobDef.atk ?? 0,
    def: jobDef.def,
    gold: 50,
    yuanbao: 0,
    settings: {
      autoEquip: true,
      autoRecycle: false,
      recycleRarityThreshold: "white",
      autoHpPotionPct: 35,
      autoMpPotionPct: 35
    },
    skills: {
      activeId: null,
      activeIds: [],
      passiveIds: [],
      levels: {}
    },
    progress: {
      currentMapId: "novice_village",
      mapKills: {},
      mapCleared: {}
    },
    equipped: Object.fromEntries((save.config.equipSlots ?? DEFAULT_CONFIG.equipSlots).map((s) => [s, null])),
    inventory: [],
    warehouse: []
  };
  pushLog(save, "system", `创建角色：${player.name}（${jobDef.name}）`);
  // 初始装备：按职业主属性提供新手套装
  const starter = createStarterEquip(save.config, job);
  for (const it of Object.values(starter)) {
    player.inventory.push(it);
    equipItemDirect(save, player, it.id);
  }
  // 初始药品：3 瓶小金疮药
  for (let i = 0; i < 3; i++) {
    player.inventory.push({
      id: crypto.randomUUID(),
      type: "potion",
      potionId: "hp_small",
      name: "小金创药",
      healHp: 35,
      healMp: 0
    });
  }
  const mapId = player.progress.currentMapId;
  const map = save.config.maps.find((m) => m.id === mapId) ?? save.config.maps[0];
  if (save.runtime && map) {
    save.runtime.board = initBoardForMap(save, player, map);
    save.runtime.lastFrame = null;
    pushLog(save, "system", `进入场景：${map.name}（6x6）`);
  }
  return player;
}

export function warehouseStore(save, player, itemId) {
  if (!player) throw new Error("未创建角色");
  const inv = player.inventory ?? [];
  const idx = inv.findIndex((it) => it?.id === itemId);
  if (idx < 0) throw new Error("物品不存在");
  const it = inv[idx];
  if (it?.type === "equip" && it.equipped) throw new Error("已穿戴装备无法存放");
  inv.splice(idx, 1);
  if (!Array.isArray(player.warehouse)) player.warehouse = [];
  player.warehouse.push(it);
  pushLog(save, "system", `存入仓库：${it?.name ?? it?.type ?? "物品"}`);
}

export function warehouseTake(save, player, itemId) {
  if (!player) throw new Error("未创建角色");
  if (!Array.isArray(player.warehouse)) player.warehouse = [];
  const idx = player.warehouse.findIndex((it) => it?.id === itemId);
  if (idx < 0) throw new Error("物品不存在");
  const it = player.warehouse[idx];
  player.warehouse.splice(idx, 1);
  if (!Array.isArray(player.inventory)) player.inventory = [];
  player.inventory.push(it);
  pushLog(save, "system", `取出仓库：${it?.name ?? it?.type ?? "物品"}`);
}

export function setRunning(save, player, isRunning) {
  save.runtime.isRunning = !!isRunning;
  save.runtime.lastTickAt = Date.now();
  console.log("[DEBUG] setRunning:", { isRunning: save.runtime.isRunning, ts: save.runtime.lastTickAt });
  if (save.runtime.isRunning && player?.settings?.autoEquip) {
    autoEquipBestAllSlots(save, player);
  }
  pushLog(save, "system", isRunning ? "开始挂机" : "停止挂机");
}

export function setCurrentMap(save, player, mapId) {
  if (!player) throw new Error("未创建角色");
  const travel = canTravelToMap(save, player, mapId);
  if (!travel.ok) throw new Error(travel.reason);
  const gate = canEnterMap(save, player, mapId);
  if (!gate.ok) throw new Error(gate.reason);
  player.progress.currentMapId = mapId;
  const map = save.config.maps.find((m) => m.id === mapId);
  if (save.runtime) {
    save.runtime.board = null;
    save.runtime.lastFrame = null;
    if (player && map) {
      save.runtime.board = initBoardForMap(save, player, map);
      pushLog(save, "system", `进入场景：${map.name}（6x6）`);
    }
  }
  pushLog(save, "system", `前往地图：${map?.name ?? mapId}`);
}

export function settleOffline(save, player) {
  if (!player) return { ticks: 0, logs: [] };
  const now = Date.now();
  const dtSeconds = Math.max(0, Math.floor((now - save.runtime.lastTickAt) / 1000));
  const maxSeconds = save.config.offlineMaxSeconds ?? DEFAULT_CONFIG.offlineMaxSeconds;
  const effectiveSeconds = Math.min(dtSeconds, maxSeconds);
  const tickMs = save.config.tickMs ?? DEFAULT_CONFIG.tickMs;
  const ticks = Math.floor((effectiveSeconds * 1000) / tickMs);
  if (ticks <= 0) {
    save.runtime.lastTickAt = now;
    return { ticks: 0, logs: [] };
  }
  const result = runTicks(save, player, ticks);
  pushLog(save, "system", `离线结算：${effectiveSeconds}s，补算 ${ticks} 次`);
  save.runtime.lastTickAt = now;
  return result;
}

export function runTicks(save, player, count) {
  if (!player) return { ticks: 0, logs: [] };
  const beforeLogIndex = save.logs.length;
  const ticks = Math.max(0, Math.min(Number(count) || 0, 200));
  console.log("[DEBUG] runTicks:", { count, ticks, isRunning: save.runtime.isRunning });
  for (let i = 0; i < ticks; i += 1) {
    if (!save.runtime.isRunning) {
      console.log("[DEBUG] runTicks 中 isRunning 为 false，中断");
      break;
    }
    runSingleTick(save, player);
  }
  save.runtime.lastTickAt = Date.now();
  const newLogs = save.logs.slice(beforeLogIndex);
  return { ticks, logs: newLogs };
}

export function recycleItems(save, player, itemIds) {
  if (!player) throw new Error("未创建角色");
  const idSet = new Set((itemIds ?? []).map(String));
  const before = player.inventory.length;
  let goldGain = 0;
  let skippedEquipped = 0;
  player.inventory = player.inventory.filter((it) => {
    if (!idSet.has(it.id)) return true;
    if (it.locked) return true;
    if (it.equipped) {
      skippedEquipped += 1;
      return true;
    }
    goldGain += getRecycleValue(save.config, it);
    return false;
  });
  const removed = before - player.inventory.length;
  if (removed <= 0) return { removed: 0, goldGain: 0 };
  player.gold += goldGain;
  pushLog(save, "loot", `回收装备 ${removed} 件，获得金币 +${goldGain}`);
  if (skippedEquipped > 0) {
    pushLog(save, "system", `已跳过穿戴中的装备 ${skippedEquipped} 件`);
  }
  return { removed, goldGain };
}

export function strengthenEquipped(save, player, slot) {
  if (!player) throw new Error("未创建角色");
  const validSlots = save.config.equipSlots || DEFAULT_CONFIG.equipSlots;
  if (!validSlots.includes(slot)) throw new Error(`未知部位: ${slot}`);
  const eq = player.equipped[slot];
  if (!eq) throw new Error("该部位未穿戴装备");
  const maxLevel = save.config.strengthen.maxLevel ?? DEFAULT_CONFIG.strengthen.maxLevel;
  if (eq.strengthenLevel >= maxLevel) throw new Error("已达强化上限");
  const cost = getStrengthenCost(save.config, eq.strengthenLevel + 1);
  if (player.gold < cost) throw new Error("金币不足");
  player.gold -= cost;
  const success = Math.random() < (save.config.strengthen.successRate ?? 1.0);
  if (!success) {
    pushLog(save, "system", `强化失败：${save.config.equipSlotNames[slot]}（消耗金币 ${cost}）`);
    return { success: false, cost };
  }
  eq.strengthenLevel += 1;
  recomputeDerivedStatsForPlayer(save, player);
  pushLog(save, "system", `强化成功：${save.config.equipSlotNames[slot]} +${eq.strengthenLevel}（消耗金币 ${cost}）`);
  return { success: true, cost };
}

export function equipItem(save, player, itemId) {
  if (!player) throw new Error("未创建角色");
  equipItemDirect(save, player, itemId);
}

function equipItemDirect(save, player, itemId) {
  const item = player.inventory.find((it) => it.id === itemId);
  if (!item) throw new Error("物品不存在");
  if (item.type !== "equip") throw new Error("不是装备");
  const slot = item.slot;
  const validSlots = save.config.equipSlots || DEFAULT_CONFIG.equipSlots;
  if (!validSlots.includes(slot)) {
    console.error(`Equip failed: slot ${slot} not in`, validSlots);
    throw new Error(`未知部位: ${slot}`);
  }
  const prev = player.equipped[slot];
  if (prev?.id === item.id) {
    pushLog(save, "system", `已穿戴：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
    return;
  }
  player.equipped[slot] = item;
  item.equipped = true;
  if (prev) prev.equipped = false;
  recomputeDerivedStatsForPlayer(save, player);
  pushLog(save, "system", `穿戴：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
}

export function unequipItem(save, player, itemId) {
  if (!player) throw new Error("未创建角色");
  const item = player.inventory.find((it) => it.id === itemId);
  if (!item) throw new Error("物品不存在");
  if (item.type !== "equip") throw new Error("不是装备");
  const slot = item.slot;
  const validSlots = save.config.equipSlots || DEFAULT_CONFIG.equipSlots;
  if (!validSlots.includes(slot)) throw new Error(`未知部位: ${slot}`);
  const cur = player.equipped[slot];
  if (!cur || cur.id !== item.id) throw new Error("该装备未穿戴");
  player.equipped[slot] = null;
  item.equipped = false;
  recomputeDerivedStatsForPlayer(save, player);
  pushLog(save, "system", `卸下：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
}

export function setAutoEquip(save, player, enabled) {
  if (!player) throw new Error("未创建角色");
  player.settings.autoEquip = !!enabled;
  if (player.settings.autoEquip) {
    autoEquipBestAllSlots(save, player);
  }
  pushLog(save, "system", player.settings.autoEquip ? "开启自动换装" : "关闭自动换装");
}

export function setAutoRecycle(save, player, enabled) {
  if (!player) throw new Error("未创建角色");
  player.settings.autoRecycle = !!enabled;
  pushLog(save, "system", player.settings.autoRecycle ? "开启自动回收" : "关闭自动回收");
}

export function setRecycleRarityThreshold(save, player, threshold) {
  if (!player) throw new Error("未创建角色");
  const t = String(threshold ?? "");
  if (!RARITY_ORDER.includes(t)) throw new Error("未知品质");
  player.settings.recycleRarityThreshold = t;
  const name = save.config.rarityName?.[t] ?? t;
  pushLog(save, "system", `自动回收品质：${name}及以下`);
}

export function setAutoDrink(save, player, hpPct, mpPct) {
  if (!player) throw new Error("未创建角色");
  player.settings.autoHpPotionPct = clampPct(hpPct);
  player.settings.autoMpPotionPct = clampPct(mpPct);
  pushLog(
    save,
    "system",
    `自动喝药阈值：HP<${player.settings.autoHpPotionPct}% / MP<${player.settings.autoMpPotionPct}%`
  );
}

function runSingleTick(save, player) {
  if (!player) return;
  const mapId = player.progress?.currentMapId ?? save.config.maps[0].id;
  const map = save.config.maps.find((m) => m.id === mapId) ?? save.config.maps[0];
  const board = ensureBoard(save, player, map);
  console.log("[DEBUG] runSingleTick:", { 
    mapId: map.id, 
    boardExists: !!board, 
    playerExists: !!board?.player,
    monstersCount: board?.monsters?.length ?? 0,
    isRunning: save.runtime?.isRunning 
  });
  
  // 关键检查
  if (!board || !board.player) {
    console.error("[CRITICAL ERROR] runSingleTick: board or board.player is undefined after ensureBoard!");
    console.error("[CRITICAL ERROR] Details:", {
      mapId: map.id,
      boardType: typeof board,
      boardPlayer: board?.player,
      runtimeExists: !!save.runtime
    });
    return;
  }
  
  const frame = { id: crypto.randomUUID(), ts: Date.now(), mapId: map.id, events: [] };

  // 处理延迟复活
  if (save.runtime?.pendingReviveAt && Date.now() >= save.runtime.pendingReviveAt) {
    const townId = save.runtime.pendingReviveTownId ?? map.returnTownId ?? map.id;
    const town = save.config.maps.find((m) => m.id === townId && m);
    player.hp = player.hpMax;
    save.runtime.isRunning = false;
    save.runtime.pendingReviveAt = null;
    save.runtime.pendingReviveTownId = null;
    frame.events.push({ type: "revive", entityId: "player", at: { x: board.player.x, y: board.player.y } });
    if (town) {
      player.progress.currentMapId = town.id;
      save.runtime.board = initBoardForMap(save, player, town);
      save.runtime.lastFrame = null;
      pushLog(save, "system", `已返回主城：${town.name}`);
    }
  }

  applyRegen(player);
  maybeAutoDrinkUsingInventory(save, player);
  maybeAutoDrinkInTown(save, player, map);
  // 每个 tick 都检查是否需要更换装备（确保始终穿戴最好的）
  if (player?.settings?.autoEquip) {
    autoEquipBestAllSlots(save, player);
  }
  tickMonstersMove(save, player, map, board, frame);
  tickPlayerMove(save, player, map, board, frame);
  tickPlayerAttack(save, player, map, board, frame);
  if (!save.runtime.isRunning) {
    save.runtime.lastFrame = frame;
    return;
  }
  tickMonstersAttack(save, player, map, board, frame);

  save.runtime.lastFrame = frame;
}

function applyRegen(p) {
  const regen = { hp: 1, mp: 1 };
  p.hp = Math.min(p.hpMax, p.hp + Math.max(0, Number(regen.hp ?? 0)));
  p.mp = Math.min(p.mpMax, p.mp + Math.max(0, Number(regen.mp ?? 0)));
}

function ensureBoard(save, player, map) {
  if (!save.runtime) save.runtime = { isRunning: false, lastTickAt: Date.now(), lastBattle: null, board: null, lastFrame: null };
  const board = save.runtime.board;
  if (board && board.mapId === map.id && board.width === 6 && board.height === 6) {
    board.targetCount = Math.min(5, Number(board.targetCount ?? 5)); // 最多 5 个怪物
    if (board.monsters.length > board.targetCount) {
      board.monsters = board.monsters.slice(0, board.targetCount);
    }
    // 如果怪物数量不足，立即补充（不受 5 秒间隔限制）
    if (board.monsters.length < board.targetCount) {
      replenishMonsters(save, player, map, board, true, board.targetCount - board.monsters.length);
    }
    return board;
  }
  const next = initBoardForMap(save, player, map);
  save.runtime.board = next;
  save.runtime.lastFrame = null;
  pushLog(save, "system", `进入场景：${map.name}（6x6）`);
  return next;
}

function initBoardForMap(save, player, map) {
  const width = 6;
  const height = 6;
  const playerPos = { x: randInt(0, width - 1), y: randInt(0, height - 1) };
  const targetCount = 5; // 场景最多 5 个怪物
  const board = {
    id: crypto.randomUUID(),
    mapId: map.id,
    width,
    height,
    player: { x: playerPos.x, y: playerPos.y },
    monsters: [],
    targetCount,
    lastSpawnAt: 0
  };
  // 进入新场景时立刻刷新 3 只怪物（不是满的）
  replenishMonsters(save, player, map, board, true, 3);
  return board;
}

function replenishMonsters(save, player, map, board, forceFull = false, spawnCount = 1) {
  // 防御性检查
  if (!board || !board.player) {
    console.error("[ERROR] replenishMonsters: board or board.player is undefined", { 
      boardExists: !!board,
      playerExists: !!board?.player,
      mapId: map?.id 
    });
    return;
  }
  
  const cap = Math.max(1, Number(board.targetCount ?? 5)); // 使用 board.targetCount，默认 5
  const now = Date.now();
  const intervalMs = 7000;
  // 初次进入或 forceFull 时可以刷多只；之后每 6.5s 少于上限则刷 1 只
  const canSpawn =
    forceFull ? board.monsters.length < cap : (board.monsters.length < cap && (now - (board.lastSpawnAt ?? 0)) >= intervalMs);
  
  if (!canSpawn) return;
  const occupied = new Set([posKey(board.player.x, board.player.y)]);
  for (const m of board.monsters) occupied.add(posKey(m.x, m.y));

  // 批量刷新怪物
  for (let i = 0; i < spawnCount; i++) {
    if (board.monsters.length >= cap) break;
    
    const monsterId = pickWeighted(map.monsters);
    const def = save.config.monsters[monsterId];
    if (!def) continue;
    
    // 重新计算占用位置
    const currentOccupied = new Set([posKey(board.player.x, board.player.y)]);
    for (const m of board.monsters) currentOccupied.add(posKey(m.x, m.y));
    
    const { x, y } = pickEmptyPosAway(board, currentOccupied, board.player.x, board.player.y, 3);
    if (x == null) break;
    
    const range = Math.max(1, Number(def.range ?? 1));
    const eliteCfg = save.config.elite ?? DEFAULT_CONFIG.elite;
    const isElite = !map.isTown && Math.random() < Number(eliteCfg?.chance ?? 0.05);
    const hpMul = isElite ? Number(eliteCfg?.hpMul ?? 1.6) : 1;
    const atkMul = isElite ? Number(eliteCfg?.atkMul ?? 1.25) : 1;
    const defMul = isElite ? Number(eliteCfg?.defMul ?? 1.2) : 1;
    const name = isElite ? `精英${def.name}` : def.name;
    const ent = {
      id: crypto.randomUUID(),
      monsterId,
      name,
      level: def.level,
      hpMax: Math.max(1, Math.floor(Number(def.hp) * hpMul)),
      hp: Math.max(1, Math.floor(Number(def.hp) * hpMul)),
      atk: Math.max(1, Math.floor(Number(def.atk) * atkMul)),
      def: Math.max(0, Math.floor(Number(def.def) * defMul)),
      exp: def.exp,
      range,
      isRanged: range > 1,
      isElite,
      skillBookChance: Number(def.skillBookChance ?? 0),
      x,
      y
    };
    board.monsters.push(ent);
  }
  board.lastSpawnAt = now;
}

function selectPlayerActiveSkill(save, p) {
  const list = (save.config.skills?.[p.job] ?? []).filter((s) => s.type === "active");
  const learned = new Set(p.skills?.activeIds ?? []);
  const chosenId = p.skills?.activeId;
  const chosen = chosenId && learned.has(chosenId) ? list.find((s) => s.id === chosenId) : null;
  const fallback = list.find((s) => learned.has(s.id)) ?? null;
  const prefer = chosen ?? fallback;
  if (!prefer) return { id: "basic_attack", name: "普攻", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.0, learnLevel: 1, trainNeed: { 1: 0, 2: 0, 3: 0 }, level: 1 };
  if (p.level < (prefer.learnLevel ?? 1)) {
    return { id: "basic_attack", name: "普攻", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.0, learnLevel: 1, trainNeed: { 1: 0, 2: 0, 3: 0 }, level: 1 };
  }
  const lvInfo = p.skills?.levels?.[prefer.id] ?? { level: 1, exp: 0 };
  const lvl = Math.max(1, Math.min(3, Number(lvInfo.level ?? 1)));
  const extraMul = 1 + (lvl - 1) * 0.12;
  return { ...prefer, dmgMul: (prefer.dmgMul ?? 1.0) * extraMul, level: lvl, exp: lvInfo.exp ?? 0 };
}

function tickPlayerMove(save, player, map, board, frame) {
  if (map?.isTown) return;
  
  // 防御性检查
  if (!board || !board.player) {
    console.error("[ERROR] tickPlayerMove: board or board.player is undefined", { 
      boardExists: !!board, 
      playerExists: !!board?.player,
      mapId: map?.id 
    });
    return;
  }
  
  const skill = selectPlayerActiveSkill(save, player);
  const targetInRange = pickNearestMonster(board, board.player.x, board.player.y, skill.range);
  if (targetInRange) {
    // 在攻击范围内，有 15% 概率随机移动一格
    if (Math.random() < 0.15) {
      performRandomMove(board, frame);
    }
    return;
  }
  const nearest = pickNearestMonster(board, board.player.x, board.player.y, Infinity);
  if (!nearest) {
    const dirs = [
      { x: 1, y: 0 },
      { x: -1, y: 0 },
      { x: 0, y: 1 },
      { x: 0, y: -1 }
    ];
    for (let i = dirs.length - 1; i > 0; i -= 1) {
      const j = randInt(0, i);
      const tmp = dirs[i];
      dirs[i] = dirs[j];
      dirs[j] = tmp;
    }
    for (const d of dirs) {
      const to = { x: board.player.x + d.x, y: board.player.y + d.y };
      if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
      const from = { x: board.player.x, y: board.player.y };
      board.player.x = to.x;
      board.player.y = to.y;
      frame.events.push({ type: "move", entityId: "player", from, to: { x: to.x, y: to.y } });
      break;
    }
    return;
  }
  const step = stepToward(board.player.x, board.player.y, nearest.x, nearest.y);
  if (!step) return;
  const occupied = new Set(board.monsters.map((m) => posKey(m.x, m.y)));
  const candidates = [step, step.alt].filter(Boolean);
  for (const to of candidates) {
    if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
    const keyTo = posKey(to.x, to.y);
    if (occupied.has(keyTo)) continue;
    const from = { x: board.player.x, y: board.player.y };
    board.player.x = to.x;
    board.player.y = to.y;
    frame.events.push({ type: "move", entityId: "player", from, to: { x: to.x, y: to.y } });
    break;
  }
}

// 随机移动一格
function performRandomMove(board, frame) {
  const dirs = [
    { x: 1, y: 0 },
    { x: -1, y: 0 },
    { x: 0, y: 1 },
    { x: 0, y: -1 }
  ];
  
  // 打乱方向顺序
  for (let i = dirs.length - 1; i > 0; i -= 1) {
    const j = randInt(0, i);
    const tmp = dirs[i];
    dirs[i] = dirs[j];
    dirs[j] = tmp;
  }
  
  const occupied = new Set(board.monsters.map((m) => posKey(m.x, m.y)));
  
  for (const d of dirs) {
    const to = { x: board.player.x + d.x, y: board.player.y + d.y };
    if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
    const keyTo = posKey(to.x, to.y);
    if (occupied.has(keyTo)) continue;
    
    const from = { x: board.player.x, y: board.player.y };
    board.player.x = to.x;
    board.player.y = to.y;
    frame.events.push({ type: "move", entityId: "player", from, to: { x: to.x, y: to.y } });
    break;
  }
}

function pickEmptyPos(board, occupied) {
  const tries = 50;
  for (let i = 0; i < tries; i += 1) {
    const x = randInt(0, board.width - 1);
    const y = randInt(0, board.height - 1);
    const key = posKey(x, y);
    if (!occupied.has(key)) return { x, y };
  }
  for (let y = 0; y < board.height; y += 1) {
    for (let x = 0; x < board.width; x += 1) {
      const key = posKey(x, y);
      if (!occupied.has(key)) return { x, y };
    }
  }
  return { x: null, y: null };
}

function pickEmptyPosAway(board, occupied, px, py, minDist) {
  const attempt = (d, tries) => {
    for (let i = 0; i < tries; i += 1) {
      const x = randInt(0, board.width - 1);
      const y = randInt(0, board.height - 1);
      const key = posKey(x, y);
      if (occupied.has(key)) continue;
      const dist = Math.abs(x - px) + Math.abs(y - py);
      if (dist >= d) return { x, y };
    }
    return null;
  };
  const first = attempt(Math.max(0, Number(minDist ?? 0)), 80);
  if (first) return first;
  const second = attempt(2, 80);
  if (second) return second;
  return pickEmptyPos(board, occupied);
}

function tickMonstersMove(save, player, map, board, frame) {
  // 防御性检查
  if (!board || !board.player) {
    console.error("[ERROR] tickMonstersMove: board or board.player is undefined", { 
      boardExists: !!board,
      playerExists: !!board?.player,
      mapId: map?.id 
    });
    return;
  }
  
  console.log("[DEBUG] tickMonstersMove:", {
    monstersCount: board.monsters?.length ?? 0,
    playerPos: { x: board.player.x, y: board.player.y }
  });
  
  const occupied = new Map();
  occupied.set(posKey(board.player.x, board.player.y), "player");
  for (const m of board.monsters) occupied.set(posKey(m.x, m.y), m.id);

  for (const m of board.monsters) {
    console.log("[DEBUG] 怪物移动检查:", {
      monsterId: m.id,
      name: m.name,
      isRanged: m.isRanged,
      range: m.range,
      pos: { x: m.x, y: m.y }
    });
    
    if (m.isRanged) {
      console.log("[DEBUG] 怪物是远程，跳过移动");
      continue;
    }
    const dist = manhattan(m.x, m.y, board.player.x, board.player.y);
    console.log("[DEBUG] 怪物距离:", { dist, manhattanFunc: manhattan.toString() });
    if (dist <= 1) {
      console.log("[DEBUG] 距离<=1，不移动");
      continue;
    }
    const from = { x: m.x, y: m.y };
    const step = stepToward(m.x, m.y, board.player.x, board.player.y);
    console.log("[DEBUG] stepToward 结果:", { step, stepAlt: step?.alt });
    if (!step) continue;
    const candidates = [step, step.alt].filter(Boolean);
    let moved = false;
    for (const to of candidates) {
      if (to.x === board.player.x && to.y === board.player.y) continue;
      if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
      const keyTo = posKey(to.x, to.y);
      if (occupied.has(keyTo)) continue;
      occupied.delete(posKey(from.x, from.y));
      occupied.set(keyTo, m.id);
      m.x = to.x;
      m.y = to.y;
      frame.events.push({ type: "move", entityId: m.id, from, to: { x: m.x, y: m.y } });
      moved = true;
      console.log("[DEBUG] 怪物移动成功:", { to });
      break;
    }
    if (moved) continue;
    console.log("[DEBUG] 怪物未能移动");
  }
}

function tickPlayerAttack(save, player, map, board, frame) {
  // 防御性检查
  if (!board || !board.player) {
    console.error("[ERROR] tickPlayerAttack: board or board.player is undefined", { 
      boardExists: !!board, 
      playerExists: !!board?.player,
      mapId: map?.id 
    });
    return;
  }
  
  const skill = selectPlayerActiveSkill(save, player);
  const target = pickNearestMonster(board, board.player.x, board.player.y, skill.range);
  if (!target) return;
  let useMp = skill.mpCost ?? 0;
  let style = skill.style ?? "melee";
  let dmgMul = skill.dmgMul ?? 1.0;
  if (player.mp < useMp) {
    useMp = 0;
    style = "melee";
    dmgMul = 1.0;
  }
  if (useMp > 0) {
    player.mp = Math.max(0, player.mp - useMp);
  }
  const isCrit = Math.random() < 0.1;
  const critMul = 2.0;
  let damage = calcDamage(player.atk, target.def) * dmgMul;
  if (isCrit) damage *= critMul;
  damage = Math.max(1, Math.floor(damage));
  target.hp = Math.max(0, target.hp - damage);
  pushLog(
    save,
    "battle",
    `${isCrit ? "暴击！" : ""}你使用${style === "melee" ? "近战" : "远程"}技能对 ${target.name} 造成 ${damage} 伤害（${target.hp}/${target.hpMax}）`
  );
  registerSkillUse(save, player, skill.id);
  frame.events.push({
    type: "attack",
    attackerId: "player",
    targetId: target.id,
    from: { x: board.player.x, y: board.player.y },
    to: { x: target.x, y: target.y },
    damage,
    targetHp: target.hp,
    targetHpMax: target.hpMax,
    isCrit,
    style,
    skillId: skill.id
  });
  if (target.hp > 0) return;
  onMonsterKilled(save, player, map, board, target);
  frame.events.push({ type: "dead", entityId: target.id, at: { x: target.x, y: target.y } });
}

function tickMonstersAttack(save, player, map, board, frame) {
  // 防御性检查
  if (!board || !board.player || !board.monsters || !Array.isArray(board.monsters)) {
    console.error("[ERROR] tickMonstersAttack: board, player or monsters is invalid", { 
      boardExists: !!board,
      playerExists: !!board?.player,
      monstersExists: !!board?.monsters,
      isArray: Array.isArray(board?.monsters),
      mapId: map?.id 
    });
    return;
  }
  
  for (const m of board.monsters.slice()) {
    const dist = manhattan(m.x, m.y, board.player.x, board.player.y);
    if (dist > m.range) continue;
    const skill = m.isRanged
      ? (save.config.skills?.monster?.ranged ?? { id: "spit", style: "ranged", dmgMul: 1.0 })
      : (save.config.skills?.monster?.melee ?? { id: "claw", style: "melee", dmgMul: 1.0 });
    const atkMul = Number(map.monsterAtkMul ?? 1.0);
    const damage = Math.max(1, Math.floor(calcDamage(m.atk, player.def) * (skill.dmgMul ?? 1.0) * atkMul));
    player.hp = Math.max(0, player.hp - damage);
    pushLog(save, "battle", `${m.name} 对你造成 ${damage} 伤害（${player.hp}/${player.hpMax}）`);
    frame.events.push({
      type: "attack",
      attackerId: m.id,
      targetId: "player",
      from: { x: m.x, y: m.y },
      to: { x: board.player.x, y: board.player.y },
      damage,
      targetHp: player.hp,
      targetHpMax: player.hpMax,
      style: m.isRanged ? "ranged" : "melee",
      skillId: skill.id
    });
    if (player.hp > 0) continue;
    save.runtime.isRunning = false;
    pushLog(save, "system", "你被击败，5秒后回城复活");
    // 清空当前怪物
    board.monsters = [];
    save.runtime.pendingReviveAt = Date.now() + 5000;
    save.runtime.pendingReviveTownId = map.returnTownId ?? map.id;
    return;
  }
}

function onMonsterKilled(save, player, map, board, monster) {
  board.monsters = board.monsters.filter((m) => m.id !== monster.id);
  
  // 使用新的掉落系统
  loadDropConfigs(); // 确保加载配置
  const drops = rollMonsterDrops(monster.id);
  
  // 处理金币掉落
  let totalGold = 0;
  for (const drop of drops) {
    if (drop.type === 'gold') {
      totalGold += drop.amount;
    }
  }
  
  player.gold += totalGold;
  if (totalGold > 0) {
    pushLog(save, "loot", `获得金币：+${totalGold}`);
  }
  
  gainExp(save, player, monster.exp);
  pushLog(save, "loot", `获得经验：+${monster.exp}`);
  trackMapKill(save, player, map.id);
  
  // 处理其他掉落
  for (const drop of drops) {
    if (drop.type === 'equip') {
      // 根据怪物等级和是否 BOSS 确定品质概率
      const qualityRates = getQualityRates(monster.level, monster.isBoss);
      const quality = pickQuality(qualityRates);
      
      const equip = createEquipWithQuality(drop.equipId, quality);
      if (equip) {
        player.inventory.push(equip);
        pushLog(save, "loot", `[掉落] ${equip.name} (${equip.rarity}) - ${formatEquipStats(equip.stats)}`);
        
        // 优先触发自动穿戴，再触发自动回收
        if (player.settings.autoEquip) {
          autoEquipBestAllSlots(save, player);
        }
        maybeAutoRecycle(save, player, equip);
      }
    } else if (drop.type === 'material') {
      // 材料掉落 (如鸡肉、鹿肉)
      const material = {
        id: crypto.randomUUID(),
        type: "material",
        itemId: drop.itemId,
        name: drop.name,
        stackCount: 1
      };
      player.inventory.push(material);
      pushLog(save, "loot", `[材料] ${drop.name}`);
    } else if (drop.type === 'skillbook') {
      // 技能书掉落
      const skillBook = {
        id: crypto.randomUUID(),
        type: "skillbook",
        skillId: drop.skillId,
        skillName: drop.name,
        job: getSkillJob(drop.skillId)
      };
      player.inventory.push(skillBook);
      pushLog(save, "loot", `[技能书] 《${drop.name}》`);
    } else if (drop.type === 'set') {
      // 套装部件 (随机)
      const setParts = getSetParts(drop.setId);
      const randomPart = setParts[Math.floor(Math.random() * setParts.length)];
      const qualityRates = getQualityRates(monster.level, monster.isBoss);
      const quality = pickQuality(qualityRates);
      
      const equip = createEquipWithQuality(randomPart, quality);
      if (equip) {
        player.inventory.push(equip);
        pushLog(save, "loot", `[套装部件] ${equip.name} (${drop.setId})`);
        
        if (player.settings.autoEquip) {
          autoEquipBestAllSlots(save, player);
        }
        maybeAutoRecycle(save, player, equip);
      }
    }
  }
  
  // BOSS 额外金币奖励
  if (monster.isBoss) {
    const bossGold = totalGold * 5; // 5 倍金币
    player.gold += bossGold;
    pushLog(save, "loot", `[BOSS 奖励] 额外金币 +${bossGold}`);
  }
}

function pickNearestMonster(board, x, y, maxDist) {
  let best = null;
  let bestDist = Infinity;
  for (const m of board.monsters) {
    const d = manhattan(m.x, m.y, x, y);
    if (d > maxDist) continue;
    if (d < bestDist) {
      bestDist = d;
      best = m;
    }
  }
  return best;
}

function manhattan(ax, ay, bx, by) {
  return Math.abs(ax - bx) + Math.abs(ay - by);
}

function stepToward(x, y, tx, ty) {
  const dx = tx - x;
  const dy = ty - y;
  if (dx === 0 && dy === 0) return null;
  const sx = dx === 0 ? 0 : dx > 0 ? 1 : -1;
  const sy = dy === 0 ? 0 : dy > 0 ? 1 : -1;
  if (Math.abs(dx) >= Math.abs(dy)) {
    return { x: x + sx, y, alt: { x, y: y + sy } };
  }
  return { x, y: y + sy, alt: { x: x + sx, y } };
}

function posKey(x, y) {
  return `${x},${y}`;
}

function gainExp(save, player, exp) {
  player.exp += exp;
  while (player.exp >= player.expToNext) {
    player.exp -= player.expToNext;
    player.level += 1;
    player.expToNext = Math.floor(player.expToNext * 1.35 + 30);
    recomputeDerivedStatsForPlayer(save, player);
    pushLog(save, "system", `升级：Lv.${player.level}`);
  }
}

function trackMapKill(save, p, mapId) {
  if (!p || !p.progress) return;
  p.progress.mapKills[mapId] = (p.progress.mapKills[mapId] ?? 0) + 1;
  const killsToClear = save.config.mapClearRule.killsToClear ?? DEFAULT_CONFIG.mapClearRule.killsToClear;
  if (!p.progress.mapCleared[mapId] && p.progress.mapKills[mapId] >= killsToClear) {
    p.progress.mapCleared[mapId] = true;
    const map = save.config.maps.find((m) => m.id === mapId);
    pushLog(save, "system", `首通完成：${map?.name ?? mapId}（解锁后续地图）`);
  }
}

function maybeAutoEquip(save, player, equip) {
  // 这个函数已经被 autoEquipBestAllSlots 替代
  // 保留作为兼容性和日志记录
  const slot = equip.slot;
  const current = player.equipped[slot];
  if (!current || equip.score > current.score) {
    // 调用更智能的全局最优穿戴
    autoEquipBestAllSlots(save, player);
  }
}

function autoEquipBestAllSlots(save, p) {
  refreshEquipScoresForPlayer(save, p);
  const inv = p.inventory ?? [];
  for (const slot of save.config.equipSlots ?? DEFAULT_CONFIG.equipSlots) {
    const cur = p.equipped?.[slot] ?? null;
    let best = cur;
    let bestScore = Number(best?.score ?? -Infinity);
    for (const it of inv) {
      if (it?.type !== "equip") continue;
      if (it.slot !== slot) continue;
      const sc = Number(it.score ?? -Infinity);
      if (!best || sc > bestScore) {
        best = it;
        bestScore = sc;
      }
    }
    if (best && best.id && best.id !== cur?.id) {
      equipItemDirect(save, p, best.id);
    }
  }
}

function clampPct(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.floor(n)));
}

function maybeAutoRecycle(save, p, equip) {
  if (!p?.settings?.autoRecycle) return;
  if (!equip || equip.type !== "equip") return;
  if (equip.equipped || equip.locked) return;
  const th = String(p.settings.recycleRarityThreshold ?? "white");
  const thIdx = Math.max(0, RARITY_ORDER.indexOf(th));
  const rIdx = Math.max(0, RARITY_ORDER.indexOf(String(equip.rarity ?? "white")));
  if (rIdx <= thIdx) {
    recycleItems(save, p, [equip.id]);
  }
}

function maybeAutoDrinkInTown(save, p, map) {
  if (!p || !map?.isTown) return;
  const s = p.settings ?? {};
  const hpPct = clampPct(s.autoHpPotionPct ?? 0);
  const mpPct = clampPct(s.autoMpPotionPct ?? 0);
  const shop = (save.config.shopByTown?.[map.id] ?? save.config.shopItems ?? []).slice();
  const hpItems = shop.filter((x) => Number(x?.healHp ?? 0) > 0).sort((a, b) => Number(b.healHp) - Number(a.healHp));
  const mpItems = shop.filter((x) => Number(x?.healMp ?? 0) > 0).sort((a, b) => Number(b.healMp) - Number(a.healMp));

  const hpCurPct = p.hpMax > 0 ? (p.hp / p.hpMax) * 100 : 100;
  const mpCurPct = p.mpMax > 0 ? (p.mp / p.mpMax) * 100 : 100;

  if (hpPct > 0 && p.hp < p.hpMax && hpCurPct <= hpPct) {
    for (let i = 0; i < 5; i++) {
      const curPct = p.hpMax > 0 ? (p.hp / p.hpMax) * 100 : 100;
      if (p.hp >= p.hpMax || curPct > hpPct) break;
      const pick = hpItems.find((it) => Number(it.priceGold ?? 0) <= p.gold);
      if (!pick) break;
      buyShopItem(save, p, pick.id);
    }
  }
  if (mpPct > 0 && p.mp < p.mpMax && mpCurPct <= mpPct) {
    for (let i = 0; i < 5; i++) {
      const curPct = p.mpMax > 0 ? (p.mp / p.mpMax) * 100 : 100;
      if (p.mp >= p.mpMax || curPct > mpPct) break;
      const pick = mpItems.find((it) => Number(it.priceGold ?? 0) <= p.gold);
      if (!pick) break;
      buyShopItem(save, p, pick.id);
    }
  }
}

function createPotionItem(config, defId) {
  const def = config.potionDefs?.[defId];
  if (!def) return null;
  return {
    id: crypto.randomUUID(),
    type: "potion",
    potionId: defId,  // 添加 potionId 字段
    name: def.name,
    healHp: Number(def.healHp ?? 0),
    healMp: Number(def.healMp ?? 0),
    createdAt: Date.now()
  };
}

function usePotion(save, p, itemId) {
  if (!p) return false;
  const idx = (p.inventory ?? []).findIndex((it) => it.id === itemId && it.type === "potion");
  if (idx < 0) return false;
  const it = p.inventory[idx];
  const beforeHp = p.hp;
  const beforeMp = p.mp;
  if (it.healHp) p.hp = Math.min(p.hpMax, p.hp + Number(it.healHp));
  if (it.healMp) p.mp = Math.min(p.mpMax, p.mp + Number(it.healMp));
  p.inventory.splice(idx, 1);
  pushLog(save, "system", `使用药品：${it.name}（HP ${beforeHp}->${p.hp} · MP ${beforeMp}->${p.mp}）`);
  return true;
}

function maybeAutoDrinkUsingInventory(save, p) {
  if (!p) return;
  const s = p.settings ?? {};
  const hpPct = clampPct(s.autoHpPotionPct ?? 0);
  const mpPct = clampPct(s.autoMpPotionPct ?? 0);
  const hpCurPct = p.hpMax > 0 ? (p.hp / p.hpMax) * 100 : 100;
  const mpCurPct = p.mpMax > 0 ? (p.mp / p.mpMax) * 100 : 100;
  let count = 0;
  if (hpPct > 0 && p.hp < p.hpMax && hpCurPct <= hpPct) {
    const potions = (p.inventory ?? []).filter((x) => x.type === "potion" && Number(x.healHp ?? 0) > 0).sort((a, b) => Number(b.healHp) - Number(a.healHp));
    for (const it of potions) {
      if (p.hp >= p.hpMax || (p.hpMax > 0 && (p.hp / p.hpMax) * 100 > hpPct)) break;
      if (usePotion(save, p, it.id)) count += 1;
      if (count >= 5) break;
    }
  }
  if (mpPct > 0 && p.mp < p.mpMax && mpCurPct <= mpPct) {
    const potions = (p.inventory ?? []).filter((x) => x.type === "potion" && Number(x.healMp ?? 0) > 0).sort((a, b) => Number(b.healMp) - Number(a.healMp));
    for (const it of potions) {
      if (p.mp >= p.mpMax || (p.mpMax > 0 && (p.mp / p.mpMax) * 100 > mpPct)) break;
      if (usePotion(save, p, it.id)) count += 1;
      if (count >= 5) break;
    }
  }
}

function rollPotion(config) {
  const defs = config.potionDefs ?? {};
  const entries = [
    { id: "hp_small", weight: 60 },
    { id: "mp_small", weight: 60 },
    { id: "hp_mid", weight: 18 },
    { id: "mp_mid", weight: 18 }
  ].filter((e) => defs[e.id]);
  const id = pickWeighted(entries);
  if (!id) return null;
  return createPotionItem(config, id);
}

function rollEquip(config, maxRarity, job) {
  const slot = config.equipSlots[randInt(0, config.equipSlots.length - 1)];
  const maxIndex = RARITY_ORDER.indexOf(maxRarity);
  const weights = {};
  for (const [rarity, w] of Object.entries(config.rarityWeights)) {
    const idx = RARITY_ORDER.indexOf(rarity);
    if (idx >= 0 && idx <= maxIndex) weights[rarity] = w;
  }
  const rarity = pickWeighted(Object.entries(weights).map(([id, weight]) => ({ id, weight })));
  
  // 生成装备名称
  const name = generateEquipName(config, slot, rarity);
  
  // 根据装备名称获取固定属性
  const baseStats = config.equipmentStats?.[name];
  const stats = baseStats ? JSON.parse(JSON.stringify(baseStats)) : { atk: 0, magic: 0, tao: 0, def: 0, hpMax: 0 };
  
  const score = calcEquipScoreForJob(job, stats);
  return {
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity,
    name,
    stats,
    score,
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  };
}

function generateEquipName(config, slot, rarity) {
  const slotName = config.equipSlotNames[slot] ?? slot;
  const rarityName = config.rarityName[rarity] ?? rarity;
  
  // 热血传奇经典装备名称库
  const seeds = {
    weapon: [
      // 初级武器 (白色)
      "木剑",
      "乌木剑",
      "短剑",
      "铁剑",
      "青铜剑",
      "鹤嘴锄",
      // 中级武器 (绿色/蓝色)
      "凝霜",
      "修罗",
      "炼狱",
      "井中月",
      "魔杖",
      "银蛇",
      "铜锤",
      "无极棍",
      // 高级武器 (紫色)
      "裁决之杖",
      "骨玉权杖",
      "龙纹剑",
      "血饮",
      "逍遥扇",
      "命运之刃",
      "封魔剑",
      // 顶级武器 (橙色)
      "屠龙",
      "嗜魂法杖",
      "怒斩",
      "龙牙",
      "开天",
      "镇天",
      "玄天",
      "赤血魔剑"
    ],
    armor: [
      // 初级盔甲 (白色)
      "布衣",
      "轻型盔甲",
      "中型盔甲",
      "重盔甲",
      "魔法长袍",
      "灵魂战衣",
      // 中级盔甲 (绿色/蓝色)
      "战神盔甲",
      "幽灵战衣",
      "恶魔长袍",
      "地狱火焰",
      "天蝉法袍",
      // 高级盔甲 (紫色)
      "天魔神甲",
      "霓裳羽衣",
      "天师长袍",
      "雷霆战甲",
      "烈焰魔衣",
      "光芒道袍",
      // 顶级盔甲 (橙色)
      "凤天魔甲",
      "凰天魔衣",
      "星王战甲",
      "预言战甲"
    ],
    shoes: [
      // 初级鞋子 (白色)
      "草鞋",
      "布鞋",
      "鹿皮靴",
      "兽皮靴",
      // 中级鞋子 (绿色/蓝色)
      "皮靴",
      "追风靴",
      "疾风靴",
      // 高级鞋子 (紫色)
      "铁靴",
      "战靴",
      "紫绸靴",
      "避魂靴",
      // 顶级鞋子 (橙色)
      "星王战靴",
      "传说魔靴"
    ],
    head: [
      // 初级头盔 (白色)
      "青铜头盔",
      "魔法头盔",
      "道士头盔",
      "骷髅头盔",
      "虎齿项链",
      // 中级头盔 (绿色/蓝色)
      "战士头盔",
      "黑铁头盔",
      "黄金头盔",
      // 高级头盔 (紫色)
      "圣战头盔",
      "法神头盔",
      "天尊头盔",
      "黑铁头盔",
      // 顶级头盔 (橙色)
      "星王战盔",
      "星王法盔",
      "星王道盔",
      "预言头盔"
    ],
    ring: [
      // 初级戒指 (白色)
      "古铜戒指",
      "银戒指",
      "珍珠戒指",
      "道德戒指",
      "玻璃戒指",
      // 中级戒指 (绿色/蓝色)
      "红宝石戒指",
      "生铁戒指",
      "珊瑚戒指",
      "蓝翡翠戒指",
      // 高级戒指 (紫色)
      "龙之戒指",
      "力量戒指",
      "紫金戒指",
      "泰坦戒指",
      "心灵戒指",
      "三眼戒指",
      // 顶级戒指 (橙色)
      "圣战戒指",
      "法神戒指",
      "天尊戒指",
      "狂战戒指",
      "混世戒指",
      "太极戒指",
      "战神戒指",
      "圣魔戒指",
      "真魂戒指"
    ],
    bracelet: [
      // 初级手镯 (白色)
      "铁手镯",
      "铜手镯",
      "银手镯",
      "金手镯",
      "凤凰明珠",
      // 中级手镯 (绿色/蓝色)
      "道士手镯",
      "黑檀手镯",
      "蓝宝石手镯",
      "玛瑙手镯",
      "辟邪手镯",
      "夏普儿手镯",
      // 高级手镯 (紫色)
      "龙之手镯",
      "骑士手镯",
      "心灵手镯",
      "三眼护腕",
      "思贝尔手镯",
      "铃铛手镯",
      // 顶级手镯 (橙色)
      "圣战手镯",
      "法神手镯",
      "天尊手镯",
      "狂战护腕",
      "混世手镯",
      "太极手镯",
      "战神手镯",
      "圣魔手镯",
      "真魂手镯"
    ],
    necklace: [
      // 初级项链 (白色)
      "传统项链",
      "蓝色水晶项链",
      "黄色水晶项链",
      "凤凰明珠",
      "魔鬼项链",
      // 中级项链 (绿色/蓝色)
      "记忆项链",
      "绿色项链",
      "灵魂项链",
      "生命项链",
      "如意项链",
      "狂风项链",
      // 高级项链 (紫色)
      "圣战项链",
      "法神项链",
      "天尊项链",
      "白虎齿项链",
      "幸运项链",
      "技巧项链",
      "探测项链",
      // 顶级项链 (橙色)
      "雷霆项链",
      "烈焰项链",
      "光芒项链",
      "强化雷霆项链",
      "强化烈焰项链",
      "强化光芒项链",
      "圣魔项链",
      "真魂项链"
    ],
    medal: [
      // 初级勋章 (白色)
      "铜勋章",
      "铁勋章",
      "银勋章",
      "金勋章",
      // 中级勋章 (绿色/蓝色)
      "荣誉勋章 1 号",
      "荣誉勋章 5 号",
      "荣誉勋章 10 号",
      "祈祷徽章",
      // 高级勋章 (紫色)
      "荣誉勋章 23 号",
      "荣誉勋章 33 号",
      "荣誉勋章 43 号",
      "圣战纹章",
      "法神纹章",
      "天尊纹章",
      // 顶级勋章 (橙色)
      "银星勋章",
      "荣誉勋章 53 号",
      "荣誉勋章 54 号",
      "荣誉勋章 55 号"
    ]
  };
  
  const list = seeds[slot] ?? [slotName];
  const base = list[randInt(0, list.length - 1)];
  return `${rarityName}${base}`;
}
function createStarterEquip(config, job) {
  const mkEquip = (slot, name, stats) => ({
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity: "white",
    name,
    stats,
    score: calcEquipScoreForJob(job, stats),
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  });
  
  // 所有职业初始装备都是布衣 + 乌木剑
  return {
    weapon: mkEquip("weapon", "乌木剑", { atk: 8, magic: 0, tao: 0, def: 0, hpMax: 0 }),
    armor: mkEquip("armor", "布衣", { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 8 })
  };
}

function getRecycleValue(config, equip) {
  const rarityFactor = { white: 1, green: 2, blue: 5, purple: 12, orange: 25 }[equip.rarity] ?? 1;
  const strengthenFactor = 1 + (equip.strengthenLevel ?? 0) * 0.2;
  const base = 10;
  return Math.floor(base * rarityFactor * strengthenFactor);
}

function getStrengthenCost(config, nextLevel) {
  const base = config.strengthen.baseGoldCost ?? DEFAULT_CONFIG.strengthen.baseGoldCost;
  const growth = config.strengthen.goldCostGrowth ?? DEFAULT_CONFIG.strengthen.goldCostGrowth;
  return Math.floor(base * Math.pow(growth, nextLevel - 1));
}

function calcPowerScore(atk, def, hpMax) {
  return Math.floor(atk * 6 + def * 4 + hpMax * 0.6);
}

function calcEquipScoreForJob(job, stats) {
  const s = stats ?? {};
  const atk = Number(s.atk ?? 0);
  const magic = Number(s.magic ?? 0);
  const tao = Number(s.tao ?? 0);
  const def = Number(s.def ?? 0);
  const hpMax = Number(s.hpMax ?? 0);
  const main = job === "mage" ? magic : job === "taoist" ? tao : atk;
  const side = job === "mage" ? atk + tao : job === "taoist" ? atk + magic : magic + tao;
  return Math.floor(main * 6 + side * 1 + def * 4 + hpMax * 0.6);
}

function registerSkillUse(save, p, skillId) {
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  const learned = new Set([...(p.skills.activeIds ?? []), ...(p.skills.passiveIds ?? [])]);
  if (!learned.has(skillId)) return;
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === skillId);
  if (!def) return;
  const info = p.skills.levels[skillId] ?? { level: 1, exp: 0 };
  const curLv = Math.max(1, Math.min(3, Number(info.level ?? 1)));
  if (curLv >= 3) return;
  info.exp = (info.exp ?? 0) + 1;
  const need = Number(def.trainNeed?.[curLv] ?? 999999);
  if (info.exp >= need) {
    info.level = curLv + 1;
    info.exp = 0;
    pushLog(save, "system", `技能升级：${def.name} Lv.${info.level}`);
  } else {
    info.level = curLv;
  }
  p.skills.levels[skillId] = info;
}

function getSkillName(save, p, skillId) {
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === skillId);
  return def?.name ?? skillId;
}

function rollSkillBook(save, monsterLevel, job) {
  const cap = Math.max(1, Number(monsterLevel) - 5);
  const list = (save.config.skills?.[job] ?? []).filter((s) => (s.learnLevel ?? 1) <= cap);
  if (list.length <= 0) return null;
  const skill = list[randInt(0, list.length - 1)];
  return {
    id: crypto.randomUUID(),
    type: "skill_book",
    skillId: skill.id,
    skillName: skill.name,
    learnLevel: skill.learnLevel ?? 1,
    skillType: skill.type,
    createdAt: Date.now()
  };
}

export function useSkillBook(save, p, itemId) {
  const idx = p.inventory.findIndex((it) => it.id === itemId);
  if (idx < 0) throw new Error("物品不存在");
  const it = p.inventory[idx];
  if (it.type !== "skill_book") throw new Error("不是技能书");
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === it.skillId);
  if (!def) throw new Error("技能不存在");
  if (p.level < (def.learnLevel ?? 1)) throw new Error("等级不足，无法学习");
  const learned = new Set([...(p.skills.activeIds ?? []), ...(p.skills.passiveIds ?? [])]);
  if (learned.has(it.skillId)) throw new Error("已学会该技能");
  if (def.type === "passive") {
    p.skills.passiveIds.push(it.skillId);
  } else {
    p.skills.activeIds.unshift(it.skillId);
    if (!p.skills.activeId) p.skills.activeId = it.skillId;
  }
  p.skills.levels[it.skillId] = { level: 1, exp: 0 };
  p.inventory.splice(idx, 1);
  pushLog(save, "system", `学习技能：《${it.skillName}》`);
}

export function setActiveSkill(save, p, skillId) {
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  if (!p.skills.activeIds.includes(skillId)) throw new Error("未学习该主动技能");
  p.skills.activeId = skillId;
  pushLog(save, "system", `切换技能：${getSkillName(save, p, skillId)}`);
}

export function buyShopItem(save, p, itemId) {
  const curMapId = p.progress?.currentMapId ?? save.config.maps[0].id;
  const curMap = save.config.maps.find((m) => m.id === curMapId);
  if (!curMap?.isTown) throw new Error("当前地图无法购买（请前往主城）");
  const it =
    (save.config.shopByTown?.[curMap.id] ?? save.config.shopItems ?? []).find((x) => x.id === itemId);
  if (!it) throw new Error("商品不存在");
  const price = Number(it.priceGold ?? 0);
  if (p.gold < price) throw new Error("金币不足");
  p.gold -= price;
  if (it.healHp) p.hp = Math.min(p.hpMax, p.hp + Number(it.healHp));
  if (it.healMp) p.mp = Math.min(p.mpMax, p.mp + Number(it.healMp));
  if (it.grantEquipSlot) {
    const rarity = String(it.grantRarity ?? "white");
    const eq = createShopEquip(save, String(it.grantEquipSlot), rarity, p.job);
    p.inventory.push(eq);
    pushLog(save, "system", `购买并获得：${formatEquip(save.config, eq)}`);
  } else {
    pushLog(save, "system", `购买并使用：${it.name}`);
  }
}

function calcDamage(atk, def) {
  const base = Math.max(1, atk - def);
  const roll = 0.9 + Math.random() * 0.2;
  return Math.max(1, Math.floor(base * roll));
}

function randInt(min, max) {
  const a = Math.ceil(min);
  const b = Math.floor(max);
  return Math.floor(a + Math.random() * (b - a + 1));
}

function pickWeighted(entries) {
  if (!Array.isArray(entries) || entries.length <= 0) return null;
  const sum = entries.reduce((acc, e) => acc + (e.weight ?? 0), 0);
  if (sum <= 0) return entries[0].id;
  let r = Math.random() * sum;
  for (const e of entries) {
    r -= e.weight ?? 0;
    if (r <= 0) return e.id;
  }
  return entries[entries.length - 1].id;
}

function formatEquip(config, equip) {
  const rarityName = config.rarityName[equip.rarity] ?? equip.rarity;
  const slotName = config.equipSlotNames[equip.slot] ?? equip.slot;
  const { atk = 0, magic = 0, tao = 0, def = 0, hpMax = 0 } = equip.stats ?? {};
  const strengthen = equip.strengthenLevel ? `+${equip.strengthenLevel}` : "";
  return `${equip.name}${strengthen}【${rarityName}·${slotName}】(攻${atk} 术${tao} 魔${magic} 防${def} 血${hpMax})`;
}

function createShopEquip(save, slot, rarity, job) {
  const config = save.config;
  const base = config.equipBaseBySlot[slot];
  
  // 应用品质加成 (不是倍率)
  const bonus = config.rarityBonus?.[rarity] ?? { atk: 0, magic: 0, tao: 0, def: 0, hpMax: 0 };
  const stats = {
    atk: (base.atk ?? 0) + (bonus.atk ?? 0),
    magic: (base.magic ?? 0) + (bonus.magic ?? 0),
    tao: (base.tao ?? 0) + (bonus.tao ?? 0),
    def: (base.def ?? 0) + (bonus.def ?? 0),
    hpMax: (base.hpMax ?? 0) + (bonus.hpMax ?? 0)
  };
  
  const score = calcEquipScoreForJob(job, stats);
  return {
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity,
    name: generateEquipName(config, slot, rarity),
    stats,
    score,
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  };
}

function pushLog(save, type, text) {
  save.logs.push({
    id: crypto.randomUUID(),
    ts: Date.now(),
    type,
    text
  });
  const max = save.config.logMax ?? DEFAULT_CONFIG.logMax;
  if (save.logs.length > max) {
    save.logs.splice(0, save.logs.length - max);
  }
}
