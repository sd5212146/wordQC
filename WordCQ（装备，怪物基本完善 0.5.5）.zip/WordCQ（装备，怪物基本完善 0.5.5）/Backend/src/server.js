import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

import {
  canEnterMap,
  createNewSave,
  createPlayer,
  buyShopItem,
  setActiveSkill,
  useSkillBook,
  equipItem,
  unequipItem,
  migrateSave,
  recycleItems,
  runTicks,
  settleOffline,
  setAutoEquip,
  setAutoRecycle,
  setAutoDrink,
  setRecycleRarityThreshold,
  setCurrentMap,
  setRunning,
  strengthenEquipped,
  warehouseStore,
  warehouseTake,
  initGameConfig
} from "./gameEngine.js";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(process.cwd(), "data");
const SAVE_PATH = path.join(DATA_DIR, "save.json");
const CONFIG_PATH = path.join(DATA_DIR, "gameConfig.json");

let save = createNewSave();
let gameConfig = null;

async function ensureDataDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

async function loadSave() {
  try {
    await ensureDataDir();
    
    // 加载游戏配置
    const configRaw = await fs.readFile(CONFIG_PATH, "utf8");
    gameConfig = JSON.parse(configRaw);
    console.log("[config] loaded:", CONFIG_PATH);
    
    // 初始化 gameEngine 中的全局配置
    initGameConfig(gameConfig);
    
    // 加载存档数据
    const raw = await fs.readFile(SAVE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return;
    save = parsed;
    migrateSave(save);
    if (!save.runtime) save.runtime = { isRunning: false, lastTickAt: Date.now() };
    if (!save.runtime.sessions) save.runtime.sessions = {};
    if (!("lastBattle" in save.runtime)) save.runtime.lastBattle = null;
    if (!("board" in save.runtime)) save.runtime.board = null;
    if (!("lastFrame" in save.runtime)) save.runtime.lastFrame = null;
    if (!save.accounts) save.accounts = {};
    if (!save.logs) save.logs = [];
    
    console.log("[save] loaded:", SAVE_PATH);
  } catch (err) {
    if (err?.code !== "ENOENT") {
      console.error("[save] load failed:", err);
    }
  }
}

let saveWritePromise = Promise.resolve();
function queueSaveWrite() {
  saveWritePromise = saveWritePromise
    .then(async () => {
      await ensureDataDir();
      await fs.writeFile(SAVE_PATH, JSON.stringify(save, null, 2), "utf8");
    })
    .catch((err) => console.error("[save] write failed:", err));
  return saveWritePromise;
}

function authUser(req) {
  const token = req.headers["x-auth"];
  if (!token || typeof token !== "string") return null;
  const session = save.runtime.sessions?.[token];
  if (!session) return null;
  if (typeof session === "string") {
    // 兼容旧版 string session
    return { username: session };
  }
  return session;
}

function requireAuth(req, res, next) {
  const session = authUser(req);
  if (!session) return res.status(401).json({ ok: false, error: "未登录" });
  req.username = session.username;
  req.playerId = session.playerId;
  const acc = save.accounts?.[req.username];
  
  // 从账号中查找当前活跃角色
  let player = null;
  if (req.playerId && acc?.roles) {
    player = acc.roles.find(r => r.id === req.playerId);
  }
  req.player = player;

  res.on("finish", () => {
    // 请求结束时同步角色数据回账号列表（如果活跃角色存在）
    if (acc && !req.skipSyncPlayer && req.player) {
      const idx = (acc.roles || []).findIndex(r => r.id === req.player.id);
      if (idx >= 0) acc.roles[idx] = req.player;
    }
  });
  next();
}

function hashPassword(pw) {
  return crypto.createHash("sha256").update(String(pw)).digest("hex");
}

app.post("/api/auth/register", async (req, res) => {
  try {
    const { username, password } = req.body ?? {};
    const u = String(username || "").trim().slice(0, 20);
    const p = String(password || "").trim();
    if (!u || !p) return res.status(400).json({ ok: false, error: "账号或密码为空" });
    if (save.accounts?.[u]) return res.status(400).json({ ok: false, error: "账号已存在" });
    save.accounts[u] = { passwordHash: hashPassword(p), roles: [] };
    const token = Math.random().toString(36).slice(2) + Date.now();
    save.runtime.sessions[token] = { username: u, playerId: null };
    await queueSaveWrite();
    return res.json({ ok: true, data: { token } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body ?? {};
    const u = String(username || "").trim().slice(0, 20);
    const p = String(password || "").trim();
    const acc = save.accounts?.[u];
    if (!acc) return res.status(400).json({ ok: false, error: "账号不存在" });
    if (acc.passwordHash !== hashPassword(p)) return res.status(400).json({ ok: false, error: "密码错误" });
    const token = Math.random().toString(36).slice(2) + Date.now();
    save.runtime.sessions[token] = { username: u, playerId: null };
    await queueSaveWrite();
    return res.json({ ok: true, data: { token } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/auth/logout", requireAuth, async (req, res) => {
  try {
    const token = req.headers["x-auth"];
    delete save.runtime.sessions[token];
    await queueSaveWrite();
    return res.json({ ok: true, data: {} });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

function publicState(req, player) {
  const currentMapId = player?.progress?.currentMapId ?? gameConfig.maps[0].id;
  const map = gameConfig.maps.find((m) => m.id === currentMapId) ?? gameConfig.maps[0];

  const session = authUser(req);
  const u = session?.username;
  const acc = u ? save.accounts?.[u] : null;
  const roles = acc?.roles ?? [];

  const neighbors = new Set();
  if (map?.exits && typeof map.exits === "object") {
    for (const id of Object.values(map.exits)) {
      if (id) neighbors.add(String(id));
    }
  }
  const mapExits = {};
  for (const dir of ["up", "right", "down", "left"]) {
    const id = map?.exits?.[dir] ?? null;
    if (!id) {
      mapExits[dir] = null;
      continue;
    }
    const m = gameConfig.maps.find((x) => x.id === id) ?? null;
    const gate = canEnterMap(save, player, id);
    mapExits[dir] = m
      ? {
          id: m.id,
          name: m.name,
          recommendPower: m.recommendPower,
          isTown: !!m.isTown,
          canGo: gate.ok,
          reason: gate.ok ? null : gate.reason
        }
      : { id, name: id, recommendPower: 0, isTown: false, canGo: false, reason: "地图不存在" };
  }
  const runtime = save.runtime
    ? {
        isRunning: !!save.runtime.isRunning,
        lastTickAt: save.runtime.lastTickAt,
        lastBattle: save.runtime.lastBattle ?? null,
        board: save.runtime.board ?? null,
        lastFrame: save.runtime.lastFrame ?? null
      }
    : null;
  const unlockedMaps = gameConfig.maps.map((m) => {
    const gate = canEnterMap(save, player, m.id);
    const travelOk = !currentMapId || m.id === currentMapId || neighbors.has(String(m.id));
    return {
      id: m.id,
      name: m.name,
      recommendPower: m.recommendPower,
      isTown: !!m.isTown,
      unlocked: gate.ok,
      lockedReason: gate.ok ? null : gate.reason,
      travelOk: gate.ok ? travelOk : false,
      travelReason: gate.ok && !travelOk ? "需要逐步前往" : null
    };
  });
  return {
    player,
    roles,
    progress: player?.progress ?? null,
    runtime,
    currentMap: map
      ? { id: map.id, name: map.name, recommendPower: map.recommendPower, themeColor: map.themeColor ?? null, isTown: !!map.isTown }
      : null,
    mapExits,
    unlockedMaps,
    shopItems: map?.isTown ? ((gameConfig.shopByTown?.[map.id] ?? gameConfig.shopItems) ?? []) : [],
    skillDefs: player ? (gameConfig.skills?.[player.job] ?? []) : [],
    equipSlots: gameConfig.equipSlots ?? [],
    equipSlotNames: gameConfig.equipSlotNames ?? {},
    logs: save.logs
  };
}

function requirePlayer(req, res, next) {
  if (!req.player) return res.status(400).json({ ok: false, error: "未创建角色" });
  next();
}

app.get("/api/state", requireAuth, async (req, res) => {
  try {
    if (save.runtime?.isRunning && req.player) {
      settleOffline(save, req.player);
      await queueSaveWrite();
    } else if (save.runtime) {
      save.runtime.lastTickAt = Date.now();
    }
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/create", requireAuth, async (req, res) => {
  try {
    const { name, job } = req.body ?? {};
    const player = createPlayer(save, { name, job });
    const u = req.username;
    if (!save.accounts[u]) save.accounts[u] = { passwordHash: "", roles: [] };
    save.accounts[u].roles.push(player);
    
    // 更新 session 中的 playerId
    const token = req.headers["x-auth"];
    if (save.runtime.sessions[token]) {
      save.runtime.sessions[token].playerId = player.id;
    }
    req.player = player;
    
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/select", requireAuth, async (req, res) => {
  try {
    const { playerId } = req.body ?? {};
    const u = req.username;
    const acc = save.accounts?.[u];
    if (!acc) throw new Error("账号异常");
    const player = (acc.roles || []).find(r => r.id === playerId);
    if (!player) throw new Error("角色不存在");
    
    // 更新 session 中的 playerId
    const token = req.headers["x-auth"];
    if (save.runtime.sessions[token]) {
      save.runtime.sessions[token].playerId = player.id;
    }
    req.player = player;

    // 重置运行状态
    save.runtime.isRunning = false;
    save.runtime.board = null;
    save.runtime.lastFrame = null;
    
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/reset", requireAuth, async (req, res) => {
  try {
    // 退出角色到选择界面，不删除数据
    req.skipSyncPlayer = true;
    
    // 更新 session 中的 playerId
    const token = req.headers["x-auth"];
    if (save.runtime.sessions[token]) {
      save.runtime.sessions[token].playerId = null;
    }
    req.player = null;

    save.runtime.board = null;
    save.runtime.lastFrame = null;
    save.runtime.isRunning = false;
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/delete", requireAuth, async (req, res) => {
  try {
    // 彻底删除角色数据
    const { playerId } = req.body ?? {};
    const u = req.username;
    const acc = save.accounts?.[u];
    if (acc && acc.roles) {
      acc.roles = acc.roles.filter(r => r.id !== playerId);
    }
    
    if (req.playerId === playerId) {
      // 更新 session 中的 playerId
      const token = req.headers["x-auth"];
      if (save.runtime.sessions[token]) {
        save.runtime.sessions[token].playerId = null;
      }
      req.player = null;
      
      save.runtime.board = null;
      save.runtime.lastFrame = null;
      save.runtime.isRunning = false;
    }
    
    if (save.runtime) {
      save.runtime.pendingReviveAt = null;
      save.runtime.pendingReviveTownId = null;
    }

    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/start", requireAuth, requirePlayer, async (req, res) => {
  try {
    setRunning(save, req.player, true);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/stop", requireAuth, requirePlayer, async (req, res) => {
  try {
    setRunning(save, req.player, false);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/tick", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { count } = req.body ?? {};
    const result = runTicks(save, req.player, count ?? 1);
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState(req, req.player) } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/map/set", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { mapId } = req.body ?? {};
    setCurrentMap(save, req.player, String(mapId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-equip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { enabled } = req.body ?? {};
    setAutoEquip(save, req.player, !!enabled);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-recycle", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { enabled } = req.body ?? {};
    setAutoRecycle(save, req.player, !!enabled);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/recycle-threshold", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { threshold } = req.body ?? {};
    setRecycleRarityThreshold(save, req.player, String(threshold));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-drink", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { hpPct, mpPct } = req.body ?? {};
    setAutoDrink(save, req.player, hpPct, mpPct);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/equip/equip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    equipItem(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/equip/unequip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    unequipItem(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/inventory/recycle", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemIds } = req.body ?? {};
    const result = recycleItems(save, req.player, itemIds);
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState(req, req.player) } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/warehouse/store", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    warehouseStore(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/warehouse/take", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    warehouseTake(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/skills/use-book", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    useSkillBook(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/skills/set-active", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { skillId } = req.body ?? {};
    setActiveSkill(save, req.player, String(skillId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/shop/buy", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    buyShopItem(save, req.player, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState(req, req.player) });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/forge/strengthen", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { slot } = req.body ?? {};
    const result = strengthenEquipped(save, req.player, String(slot));
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState(req, req.player) } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.use(express.static(path.join(process.cwd(), "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

await loadSave();

app.listen(PORT, () => {
  console.log(`[server] listening on http://localhost:${PORT}`);
});
