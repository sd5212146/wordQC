import crypto from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));

// 加载掉落配置
let monsterDropsConfig = null;
let equipmentsConfig = null;
let skillsConfig = null;

export function loadDropConfigs() {
  if (!monsterDropsConfig) {
    monsterDropsConfig = JSON.parse(readFileSync(join(__dirname, "../data/monsterDrops.json"), "utf-8"));
  }
  if (!equipmentsConfig) {
    equipmentsConfig = JSON.parse(readFileSync(join(__dirname, "../data/equipments.json"), "utf-8"));
  }
  if (!skillsConfig) {
    skillsConfig = JSON.parse(readFileSync(join(__dirname, "../data/skills.json"), "utf-8"));
  }
}

export function getMonsterDrops(monsterId) {
  if (!monsterDropsConfig) loadDropConfigs();
  return monsterDropsConfig.monsterDrops[monsterId] || null;
}

export function getEquipment(itemId) {
  if (!equipmentsConfig) loadDropConfigs();
  
  // 在武器、衣服、首饰中查找
  const allEquips = {
    ...equipmentsConfig.weapons,
    ...equipmentsConfig.armors,
    ...equipmentsConfig.accessories
  };
  
  return allEquips[itemId] || null;
}

export function getSkillBook(skillId) {
  if (!skillsConfig) loadDropConfigs();
  
  // 在所有职业技能和特殊技能中查找
  const allSkills = {};
  Object.values(skillsConfig).forEach(jobSkills => {
    Object.assign(allSkills, jobSkills);
  });
  
  return allSkills[skillId] || null;
}

/**
 * 根据品质计算装备最终属性
 * @param {Object} baseEquip - 基础装备数据
 * @param {string} quality - 品质 (white/green/blue/purple/orange)
 * @returns {Object} 最终属性
 */
export function applyQualityBonus(baseEquip, quality) {
  const bonusMap = {
    'white': 0,
    'green': 3,
    'blue': 5,
    'purple': 7,
    'orange': 9
  };
  
  const bonus = bonusMap[quality] || 0;
  
  // 复制基础属性
  const finalStats = { ...baseEquip.baseStats };
  
  // 应用品质加成
  finalStats.atk = (finalStats.atk || 0) + bonus;
  finalStats.def = (finalStats.def || 0) + bonus;
  finalStats.magic = (finalStats.magic || 0) + bonus;
  finalStats.tao = (finalStats.tao || 0) + bonus;
  finalStats.hpMax = (finalStats.hpMax || 0) + bonus * 5; // 生命值加成更高
  
  return finalStats;
}

/**
 * 生成带品质的装备对象
 * @param {string} itemId - 装备 ID
 * @param {string} quality - 品质
 * @returns {Object|null} 装备对象
 */
export function createEquipWithQuality(itemId, quality) {
  const baseEquip = getEquipment(itemId);
  if (!baseEquip) return null;
  
  const finalStats = applyQualityBonus(baseEquip, quality);
  
  return {
    id: crypto.randomUUID(),
    itemId, // 保存原始 ID 用于查询
    type: "equip",
    slot: baseEquip.slot,
    rarity: quality,
    name: `${baseEquip.name}${quality === 'white' ? '' : `·${getQualityName(quality)}`}`,
    stats: finalStats,
    score: calcEquipScore(finalStats),
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now(),
    level: baseEquip.level,
    jobRestriction: baseEquip.jobRestriction
  };
}

/**
 * 获取品质名称
 */
function getQualityName(quality) {
  const names = {
    'white': '',
    'green': '绿',
    'blue': '蓝',
    'purple': '紫',
    'orange': '橙'
  };
  return names[quality] || '';
}

/**
 * 计算装备评分
 */
function calcEquipScore(stats) {
  return (stats.atk || 0) + 
         (stats.def || 0) + 
         (stats.magic || 0) + 
         (stats.tao || 0) + 
         Math.floor((stats.hpMax || 0) / 5);
}

/**
 * 从指定怪物掉落表中随机选择物品
 * @param {string} monsterId - 怪物 ID
 * @returns {Array} 掉落物品列表
 */
export function rollMonsterDrops(monsterId) {
  const monsterData = getMonsterDrops(monsterId);
  if (!monsterData) return [];
  
  const drops = [];
  
  // 遍历所有掉落项
  for (const dropItem of monsterData.drops) {
    // 金币掉落 (必掉)
    if (dropItem.goldMin !== undefined && dropItem.goldMax !== undefined) {
      const gold = Math.floor(Math.random() * (dropItem.goldMax - dropItem.goldMin + 1)) + dropItem.goldMin;
      if (gold > 0) {
        drops.push({ type: 'gold', amount: gold });
      }
    }
    // 装备掉落
    else if (dropItem.equipId && dropItem.chance) {
      if (Math.random() < dropItem.chance) {
        drops.push({ type: 'equip', equipId: dropItem.equipId });
      }
    }
    // 材料掉落
    else if (dropItem.itemId && dropItem.chance) {
      if (Math.random() < dropItem.chance) {
        drops.push({ type: 'material', itemId: dropItem.itemId, name: dropItem.name });
      }
    }
    // 技能书掉落
    else if (dropItem.itemStackId && dropItem.chance) {
      if (Math.random() < dropItem.chance) {
        drops.push({ type: 'skillbook', skillId: dropItem.itemStackId, name: dropItem.name });
      }
    }
    // 套装掉落
    else if (dropItem.equipId && dropItem.chance && dropItem.equipId.startsWith('set_')) {
      if (Math.random() < dropItem.chance) {
        drops.push({ type: 'set', setId: dropItem.equipId, name: dropItem.name });
      }
    }
  }
  
  return drops;
}

/**
 * 根据怪物等级和类型确定品质概率
 * @param {number} monsterLevel - 怪物等级
 * @param {boolean} isBoss - 是否 BOSS
 * @returns {Object} 品质概率表
 */
export function getQualityRates(monsterLevel, isBoss = false) {
  if (isBoss) {
    return { white: 0.30, green: 0.30, blue: 0.25, purple: 0.12, orange: 0.03 };
  }
  
  if (monsterLevel <= 6) {
    // 新手怪
    return { white: 0.70, green: 0.25, blue: 0.05, purple: 0, orange: 0 };
  } else if (monsterLevel <= 15) {
    // 低级怪
    return { white: 0.60, green: 0.30, blue: 0.08, purple: 0.02, orange: 0 };
  } else if (monsterLevel <= 30) {
    // 中级怪
    return { white: 0.50, green: 0.30, blue: 0.15, purple: 0.04, orange: 0.01 };
  } else if (monsterLevel <= 45) {
    // 高级怪
    return { white: 0.40, green: 0.30, blue: 0.20, purple: 0.08, orange: 0.02 };
  } else {
    // 顶级怪
    return { white: 0.35, green: 0.30, blue: 0.20, purple: 0.10, orange: 0.05 };
  }
}

/**
 * 根据概率表随机选择品质
 * @param {Object} rates - 品质概率表
 * @returns {string} 品质
 */
export function pickQuality(rates) {
  const rand = Math.random();
  let cumulative = 0;
  
  for (const [quality, rate] of Object.entries(rates)) {
    cumulative += rate;
    if (rand < cumulative) {
      return quality;
    }
  }
  
  return 'white'; // 默认白色
}

/**
 * 获取技能书对应的职业
 */
export function getSkillJob(skillId) {
  if (!skillsConfig) loadDropConfigs();
  
  // 遍历所有职业技能
  for (const [job, skills] of Object.entries(skillsConfig)) {
    if (skills[skillId]) {
      return job === 'special' ? 'all' : job;
    }
  }
  
  return 'all'; // 特殊技能所有职业可用
}

/**
 * 获取套装部件列表
 */
export function getSetParts(setId) {
  // 根据套装 ID 返回对应的装备 ID 列表
  const setMap = {
    'set_memory': ['ring_memory', 'necklace_memory', 'bracelet_memory'], // 记忆套装
    'set_dragon_legendary': ['weapon_dragon', 'armor_dragon', 'ring_dragon'] // 魔龙套装
  };
  
  return setMap[setId] || [];
}

/**
 * 格式化装备属性显示
 */
export function formatEquipStats(stats) {
  const parts = [];
  if (stats.atk > 0) parts.push(`攻+${stats.atk}`);
  if (stats.def > 0) parts.push(`防+${stats.def}`);
  if (stats.magic > 0) parts.push(`魔+${stats.magic}`);
  if (stats.tao > 0) parts.push(`道+${stats.tao}`);
  if (stats.hpMax > 0) parts.push(`血 +${stats.hpMax}`);
  return parts.join(', ');
}
