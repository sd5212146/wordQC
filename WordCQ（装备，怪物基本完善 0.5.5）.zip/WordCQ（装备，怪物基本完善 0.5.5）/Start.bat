@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "BACKEND_DIR=%~dp0Backend"
set "PORT=3000"
set "URL=http://localhost:%PORT%"

echo ========================================
echo  热血传奇 - 快速启动脚本
echo ========================================
echo.

REM 检查后端目录
if not exist "%BACKEND_DIR%\package.json" (
    echo [ERROR] 后端目录不存在：%BACKEND_DIR%
    pause
    exit /b 1
)

pushd "%BACKEND_DIR%" || goto :cd_failed

REM 检查 Node.js
where node >nul 2>nul
if errorlevel 1 (
    popd
    echo [ERROR] 未找到 Node.js，请先安装 Node.js
    pause
    exit /b 1
)

REM 检查 npm
where npm >nul 2>nul
if errorlevel 1 (
    popd
    echo [ERROR] 未找到 npm，请先安装 Node.js
    pause
    exit /b 1
)

REM 检查依赖是否已安装
if not exist "node_modules\" (
    echo [INFO] 正在安装依赖（使用 npmmirror 镜像）...
    call npm install --registry https://registry.npmmirror.com
    if errorlevel 1 (
        popd
        echo [ERROR] 依赖安装失败
        pause
        exit /b 1
    )
    echo.
)

popd

echo [INFO] 正在启动服务器：%URL%
echo.

REM 启动服务器并打开浏览器
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Start-Process -WorkingDirectory '%BACKEND_DIR%' -FilePath 'node' -ArgumentList 'src/server.js'; " ^
    "Start-Sleep -Milliseconds 800; " ^
    "Start-Process '%URL%';"

echo [INFO] 服务器已启动，浏览器应该自动打开
echo [INFO] 按任意键退出此窗口...
pause >nul
exit /b 0

:cd_failed
echo [ERROR] 无法进入后端目录：%BACKEND_DIR%
pause
exit /b 1
