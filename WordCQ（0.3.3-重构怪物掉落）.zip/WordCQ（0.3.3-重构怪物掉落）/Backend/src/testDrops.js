/**
 * 测试新的掉落系统
 */
import { loadDropConfigs, rollMonsterDrops, getQualityRates, pickQuality } from './dropSystem.js';

console.log('=== 热血传奇掉落系统测试 ===\n');

// 加载配置
loadDropConfigs();
console.log('✓ 配置文件加载成功\n');

// 测试 1: 新手村怪物 - 鸡
console.log('【测试 1】鸡 (新手怪) 掉落表:');
const chickenDrops = rollMonsterDrops('chicken');
console.log(chickenDrops);
console.log('预期：只掉落鸡肉和少量金币，不掉装备\n');

// 测试 2: 僵尸 - 技能书掉落
console.log('【测试 2】僵尸 (中级怪) 掉落表:');
const zombieDrops = rollMonsterDrops('zombie');
console.log(zombieDrops);
console.log('预期：掉落偃月、降魔，低概率掉落火球术、治愈术\n');

// 测试 3: 尸王 - 技能书主要来源
console.log('【测试 3】尸王 (高级怪) 掉落表:');
const zombieKingDrops = rollMonsterDrops('zombie_king');
console.log(zombieKingDrops);
console.log('预期：掉落记忆戒指、祈祷戒指，中高概率掉落雷电术、灵魂火符等\n');

// 测试 4: 沃玛教主 - BOSS 掉落
console.log('【测试 4】沃玛教主 (BOSS) 掉落表:');
const woomaBossDrops = rollMonsterDrops('wooma_boss');
console.log(woomaBossDrops);
console.log('预期：掉落井中月、沃玛首饰、无极棍，概率掉落基础技能书\n');

// 测试 5: 祖玛教主 - 群攻技能
console.log('【测试 5】祖玛教主 (BOSS) 掉落表:');
const zumaBossDrops = rollMonsterDrops('zuma_boss');
console.log(zumaBossDrops);
console.log('预期：掉落裁决、龙纹、骨玉，祖玛首饰，特殊戒指，群攻技能书\n');

// 测试品质概率
console.log('\n=== 品质概率测试 ===');
const testCases = [
  { level: 1, isBoss: false, name: '新手怪' },
  { level: 10, isBoss: false, name: '低级怪' },
  { level: 25, isBoss: false, name: '中级怪' },
  { level: 40, isBoss: false, name: '高级怪' },
  { level: 50, isBoss: true, name: 'BOSS' }
];

for (const tc of testCases) {
  const rates = getQualityRates(tc.level, tc.isBoss);
  console.log(`\n${tc.name} (Lv.${tc.level}, BOSS:${tc.isBoss}):`);
  console.log(`白:${(rates.white * 100).toFixed(0)}% 绿:${(rates.green * 100).toFixed(0)}% 蓝:${(rates.blue * 100).toFixed(0)}% 紫:${(rates.purple * 100).toFixed(0)}% 橙:${(rates.orange * 100).toFixed(0)}%`);
  
  // 模拟 100 次掉落
  const stats = { white: 0, green: 0, blue: 0, purple: 0, orange: 0 };
  for (let i = 0; i < 100; i++) {
    const q = pickQuality(rates);
    stats[q]++;
  }
  console.log(`模拟 100 次：白:${stats.white} 绿:${stats.green} 蓝:${stats.blue} 紫:${stats.purple} 橙:${stats.orange}`);
}

console.log('\n=== 测试完成 ===');
