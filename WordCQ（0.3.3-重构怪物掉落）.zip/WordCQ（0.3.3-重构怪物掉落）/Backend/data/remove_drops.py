import json
import re

# 读取原始文件
with open('gameConfig.json', 'r', encoding='utf-8') as f:
    content = f.read()

# 使用正则表达式移除所有地图的 drops 字段
# 匹配 "drops": { ... } 格式的内容
pattern = r',\s*"drops":\s*\{[^}]*\}'
content = re.sub(pattern, '', content)

# 写回文件
with open('gameConfig.json', 'w', encoding='utf-8') as f:
    f.write(content)

print("已成功移除所有 drops 字段")
