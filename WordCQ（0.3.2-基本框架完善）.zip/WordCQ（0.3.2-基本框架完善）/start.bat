@echo off
setlocal EnableExtensions

set "BACKEND_DIR=%~dp0Backend"
set "PORT=3000"
set "URL=http://localhost:%PORT%"

if not exist "%BACKEND_DIR%\package.json" goto :missing_backend

pushd "%BACKEND_DIR%" || goto :cd_failed

where node >nul 2>nul
if errorlevel 1 goto :node_missing

where npm >nul 2>nul
if errorlevel 1 goto :npm_missing

if exist "node_modules\" goto :run

echo [INFO] Installing dependencies (npmmirror)...
call npm install --registry https://registry.npmmirror.com
if errorlevel 1 goto :npm_install_failed

popd
goto :run

:run
where powershell >nul 2>nul
if errorlevel 1 goto :powershell_missing

echo [INFO] Starting server and opening browser: %URL%
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -WorkingDirectory '%BACKEND_DIR%' -FilePath 'node' -ArgumentList 'src/server.js'; Start-Sleep -Milliseconds 800; Start-Process '%URL%';"
if errorlevel 1 goto :powershell_failed

echo [INFO] Done.
exit /b 0

:missing_backend
echo [ERROR] Backend not found: %BACKEND_DIR%
pause
exit /b 1

:cd_failed
echo [ERROR] Cannot enter: %BACKEND_DIR%
pause
exit /b 1

:node_missing
popd
echo [ERROR] node not found in PATH
pause
exit /b 1

:npm_missing
popd
echo [ERROR] npm not found in PATH
pause
exit /b 1

:npm_install_failed
popd
echo [ERROR] npm install failed
pause
exit /b 1

:powershell_missing
echo [ERROR] powershell not found in PATH
pause
exit /b 1

:powershell_failed
echo [ERROR] failed to start server/browser via powershell
pause
exit /b 1
