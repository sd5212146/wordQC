import crypto from "node:crypto";

const RARITY_ORDER = ["white", "green", "blue", "purple", "orange"];

const DEFAULT_CONFIG = {
  tickMs: 1500,
  logMax: 300,
  offlineMaxSeconds: 4 * 60 * 60,
  elite: { chance: 0.05, hpMul: 1.6, atkMul: 1.25, defMul: 1.2 },
  jobs: {
    warrior: { name: "战士", hpMax: 120, atk: 8, magic: 0, tao: 0, def: 5 },
    mage: { name: "法师", hpMax: 95, atk: 0, magic: 10, tao: 0, def: 4 },
    taoist: { name: "道士", hpMax: 110, atk: 0, magic: 0, tao: 9, def: 4 }
  },
  jobMpMax: { warrior: 40, mage: 90, taoist: 70 },
  jobRegen: {
    warrior: { hp: 3, mp: 2 },
    mage: { hp: 2, mp: 4 },
    taoist: { hp: 3, mp: 3 }
  },
  shopItems: [
    { id: "hp_small", name: "小金创药", priceGold: 25, healHp: 35, healMp: 0 },
    { id: "hp_mid", name: "中金创药", priceGold: 90, healHp: 120, healMp: 0 },
    { id: "mp_small", name: "小魔法药", priceGold: 30, healHp: 0, healMp: 40 },
    { id: "mp_mid", name: "中魔法药", priceGold: 110, healHp: 0, healMp: 140 }
  ],
  shopByTown: {
    novice_village: [
      { id: "nv_hp_small", name: "小金创药", priceGold: 25, healHp: 35 },
      { id: "nv_mp_small", name: "小魔法药", priceGold: 30, healMp: 40 },
      { id: "nv_hp_mid", name: "中金创药", priceGold: 90, healHp: 120 },
      { id: "nv_weapon_green", name: "青铜剑", priceGold: 120, grantEquipSlot: "weapon", grantRarity: "green" },
      { id: "nv_armor_white", name: "布衣", priceGold: 60, grantEquipSlot: "armor", grantRarity: "white" }
    ],
    bichi_city: [
      { id: "bc_hp_mid", name: "中金创药", priceGold: 90, healHp: 120 },
      { id: "bc_mp_mid", name: "中魔法药", priceGold: 110, healMp: 140 },
      { id: "bc_weapon_green", name: "战刃", priceGold: 260, grantEquipSlot: "weapon", grantRarity: "green" },
      { id: "bc_armor_green", name: "皮甲", priceGold: 240, grantEquipSlot: "armor", grantRarity: "green" }
    ],
    mengzhong_city: [
      { id: "mz_hp_big", name: "大金创药", priceGold: 220, healHp: 220 },
      { id: "mz_mp_big", name: "大魔法药", priceGold: 240, healMp: 280 },
      { id: "mz_weapon_blue", name: "战刃·蓝", priceGold: 680, grantEquipSlot: "weapon", grantRarity: "blue" },
      { id: "mz_armor_blue", name: "重甲·蓝", priceGold: 620, grantEquipSlot: "armor", grantRarity: "blue" }
    ]
  },
  skills: {
    warrior: [
      { id: "slaying", name: "攻杀剑术", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.15, learnLevel: 19, trainNeed: { 1: 40, 2: 120, 3: 260 } },
      { id: "thrusting", name: "刺杀剑术", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.25, learnLevel: 25, trainNeed: { 1: 60, 2: 180, 3: 360 } },
      { id: "halfmoon", name: "半月弯刀", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.18, learnLevel: 28, trainNeed: { 1: 80, 2: 220, 3: 420 } },
      { id: "flame_sword", name: "烈火剑法", type: "active", style: "melee", mpCost: 12, range: 1, dmgMul: 1.6, learnLevel: 35, trainNeed: { 1: 120, 2: 360, 3: 720 } },
      { id: "fencing", name: "基本剑术", type: "passive", style: "passive", mpCost: 0, learnLevel: 7, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { atk: 1 } }
    ],
    mage: [
      { id: "fireball", name: "火球术", type: "active", style: "ranged", mpCost: 4, range: 3, dmgMul: 1.15, learnLevel: 7, trainNeed: { 1: 40, 2: 120, 3: 240 } },
      { id: "lightning", name: "雷电术", type: "active", style: "ranged", mpCost: 10, range: 4, dmgMul: 1.55, learnLevel: 17, trainNeed: { 1: 80, 2: 240, 3: 520 } },
      { id: "firewall", name: "火墙", type: "active", style: "ranged", mpCost: 18, range: 4, dmgMul: 1.25, learnLevel: 24, trainNeed: { 1: 120, 2: 360, 3: 760 } },
      { id: "ice_storm", name: "冰咆哮", type: "active", style: "ranged", mpCost: 28, range: 4, dmgMul: 1.75, learnLevel: 35, trainNeed: { 1: 160, 2: 520, 3: 980 } },
      { id: "magic_mastery", name: "魔法掌握", type: "passive", style: "passive", mpCost: 0, learnLevel: 9, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { atk: 1 } }
    ],
    taoist: [
      { id: "poisoning", name: "施毒术", type: "active", style: "ranged", mpCost: 8, range: 3, dmgMul: 1.05, learnLevel: 14, trainNeed: { 1: 60, 2: 180, 3: 360 } },
      { id: "soul_fireball", name: "灵魂火符", type: "active", style: "ranged", mpCost: 6, range: 3, dmgMul: 1.25, learnLevel: 18, trainNeed: { 1: 80, 2: 240, 3: 520 } },
      { id: "summon", name: "召唤神兽", type: "active", style: "ranged", mpCost: 22, range: 3, dmgMul: 1.4, learnLevel: 35, trainNeed: { 1: 180, 2: 520, 3: 980 } },
      { id: "discipline", name: "修行", type: "passive", style: "passive", mpCost: 0, learnLevel: 7, trainNeed: { 1: 30, 2: 90, 3: 200 }, bonus: { def: 1 } }
    ],
    monster: {
      melee: { id: "claw", name: "撕咬", style: "melee", dmgMul: 1.0 },
      ranged: { id: "shoot", name: "远程攻击", style: "ranged", dmgMul: 1.0 }
    }
  },
  maps: [
    {
      id: "novice_village",
      name: "新手村",
      recommendPower: 0,
      themeColor: "#22c55e",
      isTown: true,
      returnTownId: "novice_village",
      monsterAtkMul: 0.65,
      unlockBy: null,
      monsters: [
        { id: "chicken", weight: 35 },
        { id: "deer", weight: 20 },
        { id: "scarecrow", weight: 25 },
        { id: "rake_cat", weight: 20 }
      ],
      drops: { goldMin: 1, goldMax: 3, equipChance: 0.001, maxRarity: "green" }
    },
    {
      id: "bichi_city",
      name: "比奇城",
      recommendPower: 60,
      themeColor: "#3b82f6",
      isTown: true,
      returnTownId: "bichi_city",
      unlockBy: { type: "mapClear", mapId: "novice_village" },
      monsters: [],
      drops: { goldMin: 0, goldMax: 0, equipChance: 0, maxRarity: "white" }
    },
    {
      id: "bichi_outskirts",
      name: "比奇城郊",
      recommendPower: 80,
      themeColor: "#06b6d4",
      isTown: false,
      returnTownId: "bichi_city",
      minLevel: 4,
      monsterAtkMul: 0.85,
      unlockBy: { type: "mapClear", mapId: "novice_village" },
      monsters: [
        { id: "half_orc", weight: 30 },
        { id: "multi_hook_cat", weight: 25 },
        { id: "forest_snowman", weight: 20 },
        { id: "rake_cat", weight: 25 }
      ],
      drops: { goldMin: 2, goldMax: 6, equipChance: 0.0012, maxRarity: "blue" }
    },
    {
      id: "mengzhong_path",
      name: "盟重小径",
      recommendPower: 120,
      themeColor: "#14b8a6",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 6,
      unlockBy: { type: "mapClear", mapId: "novice_village" },
      monsters: [
        { id: "wolf", weight: 40 },
        { id: "sand_worm", weight: 30 },
        { id: "shell_nipper", weight: 30 }
      ],
      drops: { goldMin: 2, goldMax: 7, equipChance: 0.0013, maxRarity: "blue" }
    },
    {
      id: "mengzhong_city",
      name: "盟重土城",
      recommendPower: 220,
      themeColor: "#f59e0b",
      isTown: true,
      returnTownId: "mengzhong_city",
      unlockBy: { type: "mapClear", mapId: "bichi_outskirts" },
      monsters: [],
      drops: { goldMin: 0, goldMax: 0, equipChance: 0, maxRarity: "white" }
    },
    {
      id: "wooma_forest",
      name: "沃玛森林",
      recommendPower: 180,
      themeColor: "#16a34a",
      isTown: false,
      returnTownId: "bichi_city",
      minLevel: 8,
      unlockBy: { type: "mapClear", mapId: "bichi_outskirts" },
      monsters: [
        { id: "forest_snowman", weight: 25 },
        { id: "wooma_soldier", weight: 45 },
        { id: "wooma_fighter", weight: 30 }
      ],
      drops: { goldMin: 3, goldMax: 9, equipChance: 0.0015, maxRarity: "blue" }
    },
    {
      id: "luye_plain",
      name: "鹿野平原",
      recommendPower: 160,
      themeColor: "#10b981",
      isTown: false,
      returnTownId: "bichi_city",
      unlockBy: { type: "mapClear", mapId: "bichi_outskirts" },
      monsters: [
        { id: "deer", weight: 30 },
        { id: "wolf", weight: 40 },
        { id: "multi_hook_cat", weight: 30 }
      ],
      drops: { goldMin: 3, goldMax: 8, equipChance: 0.0015, maxRarity: "blue" }
    },
    {
      id: "snake_valley",
      name: "毒蛇山谷",
      recommendPower: 220,
      themeColor: "#8b5cf6",
      isTown: false,
      returnTownId: "bichi_city",
      minLevel: 10,
      unlockBy: { type: "mapClear", mapId: "wooma_forest" },
      monsters: [
        { id: "red_snake", weight: 55 },
        { id: "tiger_snake", weight: 45 }
      ],
      drops: { goldMin: 3, goldMax: 10, equipChance: 0.0015, maxRarity: "blue" }
    },
    {
      id: "mengzhong_outskirts",
      name: "盟重土城郊外",
      recommendPower: 320,
      themeColor: "#eab308",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 12,
      unlockBy: { type: "mapClear", mapId: "snake_valley" },
      monsters: [
        { id: "wolf", weight: 30 },
        { id: "sand_worm", weight: 35 },
        { id: "shell_nipper", weight: 35 }
      ],
      drops: { goldMin: 4, goldMax: 14, equipChance: 0.0018, maxRarity: "blue" }
    },
    {
      id: "mine",
      name: "矿洞",
      recommendPower: 380,
      themeColor: "#64748b",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 15,
      unlockBy: { type: "mapClear", mapId: "mengzhong_outskirts" },
      monsters: [
        { id: "zombie", weight: 70 },
        { id: "zombie_king", weight: 30 }
      ],
      drops: { goldMin: 5, goldMax: 18, equipChance: 0.002, maxRarity: "blue" }
    },
    {
      id: "pig_cave_1",
      name: "石墓一层（猪洞）",
      recommendPower: 520,
      themeColor: "#fb7185",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 20,
      unlockBy: { type: "mapClear", mapId: "mine" },
      monsters: [
        { id: "red_boar", weight: 45 },
        { id: "black_boar", weight: 35 },
        { id: "moth", weight: 20 }
      ],
      drops: { goldMin: 6, goldMax: 22, equipChance: 0.0022, maxRarity: "purple" }
    },
    {
      id: "centipede_cave",
      name: "蜈蚣洞",
      recommendPower: 680,
      themeColor: "#84cc16",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 26,
      unlockBy: { type: "mapClear", mapId: "pig_cave_1" },
      monsters: [
        { id: "centipede", weight: 35 },
        { id: "bee", weight: 25 },
        { id: "tongs", weight: 25 },
        { id: "evil_tongs", weight: 15 }
      ],
      drops: { goldMin: 7, goldMax: 26, equipChance: 0.0024, maxRarity: "purple" }
    },
    {
      id: "zuma_temple",
      name: "祖玛寺庙",
      recommendPower: 920,
      themeColor: "#6366f1",
      isTown: false,
      returnTownId: "bichi_city",
      minLevel: 32,
      unlockBy: { type: "mapClear", mapId: "centipede_cave" },
      monsters: [
        { id: "zuma_statue", weight: 40 },
        { id: "zuma_guardian", weight: 35 },
        { id: "zuma_archer", weight: 25 }
      ],
      drops: { goldMin: 8, goldMax: 30, equipChance: 0.0026, maxRarity: "purple" }
    },
    {
      id: "fengmo_valley",
      name: "封魔谷",
      recommendPower: 1150,
      themeColor: "#f43f5e",
      isTown: false,
      returnTownId: "bichi_city",
      minLevel: 40,
      unlockBy: { type: "mapClear", mapId: "zuma_temple" },
      monsters: [
        { id: "hongmo_boar_guard", weight: 55 },
        { id: "hongmo_scorpion_guard", weight: 45 }
      ],
      drops: { goldMin: 10, goldMax: 38, equipChance: 0.0026, maxRarity: "purple" }
    },
    {
      id: "chiyue_canyon",
      name: "赤月峡谷",
      recommendPower: 1450,
      themeColor: "#f97316",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 45,
      unlockBy: { type: "mapClear", mapId: "fengmo_valley" },
      monsters: [
        { id: "moon_spider", weight: 35 },
        { id: "kiss_spider", weight: 35 },
        { id: "fang_spider", weight: 30 }
      ],
      drops: { goldMin: 12, goldMax: 45, equipChance: 0.0024, maxRarity: "orange" }
    },
    {
      id: "cangyue_island",
      name: "苍月岛（骨魔/牛魔）",
      recommendPower: 1750,
      themeColor: "#a855f7",
      isTown: false,
      returnTownId: "mengzhong_city",
      minLevel: 50,
      unlockBy: { type: "mapClear", mapId: "chiyue_canyon" },
      monsters: [
        { id: "bone_demon", weight: 45 },
        { id: "minotaur_warrior", weight: 35 },
        { id: "minotaur_mage", weight: 20 }
      ],
      drops: { goldMin: 14, goldMax: 55, equipChance: 0.0022, maxRarity: "orange" }
    }
  ],
  monsters: {
    chicken: { name: "鸡", level: 1, hp: 18, atk: 4, def: 0, exp: 1, range: 1 },
    deer: { name: "鹿", level: 1, hp: 22, atk: 5, def: 1, exp: 1, range: 1 },
    scarecrow: { name: "稻草人", level: 2, hp: 30, atk: 6, def: 1, exp: 1, range: 1 },
    rake_cat: { name: "钉耙猫", level: 3, hp: 34, atk: 7, def: 2, exp: 2, range: 1 },
    half_orc: { name: "半兽人", level: 5, hp: 55, atk: 10, def: 3, exp: 3, range: 1 },
    multi_hook_cat: { name: "多钩猫", level: 5, hp: 50, atk: 10, def: 2, exp: 3, range: 1 },
    forest_snowman: { name: "森林雪人", level: 6, hp: 70, atk: 12, def: 3, exp: 4, range: 1 },
    wooma_soldier: { name: "沃玛战士", level: 10, hp: 120, atk: 18, def: 6, exp: 6, range: 1, skillBookChance: 0.0004 },
    wooma_fighter: { name: "沃玛勇士", level: 12, hp: 150, atk: 22, def: 7, exp: 7, range: 1, skillBookChance: 0.0006 },
    red_snake: { name: "红蛇", level: 13, hp: 160, atk: 24, def: 8, exp: 8, range: 1, skillBookChance: 0.0005 },
    tiger_snake: { name: "虎蛇", level: 15, hp: 185, atk: 26, def: 9, exp: 9, range: 1, skillBookChance: 0.0005 },
    wolf: { name: "狼", level: 16, hp: 200, atk: 28, def: 10, exp: 9, range: 1 },
    sand_worm: { name: "沙虫", level: 17, hp: 220, atk: 30, def: 10, exp: 10, range: 1 },
    shell_nipper: { name: "盔甲虫", level: 18, hp: 240, atk: 31, def: 11, exp: 10, range: 1 },
    zombie: { name: "僵尸", level: 20, hp: 280, atk: 34, def: 12, exp: 11, range: 1 },
    zombie_king: { name: "尸王", level: 25, hp: 520, atk: 46, def: 16, exp: 18, range: 1, skillBookChance: 0.002 },
    red_boar: { name: "红野猪", level: 28, hp: 520, atk: 52, def: 18, exp: 20, range: 1, skillBookChance: 0.0008 },
    black_boar: { name: "黑野猪", level: 29, hp: 560, atk: 56, def: 19, exp: 21, range: 1, skillBookChance: 0.0008 },
    moth: { name: "楔蛾", level: 30, hp: 420, atk: 45, def: 16, exp: 18, range: 1 },
    centipede: { name: "蜈蚣", level: 32, hp: 620, atk: 60, def: 20, exp: 22, range: 1 },
    bee: { name: "跳跳蜂", level: 33, hp: 520, atk: 58, def: 19, exp: 22, range: 1 },
    tongs: { name: "钳虫", level: 34, hp: 720, atk: 66, def: 22, exp: 24, range: 1 },
    evil_tongs: { name: "邪恶钳虫", level: 36, hp: 900, atk: 78, def: 25, exp: 28, range: 1, skillBookChance: 0.0012 },
    zuma_statue: { name: "祖玛雕像", level: 40, hp: 1100, atk: 92, def: 28, exp: 32, range: 1, skillBookChance: 0.001 },
    zuma_guardian: { name: "祖玛卫士", level: 41, hp: 1250, atk: 98, def: 30, exp: 34, range: 1, skillBookChance: 0.001 },
    zuma_archer: { name: "祖玛弓箭手", level: 42, hp: 980, atk: 90, def: 26, exp: 34, range: 4, skillBookChance: 0.001 },
    hongmo_boar_guard: { name: "虹魔猪卫", level: 45, hp: 1500, atk: 110, def: 34, exp: 40, range: 1, skillBookChance: 0.0011 },
    hongmo_scorpion_guard: { name: "虹魔蝎卫", level: 46, hp: 1600, atk: 116, def: 35, exp: 42, range: 1, skillBookChance: 0.0011 },
    moon_spider: { name: "月魔蜘蛛", level: 50, hp: 1750, atk: 128, def: 38, exp: 50, range: 1, skillBookChance: 0.001 },
    kiss_spider: { name: "花吻蜘蛛", level: 51, hp: 1650, atk: 126, def: 37, exp: 50, range: 1, skillBookChance: 0.001 },
    fang_spider: { name: "钢牙蜘蛛", level: 52, hp: 1900, atk: 135, def: 40, exp: 56, range: 1, skillBookChance: 0.001 },
    bone_demon: { name: "骨魔", level: 55, hp: 2100, atk: 148, def: 44, exp: 62, range: 1, skillBookChance: 0.001 },
    minotaur_warrior: { name: "牛魔战士", level: 56, hp: 2250, atk: 156, def: 46, exp: 66, range: 1, skillBookChance: 0.001 },
    minotaur_mage: { name: "牛魔法师", level: 57, hp: 1950, atk: 150, def: 42, exp: 66, range: 4, skillBookChance: 0.001 }
  },
  equipSlots: ["weapon", "armor", "shoes", "head", "ring", "bracelet", "necklace", "medal"],
  equipSlotNames: { weapon: "武器", armor: "装甲", shoes: "脚部", head: "头部", ring: "戒指", bracelet: "护腕", necklace: "项链", medal: "勋章" },
  rarityWeights: { white: 700, green: 220, blue: 70, purple: 9, orange: 1 },
  rarityName: { white: "白", green: "绿", blue: "蓝", purple: "紫", orange: "橙" },
  equipBaseBySlot: {
    weapon: { atk: 6, magic: 6, tao: 6, def: 0, hpMax: 0 },
    armor: { atk: 0, magic: 0, tao: 0, def: 4, hpMax: 15 },
    shoes: { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 8 },
    head: { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 10 },
    ring: { atk: 2, magic: 2, tao: 2, def: 0, hpMax: 0 },
    bracelet: { atk: 1, magic: 1, tao: 1, def: 1, hpMax: 4 },
    necklace: { atk: 2, magic: 2, tao: 2, def: 0, hpMax: 0 },
    medal: { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 20 }
  },
  equipRarityMultiplier: { white: 1.0, green: 1.15, blue: 1.35, purple: 1.7, orange: 2.2 },
  strengthen: {
    baseGoldCost: 30,
    goldCostGrowth: 1.25,
    maxLevel: 10,
    successRate: 1.0,
    gainBySlot: {
      weapon: { atk: 2, def: 0, hpMax: 0 },
      armor: { atk: 0, def: 2, hpMax: 10 },
      shoes: { atk: 0, def: 1, hpMax: 6 },
      head: { atk: 0, def: 2, hpMax: 8 },
      ring: { atk: 1, def: 0, hpMax: 0 },
      bracelet: { atk: 1, def: 1, hpMax: 4 },
      necklace: { atk: 1, def: 0, hpMax: 0 },
      medal: { atk: 0, def: 2, hpMax: 12 }
    }
  },
  mapClearRule: {
    killsToClear: 15
  }
};

export function createNewSave({ config = DEFAULT_CONFIG } = {}) {
  return {
    config,
    player: null,
    progress: {
      currentMapId: config.maps[0]?.id ?? "novice_village",
      mapKills: {},
      mapCleared: {}
    },
    runtime: {
      isRunning: false,
      lastTickAt: Date.now(),
      lastBattle: null,
      board: null,
      lastFrame: null
    },
    logs: []
  };
}

export function migrateSave(save) {
  if (!save || typeof save !== "object") return false;
  if (!save.config || typeof save.config !== "object") save.config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));

  let changed = false;
  const applyMax = (obj, key, maxValue) => {
    if (!obj || typeof obj !== "object") return;
    const cur = obj[key];
    if (cur == null || Number(cur) > Number(maxValue)) {
      obj[key] = maxValue;
      changed = true;
    }
  };

  save.config.jobs ??= {};
  for (const [jobId, def] of Object.entries(DEFAULT_CONFIG.jobs)) {
    save.config.jobs[jobId] ??= { ...def };
    const cur = save.config.jobs[jobId];
    applyMax(cur, "hpMax", def.hpMax);
    applyMax(cur, "atk", def.atk);
    applyMax(cur, "def", def.def);
    if (cur.name == null) {
      cur.name = def.name;
      changed = true;
    }
  }

  if (!Array.isArray(save.config.maps)) save.config.maps = [];
  {
    const have = new Set(save.config.maps.map((m) => m.id));
    for (const defMap of DEFAULT_CONFIG.maps) {
      if (!have.has(defMap.id)) {
        save.config.maps.push(JSON.parse(JSON.stringify(defMap)));
        changed = true;
      }
    }
    for (const m of save.config.maps) {
      const defMap = DEFAULT_CONFIG.maps.find((x) => x.id === m?.id);
      if (!defMap) continue;
      if (defMap.isTown != null && m.isTown !== defMap.isTown) {
        m.isTown = defMap.isTown;
        changed = true;
      }
      if (defMap.themeColor != null && m.themeColor !== defMap.themeColor) {
        m.themeColor = defMap.themeColor;
        changed = true;
      }
      m.returnTownId ??= defMap.returnTownId;
      if (defMap.recommendPower != null && Number(m.recommendPower ?? 0) !== Number(defMap.recommendPower)) {
        m.recommendPower = defMap.recommendPower;
        changed = true;
      }
      if (m.minLevel == null && defMap.minLevel != null) m.minLevel = defMap.minLevel;
      if (m.monsterAtkMul == null && defMap.monsterAtkMul != null) m.monsterAtkMul = defMap.monsterAtkMul;
      if (!Array.isArray(m.monsters) || m.monsters.length <= 0) m.monsters = JSON.parse(JSON.stringify(defMap.monsters));
      m.drops ??= {};
      applyMax(m.drops, "equipChance", defMap.drops.equipChance);
      if (m.drops.goldMin == null) {
        m.drops.goldMin = defMap.drops.goldMin;
        changed = true;
      }
      if (m.drops.goldMax == null) {
        m.drops.goldMax = defMap.drops.goldMax;
        changed = true;
      }
      if (m.drops.maxRarity == null) {
        m.drops.maxRarity = defMap.drops.maxRarity;
        changed = true;
      }
    }
  }

  if (!Array.isArray(save.config.shopItems) || save.config.shopItems.length <= 0) {
    save.config.shopItems = JSON.parse(JSON.stringify(DEFAULT_CONFIG.shopItems));
    changed = true;
  }

  save.config.monsters ??= {};
  for (const [mid, def] of Object.entries(DEFAULT_CONFIG.monsters)) {
    save.config.monsters[mid] ??= { ...def };
    const cur = save.config.monsters[mid];
    if (cur.name == null) {
      cur.name = def.name;
      changed = true;
    }
    applyMax(cur, "atk", def.atk);
    applyMax(cur, "def", def.def);
    applyMax(cur, "hp", def.hp);
    if (cur.level == null) {
      cur.level = def.level;
      changed = true;
    }
    if (cur.exp == null) {
      cur.exp = def.exp;
      changed = true;
    }
    if (cur.range == null) {
      cur.range = def.range ?? 1;
      changed = true;
    }
  }

  save.runtime ??= { isRunning: false, lastTickAt: Date.now() };
  if (!("lastBattle" in save.runtime)) {
    save.runtime.lastBattle = null;
    changed = true;
  }
  if (!("board" in save.runtime)) {
    save.runtime.board = null;
    changed = true;
  }
  if (!("lastFrame" in save.runtime)) {
    save.runtime.lastFrame = null;
    changed = true;
  }

  if (save.player && changed) {
    recomputeDerivedStats(save);
  }
  if (save.player) {
    save.player.settings ??= {};
    if (save.player.settings.autoEquip == null) {
      save.player.settings.autoEquip = true;
      changed = true;
    }
    if (save.player.settings.autoRecycle == null) {
      save.player.settings.autoRecycle = false;
      changed = true;
    }
    if (!RARITY_ORDER.includes(String(save.player.settings.recycleRarityThreshold ?? ""))) {
      save.player.settings.recycleRarityThreshold = "white";
      changed = true;
    }
    if (save.player.settings.autoHpPotionPct == null) {
      save.player.settings.autoHpPotionPct = 35;
      changed = true;
    }
    if (save.player.settings.autoMpPotionPct == null) {
      save.player.settings.autoMpPotionPct = 35;
      changed = true;
    }
    save.player.settings.autoHpPotionPct = clampPct(save.player.settings.autoHpPotionPct);
    save.player.settings.autoMpPotionPct = clampPct(save.player.settings.autoMpPotionPct);
    if (save.player.mpMax == null) {
      save.player.mpMax = save.config.jobMpMax?.[save.player.job] ?? 50;
      changed = true;
    }
    if (save.player.mp == null) {
      save.player.mp = save.player.mpMax;
      changed = true;
    }
    save.player.skills ??= { activeId: null, activeIds: [], passiveIds: [], levels: {} };
    if (!("activeId" in save.player.skills)) {
      save.player.skills.activeId = null;
      changed = true;
    }
    save.player.skills.activeIds ??= [];
    save.player.skills.passiveIds ??= [];
    save.player.skills.levels ??= {};
    save.player.equipped ??= {};
    for (const slot of DEFAULT_CONFIG.equipSlots) {
      if (!(slot in save.player.equipped)) {
        save.player.equipped[slot] = null;
        changed = true;
      }
    }
  }
  if (!save.config.elite || typeof save.config.elite !== "object") {
    save.config.elite = { ...DEFAULT_CONFIG.elite };
    changed = true;
  } else {
    save.config.elite.chance ??= DEFAULT_CONFIG.elite.chance;
    save.config.elite.hpMul ??= DEFAULT_CONFIG.elite.hpMul;
    save.config.elite.atkMul ??= DEFAULT_CONFIG.elite.atkMul;
    save.config.elite.defMul ??= DEFAULT_CONFIG.elite.defMul;
  }
  return changed;
}

export function canEnterMap(save, mapId) {
  const map = save.config.maps.find((m) => m.id === mapId);
  if (!map) return { ok: false, reason: "地图不存在" };
  if (save.player && map.minLevel != null) {
    if (save.player.level < map.minLevel) {
      return { ok: false, reason: `等级不足（需 Lv.${map.minLevel}）` };
    }
  }
  if (save.player) {
    const power = calcPowerScore(save.player.atk, save.player.def, save.player.hpMax);
    if (power < (map.recommendPower ?? 0)) {
      return { ok: false, reason: "战力不足" };
    }
  }
  if (!map.unlockBy) return { ok: true };
  if (map.unlockBy.type === "mapClear") {
    const cleared = !!save.progress.mapCleared[map.unlockBy.mapId];
    return cleared ? { ok: true } : { ok: false, reason: "未解锁" };
  }
  return { ok: false, reason: "未解锁" };
}

export function createPlayer(save, { name, job }) {
  const jobDef = save.config.jobs[job];
  if (!jobDef) throw new Error("未知职业");
  const playerId = crypto.randomUUID();
  save.player = {
    id: playerId,
    name: String(name || "").trim().slice(0, 12) || "无名勇士",
    job,
    level: 1,
    exp: 0,
    expToNext: 50,
    hpMax: jobDef.hpMax,
    hp: jobDef.hpMax,
    mpMax: (save.config.jobMpMax?.[job] ?? 50),
    mp: (save.config.jobMpMax?.[job] ?? 50),
    atk: jobDef.atk ?? 0,
    def: jobDef.def,
    gold: 50,
    yuanbao: 0,
    settings: {
      autoEquip: true,
      autoRecycle: false,
      recycleRarityThreshold: "white",
      autoHpPotionPct: 35,
      autoMpPotionPct: 35
    },
    skills: {
      activeId: null,
      activeIds: [],
      passiveIds: [],
      levels: {}
    },
    equipped: Object.fromEntries((save.config.equipSlots ?? DEFAULT_CONFIG.equipSlots).map((s) => [s, null])),
    inventory: []
  };
  pushLog(save, "system", `创建角色：${save.player.name}（${jobDef.name}）`);
  // 初始装备：按职业主属性提供新手套装
  const starter = createStarterEquip(save.config, job);
  for (const it of Object.values(starter)) {
    save.player.inventory.push(it);
    equipItem(save, it.id);
  }
  const map = save.config.maps.find((m) => m.id === save.progress.currentMapId) ?? save.config.maps[0];
  if (save.runtime && map) {
    save.runtime.board = initBoardForMap(save, map);
    save.runtime.lastFrame = null;
    pushLog(save, "system", `进入场景：${map.name}（6x6）`);
  }
}

export function setRunning(save, isRunning) {
  save.runtime.isRunning = !!isRunning;
  save.runtime.lastTickAt = Date.now();
  pushLog(save, "system", isRunning ? "开始挂机" : "停止挂机");
}

export function setCurrentMap(save, mapId) {
  const gate = canEnterMap(save, mapId);
  if (!gate.ok) throw new Error(gate.reason);
  save.progress.currentMapId = mapId;
  const map = save.config.maps.find((m) => m.id === mapId);
  if (save.runtime) {
    save.runtime.board = null;
    save.runtime.lastFrame = null;
    if (save.player && map) {
      save.runtime.board = initBoardForMap(save, map);
      pushLog(save, "system", `进入场景：${map.name}（6x6）`);
    }
  }
  pushLog(save, "system", `前往地图：${map?.name ?? mapId}`);
}

export function settleOffline(save) {
  if (!save.player) return { ticks: 0, logs: [] };
  const now = Date.now();
  const dtSeconds = Math.max(0, Math.floor((now - save.runtime.lastTickAt) / 1000));
  const maxSeconds = save.config.offlineMaxSeconds ?? DEFAULT_CONFIG.offlineMaxSeconds;
  const effectiveSeconds = Math.min(dtSeconds, maxSeconds);
  const tickMs = save.config.tickMs ?? DEFAULT_CONFIG.tickMs;
  const ticks = Math.floor((effectiveSeconds * 1000) / tickMs);
  if (ticks <= 0) {
    save.runtime.lastTickAt = now;
    return { ticks: 0, logs: [] };
  }
  const result = runTicks(save, ticks);
  pushLog(save, "system", `离线结算：${effectiveSeconds}s，补算 ${ticks} 次`);
  save.runtime.lastTickAt = now;
  return result;
}

export function runTicks(save, count) {
  if (!save.player) return { ticks: 0, logs: [] };
  const beforeLogIndex = save.logs.length;
  const ticks = Math.max(0, Math.min(Number(count) || 0, 200));
  for (let i = 0; i < ticks; i += 1) {
    if (!save.runtime.isRunning) break;
    runSingleTick(save);
  }
  save.runtime.lastTickAt = Date.now();
  const newLogs = save.logs.slice(beforeLogIndex);
  return { ticks, logs: newLogs };
}

export function recycleItems(save, itemIds) {
  if (!save.player) throw new Error("未创建角色");
  const idSet = new Set((itemIds ?? []).map(String));
  const before = save.player.inventory.length;
  let goldGain = 0;
  let skippedEquipped = 0;
  save.player.inventory = save.player.inventory.filter((it) => {
    if (!idSet.has(it.id)) return true;
    if (it.locked) return true;
    if (it.equipped) {
      skippedEquipped += 1;
      return true;
    }
    goldGain += getRecycleValue(save.config, it);
    return false;
  });
  const removed = before - save.player.inventory.length;
  if (removed <= 0) return { removed: 0, goldGain: 0 };
  save.player.gold += goldGain;
  pushLog(save, "loot", `回收装备 ${removed} 件，获得金币 +${goldGain}`);
  if (skippedEquipped > 0) {
    pushLog(save, "system", `已跳过穿戴中的装备 ${skippedEquipped} 件`);
  }
  return { removed, goldGain };
}

export function strengthenEquipped(save, slot) {
  if (!save.player) throw new Error("未创建角色");
  if (!save.config.equipSlots.includes(slot)) throw new Error("未知部位");
  const eq = save.player.equipped[slot];
  if (!eq) throw new Error("该部位未穿戴装备");
  const maxLevel = save.config.strengthen.maxLevel ?? DEFAULT_CONFIG.strengthen.maxLevel;
  if (eq.strengthenLevel >= maxLevel) throw new Error("已达强化上限");
  const cost = getStrengthenCost(save.config, eq.strengthenLevel + 1);
  if (save.player.gold < cost) throw new Error("金币不足");
  save.player.gold -= cost;
  const success = Math.random() < (save.config.strengthen.successRate ?? 1.0);
  if (!success) {
    pushLog(save, "system", `强化失败：${save.config.equipSlotNames[slot]}（消耗金币 ${cost}）`);
    return { success: false, cost };
  }
  eq.strengthenLevel += 1;
  recomputeDerivedStats(save);
  pushLog(save, "system", `强化成功：${save.config.equipSlotNames[slot]} +${eq.strengthenLevel}（消耗金币 ${cost}）`);
  return { success: true, cost };
}

export function equipItem(save, itemId) {
  if (!save.player) throw new Error("未创建角色");
  const item = save.player.inventory.find((it) => it.id === itemId);
  if (!item) throw new Error("物品不存在");
  if (item.type !== "equip") throw new Error("不是装备");
  const slot = item.slot;
  if (!save.config.equipSlots.includes(slot)) throw new Error("未知部位");
  const prev = save.player.equipped[slot];
  if (prev?.id === item.id) {
    pushLog(save, "system", `已穿戴：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
    return;
  }
  save.player.equipped[slot] = item;
  item.equipped = true;
  if (prev) prev.equipped = false;
  recomputeDerivedStats(save);
  pushLog(save, "system", `穿戴：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
}

export function unequipItem(save, itemId) {
  if (!save.player) throw new Error("未创建角色");
  const item = save.player.inventory.find((it) => it.id === itemId);
  if (!item) throw new Error("物品不存在");
  if (item.type !== "equip") throw new Error("不是装备");
  const slot = item.slot;
  if (!save.config.equipSlots.includes(slot)) throw new Error("未知部位");
  const cur = save.player.equipped[slot];
  if (!cur || cur.id !== item.id) throw new Error("该装备未穿戴");
  save.player.equipped[slot] = null;
  item.equipped = false;
  recomputeDerivedStats(save);
  pushLog(save, "system", `卸下：${formatEquip(save.config, item)}（${save.config.equipSlotNames[slot]}）`);
}

export function setAutoEquip(save, enabled) {
  if (!save.player) throw new Error("未创建角色");
  save.player.settings.autoEquip = !!enabled;
  pushLog(save, "system", save.player.settings.autoEquip ? "开启自动换装" : "关闭自动换装");
}

export function setAutoRecycle(save, enabled) {
  if (!save.player) throw new Error("未创建角色");
  save.player.settings.autoRecycle = !!enabled;
  pushLog(save, "system", save.player.settings.autoRecycle ? "开启自动回收" : "关闭自动回收");
}

export function setRecycleRarityThreshold(save, threshold) {
  if (!save.player) throw new Error("未创建角色");
  const t = String(threshold ?? "");
  if (!RARITY_ORDER.includes(t)) throw new Error("未知品质");
  save.player.settings.recycleRarityThreshold = t;
  const name = save.config.rarityName?.[t] ?? t;
  pushLog(save, "system", `自动回收品质：${name}及以下`);
}

export function setAutoDrink(save, hpPct, mpPct) {
  if (!save.player) throw new Error("未创建角色");
  save.player.settings.autoHpPotionPct = clampPct(hpPct);
  save.player.settings.autoMpPotionPct = clampPct(mpPct);
  pushLog(
    save,
    "system",
    `自动喝药阈值：HP<${save.player.settings.autoHpPotionPct}% / MP<${save.player.settings.autoMpPotionPct}%`
  );
}

function runSingleTick(save) {
  const map = save.config.maps.find((m) => m.id === save.progress.currentMapId) ?? save.config.maps[0];
  const player = save.player;
  const board = ensureBoard(save, map);
  const frame = { id: crypto.randomUUID(), ts: Date.now(), mapId: map.id, events: [] };

  applyRegen(save);
  maybeAutoDrinkInTown(save, map);
  tickMonstersMove(save, map, board, frame);
  tickPlayerMove(save, map, board, frame);
  tickPlayerAttack(save, map, board, frame);
  if (!save.runtime.isRunning) {
    save.runtime.lastFrame = frame;
    return;
  }
  tickMonstersAttack(save, map, board, frame);

  save.runtime.lastFrame = frame;
}

function applyRegen(save) {
  const p = save.player;
  const regen = save.config.jobRegen?.[p.job] ?? { hp: 1, mp: 1 };
  p.hp = Math.min(p.hpMax, p.hp + Math.max(0, Number(regen.hp ?? 0)));
  p.mp = Math.min(p.mpMax, p.mp + Math.max(0, Number(regen.mp ?? 0)));
}

function ensureBoard(save, map) {
  if (!save.runtime) save.runtime = { isRunning: false, lastTickAt: Date.now(), lastBattle: null, board: null, lastFrame: null };
  const board = save.runtime.board;
  if (board && board.mapId === map.id && board.width === 6 && board.height === 6) {
    board.targetCount = Math.min(5, Number(board.targetCount ?? 5));
    if (board.monsters.length > board.targetCount) {
      board.monsters = board.monsters.slice(0, board.targetCount);
    }
    replenishMonsters(save, map, board);
    return board;
  }
  const next = initBoardForMap(save, map);
  save.runtime.board = next;
  save.runtime.lastFrame = null;
  pushLog(save, "system", `进入场景：${map.name}（6x6）`);
  return next;
}

function initBoardForMap(save, map) {
  const width = 6;
  const height = 6;
  const playerPos = { x: randInt(0, width - 1), y: randInt(0, height - 1) };
  const targetCount = 5;
  const board = {
    id: crypto.randomUUID(),
    mapId: map.id,
    width,
    height,
    player: { x: playerPos.x, y: playerPos.y },
    monsters: [],
    targetCount,
    lastSpawnAt: 0
  };
  replenishMonsters(save, map, board, true);
  return board;
}

function replenishMonsters(save, map, board, forceFull = false) {
  const cap = Math.max(1, Number(board.targetCount ?? 5));
  const now = Date.now();
  const intervalMs = 5000;
  // 初次进入只刷1只；之后每5s少于上限则刷1只
  const canSpawn =
    forceFull ? board.monsters.length < cap : (board.monsters.length < cap && (now - (board.lastSpawnAt ?? 0)) >= intervalMs);
  if (!canSpawn) return;
  const occupied = new Set([posKey(board.player.x, board.player.y)]);
  for (const m of board.monsters) occupied.add(posKey(m.x, m.y));

  const monsterId = pickWeighted(map.monsters);
  const def = save.config.monsters[monsterId];
  if (!def) return;
  const { x, y } = pickEmptyPosAway(board, occupied, board.player.x, board.player.y, 3);
  if (x == null) return;
  const range = Math.max(1, Number(def.range ?? 1));
  const eliteCfg = save.config.elite ?? DEFAULT_CONFIG.elite;
  const isElite = !map.isTown && Math.random() < Number(eliteCfg?.chance ?? DEFAULT_CONFIG.elite.chance);
  const hpMul = isElite ? Number(eliteCfg?.hpMul ?? DEFAULT_CONFIG.elite.hpMul) : 1;
  const atkMul = isElite ? Number(eliteCfg?.atkMul ?? DEFAULT_CONFIG.elite.atkMul) : 1;
  const defMul = isElite ? Number(eliteCfg?.defMul ?? DEFAULT_CONFIG.elite.defMul) : 1;
  const name = isElite ? `精英${def.name}` : def.name;
  const ent = {
    id: crypto.randomUUID(),
    monsterId,
    name,
    level: def.level,
    hpMax: Math.max(1, Math.floor(Number(def.hp) * hpMul)),
    hp: Math.max(1, Math.floor(Number(def.hp) * hpMul)),
    atk: Math.max(1, Math.floor(Number(def.atk) * atkMul)),
    def: Math.max(0, Math.floor(Number(def.def) * defMul)),
    exp: def.exp,
    range,
    isRanged: range > 1,
    isElite,
    skillBookChance: Number(def.skillBookChance ?? 0),
    x,
    y
  };
  board.monsters.push(ent);
  board.lastSpawnAt = now;
}

function selectPlayerActiveSkill(save) {
  const p = save.player;
  const list = (save.config.skills?.[p.job] ?? []).filter((s) => s.type === "active");
  const learned = new Set(p.skills?.activeIds ?? []);
  const chosenId = p.skills?.activeId;
  const chosen = chosenId && learned.has(chosenId) ? list.find((s) => s.id === chosenId) : null;
  const fallback = list.find((s) => learned.has(s.id)) ?? null;
  const prefer = chosen ?? fallback;
  if (!prefer) return { id: "basic_attack", name: "普攻", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.0, learnLevel: 1, trainNeed: { 1: 0, 2: 0, 3: 0 }, level: 1 };
  if (p.level < (prefer.learnLevel ?? 1)) {
    return { id: "basic_attack", name: "普攻", type: "active", style: "melee", mpCost: 0, range: 1, dmgMul: 1.0, learnLevel: 1, trainNeed: { 1: 0, 2: 0, 3: 0 }, level: 1 };
  }
  const lvInfo = p.skills?.levels?.[prefer.id] ?? { level: 1, exp: 0 };
  const lvl = Math.max(1, Math.min(3, Number(lvInfo.level ?? 1)));
  const extraMul = 1 + (lvl - 1) * 0.12;
  return { ...prefer, dmgMul: (prefer.dmgMul ?? 1.0) * extraMul, level: lvl, exp: lvInfo.exp ?? 0 };
}

function tickPlayerMove(save, map, board, frame) {
  const skill = selectPlayerActiveSkill(save);
  const targetInRange = pickNearestMonster(board, board.player.x, board.player.y, skill.range);
  if (targetInRange) return;
  const nearest = pickNearestMonster(board, board.player.x, board.player.y, Infinity);
  if (!nearest) return;
  const step = stepToward(board.player.x, board.player.y, nearest.x, nearest.y);
  if (!step) return;
  const occupied = new Set(board.monsters.map((m) => posKey(m.x, m.y)));
  const candidates = [step, step.alt].filter(Boolean);
  for (const to of candidates) {
    if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
    const keyTo = posKey(to.x, to.y);
    if (occupied.has(keyTo)) continue;
    const from = { x: board.player.x, y: board.player.y };
    board.player.x = to.x;
    board.player.y = to.y;
    frame.events.push({ type: "move", entityId: "player", from, to: { x: to.x, y: to.y } });
    break;
  }
}

function pickEmptyPos(board, occupied) {
  const tries = 50;
  for (let i = 0; i < tries; i += 1) {
    const x = randInt(0, board.width - 1);
    const y = randInt(0, board.height - 1);
    const key = posKey(x, y);
    if (!occupied.has(key)) return { x, y };
  }
  for (let y = 0; y < board.height; y += 1) {
    for (let x = 0; x < board.width; x += 1) {
      const key = posKey(x, y);
      if (!occupied.has(key)) return { x, y };
    }
  }
  return { x: null, y: null };
}

function pickEmptyPosAway(board, occupied, px, py, minDist) {
  const attempt = (d, tries) => {
    for (let i = 0; i < tries; i += 1) {
      const x = randInt(0, board.width - 1);
      const y = randInt(0, board.height - 1);
      const key = posKey(x, y);
      if (occupied.has(key)) continue;
      const dist = Math.abs(x - px) + Math.abs(y - py);
      if (dist >= d) return { x, y };
    }
    return null;
  };
  const first = attempt(Math.max(0, Number(minDist ?? 0)), 80);
  if (first) return first;
  const second = attempt(2, 80);
  if (second) return second;
  return pickEmptyPos(board, occupied);
}

function tickMonstersMove(save, map, board, frame) {
  const occupied = new Map();
  occupied.set(posKey(board.player.x, board.player.y), "player");
  for (const m of board.monsters) occupied.set(posKey(m.x, m.y), m.id);

  for (const m of board.monsters) {
    if (m.isRanged) continue;
    const dist = manhattan(m.x, m.y, board.player.x, board.player.y);
    if (dist <= 1) continue;
    const from = { x: m.x, y: m.y };
    const step = stepToward(m.x, m.y, board.player.x, board.player.y);
    if (!step) continue;
    const candidates = [step, step.alt].filter(Boolean);
    let moved = false;
    for (const to of candidates) {
      if (to.x === board.player.x && to.y === board.player.y) continue;
      if (to.x < 0 || to.x >= board.width || to.y < 0 || to.y >= board.height) continue;
      const keyTo = posKey(to.x, to.y);
      if (occupied.has(keyTo)) continue;
      occupied.delete(posKey(from.x, from.y));
      occupied.set(keyTo, m.id);
      m.x = to.x;
      m.y = to.y;
      frame.events.push({ type: "move", entityId: m.id, from, to: { x: m.x, y: m.y } });
      moved = true;
      break;
    }
    if (moved) continue;
  }
}

function tickPlayerAttack(save, map, board, frame) {
  const player = save.player;
  const skill = selectPlayerActiveSkill(save);
  const target = pickNearestMonster(board, board.player.x, board.player.y, skill.range);
  if (!target) return;
  let useMp = skill.mpCost ?? 0;
  let style = skill.style ?? "melee";
  let dmgMul = skill.dmgMul ?? 1.0;
  if (player.mp < useMp) {
    useMp = 0;
    style = "melee";
    dmgMul = 1.0;
  }
  if (useMp > 0) {
    player.mp = Math.max(0, player.mp - useMp);
  }
  const damage = Math.max(1, Math.floor(calcDamage(player.atk, target.def) * dmgMul));
  target.hp = Math.max(0, target.hp - damage);
  pushLog(save, "battle", `你使用${style === "melee" ? "近战" : "远程"}技能对 ${target.name} 造成 ${damage} 伤害（${target.hp}/${target.hpMax}）`);
  registerSkillUse(save, skill.id);
  frame.events.push({
    type: "attack",
    attackerId: "player",
    targetId: target.id,
    from: { x: board.player.x, y: board.player.y },
    to: { x: target.x, y: target.y },
    damage,
    targetHp: target.hp,
    targetHpMax: target.hpMax,
    style,
    skillId: skill.id
  });
  if (target.hp > 0) return;
  onMonsterKilled(save, map, board, target);
  frame.events.push({ type: "dead", entityId: target.id, at: { x: target.x, y: target.y } });
}

function tickMonstersAttack(save, map, board, frame) {
  const player = save.player;
  for (const m of board.monsters.slice()) {
    const dist = manhattan(m.x, m.y, board.player.x, board.player.y);
    if (dist > m.range) continue;
    const skill = m.isRanged
      ? (save.config.skills?.monster?.ranged ?? { id: "spit", style: "ranged", dmgMul: 1.0 })
      : (save.config.skills?.monster?.melee ?? { id: "claw", style: "melee", dmgMul: 1.0 });
    const atkMul = Number(map.monsterAtkMul ?? 1.0);
    const damage = Math.max(1, Math.floor(calcDamage(m.atk, player.def) * (skill.dmgMul ?? 1.0) * atkMul));
    player.hp = Math.max(0, player.hp - damage);
    pushLog(save, "battle", `${m.name} 对你造成 ${damage} 伤害（${player.hp}/${player.hpMax}）`);
    frame.events.push({
      type: "attack",
      attackerId: m.id,
      targetId: "player",
      from: { x: m.x, y: m.y },
      to: { x: board.player.x, y: board.player.y },
      damage,
      targetHp: player.hp,
      targetHpMax: player.hpMax,
      style: m.isRanged ? "ranged" : "melee",
      skillId: skill.id
    });
    if (player.hp > 0) continue;
    save.runtime.isRunning = false;
    pushLog(save, "system", "你被击败，挂机停止");
    // 清空当前怪物
    board.monsters = [];
    player.hp = player.hpMax;
    pushLog(save, "system", "已自动复活并恢复满血");
    frame.events.push({ type: "revive", entityId: "player", at: { x: board.player.x, y: board.player.y } });
    // 返回最近主城
    const townId = map.returnTownId ?? map.id;
    const town = save.config.maps.find((m) => m.id === townId && m);
    if (town) {
      save.progress.currentMapId = town.id;
      save.runtime.board = initBoardForMap(save, town);
      save.runtime.lastFrame = null;
      pushLog(save, "system", `已返回主城：${town.name}`);
    }
    return;
  }
}

function onMonsterKilled(save, map, board, monster) {
  board.monsters = board.monsters.filter((m) => m.id !== monster.id);
  const gold = randInt(map.drops.goldMin, map.drops.goldMax);
  save.player.gold += gold;
  gainExp(save, monster.exp);
  pushLog(save, "loot", `获得：经验 +${monster.exp}，金币 +${gold}`);
  trackMapKill(save, map.id);

  if (monster.isElite) {
    const equip = rollEquip(save.config, map.drops.maxRarity);
    save.player.inventory.push(equip);
    pushLog(save, "loot", `精英掉落：${formatEquip(save.config, equip)}（评分 ${equip.score}）`);
    if (save.player.settings.autoEquip) {
      maybeAutoEquip(save, equip);
    }
    maybeAutoRecycle(save, equip);
  } else if (Math.random() < map.drops.equipChance) {
    const equip = rollEquip(save.config, map.drops.maxRarity);
    save.player.inventory.push(equip);
    pushLog(save, "loot", `掉落：${formatEquip(save.config, equip)}（评分 ${equip.score}）`);
    if (save.player.settings.autoEquip) {
      maybeAutoEquip(save, equip);
    }
    maybeAutoRecycle(save, equip);
  }

  const chance = Number(monster.skillBookChance ?? 0);
  if (chance > 0 && Math.random() < chance) {
    const book = rollSkillBook(save, monster.level, save.player.job);
    if (book) {
      save.player.inventory.push(book);
      pushLog(save, "loot", `掉落：技能书《${book.skillName}》`);
    }
  }
}

function pickNearestMonster(board, x, y, maxDist) {
  let best = null;
  let bestDist = Infinity;
  for (const m of board.monsters) {
    const d = manhattan(m.x, m.y, x, y);
    if (d > maxDist) continue;
    if (d < bestDist) {
      bestDist = d;
      best = m;
    }
  }
  return best;
}

function manhattan(ax, ay, bx, by) {
  return Math.abs(ax - bx) + Math.abs(ay - by);
}

function stepToward(x, y, tx, ty) {
  const dx = tx - x;
  const dy = ty - y;
  if (dx === 0 && dy === 0) return null;
  const sx = dx === 0 ? 0 : dx > 0 ? 1 : -1;
  const sy = dy === 0 ? 0 : dy > 0 ? 1 : -1;
  if (Math.abs(dx) >= Math.abs(dy)) {
    return { x: x + sx, y, alt: { x, y: y + sy } };
  }
  return { x, y: y + sy, alt: { x: x + sx, y } };
}

function posKey(x, y) {
  return `${x},${y}`;
}

function gainExp(save, exp) {
  const player = save.player;
  player.exp += exp;
  while (player.exp >= player.expToNext) {
    player.exp -= player.expToNext;
    player.level += 1;
    player.expToNext = Math.floor(player.expToNext * 1.35 + 30);
    recomputeDerivedStats(save);
    pushLog(save, "system", `升级：Lv.${player.level}`);
  }
}

function trackMapKill(save, mapId) {
  save.progress.mapKills[mapId] = (save.progress.mapKills[mapId] ?? 0) + 1;
  const killsToClear = save.config.mapClearRule.killsToClear ?? DEFAULT_CONFIG.mapClearRule.killsToClear;
  if (!save.progress.mapCleared[mapId] && save.progress.mapKills[mapId] >= killsToClear) {
    save.progress.mapCleared[mapId] = true;
    const map = save.config.maps.find((m) => m.id === mapId);
    pushLog(save, "system", `首通完成：${map?.name ?? mapId}（解锁后续地图）`);
  }
}

function maybeAutoEquip(save, equip) {
  const slot = equip.slot;
  const current = save.player.equipped[slot];
  if (!current || equip.score > current.score) {
    equipItem(save, equip.id);
  }
}

function clampPct(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.floor(n)));
}

function maybeAutoRecycle(save, equip) {
  const p = save.player;
  if (!p?.settings?.autoRecycle) return;
  if (!equip || equip.type !== "equip") return;
  if (equip.equipped || equip.locked) return;
  const th = String(p.settings.recycleRarityThreshold ?? "white");
  const thIdx = Math.max(0, RARITY_ORDER.indexOf(th));
  const rIdx = Math.max(0, RARITY_ORDER.indexOf(String(equip.rarity ?? "white")));
  if (rIdx <= thIdx) {
    recycleItems(save, [equip.id]);
  }
}

function maybeAutoDrinkInTown(save, map) {
  const p = save.player;
  if (!p || !map?.isTown) return;
  const s = p.settings ?? {};
  const hpPct = clampPct(s.autoHpPotionPct ?? 0);
  const mpPct = clampPct(s.autoMpPotionPct ?? 0);
  const shop = (save.config.shopByTown?.[map.id] ?? save.config.shopItems ?? []).slice();
  const hpItems = shop.filter((x) => Number(x?.healHp ?? 0) > 0).sort((a, b) => Number(b.healHp) - Number(a.healHp));
  const mpItems = shop.filter((x) => Number(x?.healMp ?? 0) > 0).sort((a, b) => Number(b.healMp) - Number(a.healMp));

  const hpCurPct = p.hpMax > 0 ? (p.hp / p.hpMax) * 100 : 100;
  const mpCurPct = p.mpMax > 0 ? (p.mp / p.mpMax) * 100 : 100;

  if (hpPct > 0 && p.hp < p.hpMax && hpCurPct <= hpPct) {
    for (let i = 0; i < 5; i++) {
      const curPct = p.hpMax > 0 ? (p.hp / p.hpMax) * 100 : 100;
      if (p.hp >= p.hpMax || curPct > hpPct) break;
      const pick = hpItems.find((it) => Number(it.priceGold ?? 0) <= p.gold);
      if (!pick) break;
      buyShopItem(save, pick.id);
    }
  }
  if (mpPct > 0 && p.mp < p.mpMax && mpCurPct <= mpPct) {
    for (let i = 0; i < 5; i++) {
      const curPct = p.mpMax > 0 ? (p.mp / p.mpMax) * 100 : 100;
      if (p.mp >= p.mpMax || curPct > mpPct) break;
      const pick = mpItems.find((it) => Number(it.priceGold ?? 0) <= p.gold);
      if (!pick) break;
      buyShopItem(save, pick.id);
    }
  }
}

function recomputeDerivedStats(save) {
  const player = save.player;
  const jobDef = save.config.jobs[player.job];
  const base = {
    hpMax: jobDef.hpMax + (player.level - 1) * 8,
    atk: (jobDef.atk ?? 0) + (player.level - 1) * 2,
    magic: (jobDef.magic ?? 0) + (player.level - 1) * 2,
    tao: (jobDef.tao ?? 0) + (player.level - 1) * 2,
    def: jobDef.def + (player.level - 1) * 1
  };

  let extraHpMax = 0;
  let extraAtk = 0;
  let extraMagic = 0;
  let extraTao = 0;
  let extraDef = 0;

  for (const slot of save.config.equipSlots) {
    const eq = player.equipped[slot];
    if (!eq) continue;
    extraHpMax += eq.stats.hpMax ?? 0;
    extraAtk += eq.stats.atk ?? 0;
    extraMagic += eq.stats.magic ?? 0;
    extraTao += eq.stats.tao ?? 0;
    extraDef += eq.stats.def ?? 0;
    const gain = save.config.strengthen.gainBySlot[slot];
    if (gain && eq.strengthenLevel > 0) {
      extraHpMax += (gain.hpMax ?? 0) * eq.strengthenLevel;
      extraAtk += (gain.atk ?? 0) * eq.strengthenLevel;
      extraDef += (gain.def ?? 0) * eq.strengthenLevel;
    }
  }

  const prevHpMax = player.hpMax;
  player.hpMax = base.hpMax + extraHpMax;
  // 将核心攻击力映射为职业主属性（战士: 攻击；法师: 魔法；道士: 道术）
  const mainKey = player.job === "mage" ? "magic" : player.job === "taoist" ? "tao" : "atk";
  const baseMain = base[mainKey] ?? 0;
  const extraMain =
    mainKey === "magic" ? extraMagic : mainKey === "tao" ? extraTao : extraAtk;
  player.atk = baseMain + extraMain + getPassiveBonus(save, "atk");
  player.def = base.def + extraDef;
  if (player.hp > player.hpMax || player.hp === prevHpMax) player.hp = player.hpMax;
  const targetMpMax = save.config.jobMpMax?.[player.job] ?? 50;
  player.mpMax = targetMpMax;
  if (player.mp > player.mpMax) player.mp = player.mpMax;
}

function rollEquip(config, maxRarity) {
  const slot = config.equipSlots[randInt(0, config.equipSlots.length - 1)];
  const maxIndex = RARITY_ORDER.indexOf(maxRarity);
  const weights = {};
  for (const [rarity, w] of Object.entries(config.rarityWeights)) {
    const idx = RARITY_ORDER.indexOf(rarity);
    if (idx >= 0 && idx <= maxIndex) weights[rarity] = w;
  }
  const rarity = pickWeighted(Object.entries(weights).map(([id, weight]) => ({ id, weight })));
  const base = config.equipBaseBySlot[slot];
  const mul = config.equipRarityMultiplier[rarity] ?? 1.0;
  const stats = {
    atk: Math.floor((base.atk ?? 0) * mul),
    magic: Math.floor((base.magic ?? 0) * mul),
    tao: Math.floor((base.tao ?? 0) * mul),
    def: Math.floor((base.def ?? 0) * mul),
    hpMax: Math.floor((base.hpMax ?? 0) * mul)
  };
  const score = calcPowerScore(stats.atk, stats.def, stats.hpMax);
  return {
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity,
    name: generateEquipName(config, slot, rarity),
    stats,
    score,
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  };
}

function generateEquipName(config, slot, rarity) {
  const slotName = config.equipSlotNames[slot] ?? slot;
  const rarityName = config.rarityName[rarity] ?? rarity;
  const seeds = {
    weapon: ["木剑", "短剑", "铁剑", "青铜剑", "战刃"],
    armor: ["布衣", "皮甲", "锁子甲", "战甲", "重甲"],
    shoes: ["草鞋", "布鞋", "皮靴", "铁靴", "战靴"],
    head: ["头盔", "面甲", "法冠", "战盔", "头饰"],
    ring: ["戒", "指环", "戒指"],
    bracelet: ["护腕", "臂环", "镯"],
    necklace: ["项链", "挂坠", "颈饰"],
    medal: ["勋章", "徽章", "令牌"]
  };
  const list = seeds[slot] ?? [slotName];
  const base = list[randInt(0, list.length - 1)];
  return `${rarityName}${base}`;
}
function createStarterEquip(config, job) {
  const mkEquip = (slot, name, stats) => ({
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity: "white",
    name,
    stats,
    score: calcPowerScore(stats.atk ?? 0, stats.def ?? 0, stats.hpMax ?? 0),
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  });
  if (job === "mage") {
    return {
      weapon: mkEquip("weapon", "新手法杖", { atk: 0, magic: 8, tao: 0, def: 0, hpMax: 0 }),
      armor: mkEquip("armor", "新手法袍", { atk: 0, magic: 2, tao: 0, def: 3, hpMax: 10 }),
      shoes: mkEquip("shoes", "新手履", { atk: 0, magic: 1, tao: 0, def: 2, hpMax: 6 }),
      head: mkEquip("head", "新手法冠", { atk: 0, magic: 1, tao: 0, def: 2, hpMax: 8 }),
      ring: mkEquip("ring", "新手戒", { atk: 0, magic: 2, tao: 0, def: 0, hpMax: 0 }),
      bracelet: mkEquip("bracelet", "新手护腕", { atk: 0, magic: 1, tao: 0, def: 1, hpMax: 4 }),
      necklace: mkEquip("necklace", "新手项链", { atk: 0, magic: 2, tao: 0, def: 0, hpMax: 0 }),
      medal: mkEquip("medal", "新手勋章", { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 18 })
    };
  }
  if (job === "taoist") {
    return {
      weapon: mkEquip("weapon", "新手法符", { atk: 0, magic: 0, tao: 8, def: 0, hpMax: 0 }),
      armor: mkEquip("armor", "新手道袍", { atk: 0, magic: 0, tao: 2, def: 3, hpMax: 10 }),
      shoes: mkEquip("shoes", "新手履", { atk: 0, magic: 0, tao: 1, def: 2, hpMax: 6 }),
      head: mkEquip("head", "新手道冠", { atk: 0, magic: 0, tao: 1, def: 2, hpMax: 8 }),
      ring: mkEquip("ring", "新手戒", { atk: 0, magic: 0, tao: 2, def: 0, hpMax: 0 }),
      bracelet: mkEquip("bracelet", "新手护腕", { atk: 0, magic: 0, tao: 1, def: 1, hpMax: 4 }),
      necklace: mkEquip("necklace", "新手项链", { atk: 0, magic: 0, tao: 2, def: 0, hpMax: 0 }),
      medal: mkEquip("medal", "新手勋章", { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 18 })
    };
  }
  return {
    weapon: mkEquip("weapon", "新手剑", { atk: 8, magic: 0, tao: 0, def: 0, hpMax: 0 }),
    armor: mkEquip("armor", "新手甲", { atk: 2, magic: 0, tao: 0, def: 3, hpMax: 10 }),
    shoes: mkEquip("shoes", "新手靴", { atk: 1, magic: 0, tao: 0, def: 2, hpMax: 6 }),
    head: mkEquip("head", "新手头盔", { atk: 0, magic: 0, tao: 0, def: 3, hpMax: 10 }),
    ring: mkEquip("ring", "新手戒", { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 }),
    bracelet: mkEquip("bracelet", "新手护腕", { atk: 1, magic: 0, tao: 0, def: 1, hpMax: 4 }),
    necklace: mkEquip("necklace", "新手项链", { atk: 2, magic: 0, tao: 0, def: 0, hpMax: 0 }),
    medal: mkEquip("medal", "新手勋章", { atk: 0, magic: 0, tao: 0, def: 2, hpMax: 20 })
  };
}

function getRecycleValue(config, equip) {
  const rarityFactor = { white: 1, green: 2, blue: 5, purple: 12, orange: 25 }[equip.rarity] ?? 1;
  const strengthenFactor = 1 + (equip.strengthenLevel ?? 0) * 0.2;
  const base = 10;
  return Math.floor(base * rarityFactor * strengthenFactor);
}

function getStrengthenCost(config, nextLevel) {
  const base = config.strengthen.baseGoldCost ?? DEFAULT_CONFIG.strengthen.baseGoldCost;
  const growth = config.strengthen.goldCostGrowth ?? DEFAULT_CONFIG.strengthen.goldCostGrowth;
  return Math.floor(base * Math.pow(growth, nextLevel - 1));
}

function calcPowerScore(atk, def, hpMax) {
  return Math.floor(atk * 6 + def * 4 + hpMax * 0.6);
}

function getPassiveBonus(save, key) {
  const p = save.player;
  const ids = p.skills?.passiveIds ?? [];
  let sum = 0;
  for (const id of ids) {
    const s = (save.config.skills?.[p.job] ?? []).find((x) => x.id === id);
    if (!s || s.type !== "passive") continue;
    if (p.level < (s.learnLevel ?? 1)) continue;
    const bonus = s.bonus ?? {};
    const lv = Math.max(1, Math.min(3, Number(p.skills?.levels?.[id]?.level ?? 1)));
    sum += Number(bonus[key] ?? 0) * lv;
  }
  return sum;
}

function registerSkillUse(save, skillId) {
  const p = save.player;
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  const learned = new Set([...(p.skills.activeIds ?? []), ...(p.skills.passiveIds ?? [])]);
  if (!learned.has(skillId)) return;
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === skillId);
  if (!def) return;
  const info = p.skills.levels[skillId] ?? { level: 1, exp: 0 };
  const curLv = Math.max(1, Math.min(3, Number(info.level ?? 1)));
  if (curLv >= 3) return;
  info.exp = (info.exp ?? 0) + 1;
  const need = Number(def.trainNeed?.[curLv] ?? 999999);
  if (info.exp >= need) {
    info.level = curLv + 1;
    info.exp = 0;
    pushLog(save, "system", `技能升级：${def.name} Lv.${info.level}`);
  } else {
    info.level = curLv;
  }
  p.skills.levels[skillId] = info;
}

function getSkillName(save, skillId) {
  const p = save.player;
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === skillId);
  return def?.name ?? skillId;
}

function rollSkillBook(save, monsterLevel, job) {
  const cap = Math.max(1, Number(monsterLevel) - 5);
  const list = (save.config.skills?.[job] ?? []).filter((s) => (s.learnLevel ?? 1) <= cap);
  if (list.length <= 0) return null;
  const skill = list[randInt(0, list.length - 1)];
  return {
    id: crypto.randomUUID(),
    type: "skill_book",
    skillId: skill.id,
    skillName: skill.name,
    learnLevel: skill.learnLevel ?? 1,
    skillType: skill.type,
    createdAt: Date.now()
  };
}

export function useSkillBook(save, itemId) {
  if (!save.player) throw new Error("未创建角色");
  const idx = save.player.inventory.findIndex((it) => it.id === itemId);
  if (idx < 0) throw new Error("物品不存在");
  const it = save.player.inventory[idx];
  if (it.type !== "skill_book") throw new Error("不是技能书");
  const p = save.player;
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  const def = (save.config.skills?.[p.job] ?? []).find((s) => s.id === it.skillId);
  if (!def) throw new Error("技能不存在");
  if (p.level < (def.learnLevel ?? 1)) throw new Error("等级不足，无法学习");
  const learned = new Set([...(p.skills.activeIds ?? []), ...(p.skills.passiveIds ?? [])]);
  if (learned.has(it.skillId)) throw new Error("已学会该技能");
  if (def.type === "passive") {
    p.skills.passiveIds.push(it.skillId);
  } else {
    p.skills.activeIds.unshift(it.skillId);
    if (!p.skills.activeId) p.skills.activeId = it.skillId;
  }
  p.skills.levels[it.skillId] = { level: 1, exp: 0 };
  save.player.inventory.splice(idx, 1);
  pushLog(save, "system", `学习技能：《${it.skillName}》`);
}

export function setActiveSkill(save, skillId) {
  if (!save.player) throw new Error("未创建角色");
  const p = save.player;
  if (!p.skills) p.skills = { activeId: null, activeIds: [], passiveIds: [], levels: {} };
  if (!p.skills.activeIds.includes(skillId)) throw new Error("未学习该主动技能");
  p.skills.activeId = skillId;
  pushLog(save, "system", `切换技能：${getSkillName(save, skillId)}`);
}

export function buyShopItem(save, itemId) {
  if (!save.player) throw new Error("未创建角色");
  const curMap = save.config.maps.find((m) => m.id === save.progress.currentMapId);
  if (!curMap?.isTown) throw new Error("当前地图无法购买（请前往主城）");
  const it =
    (save.config.shopByTown?.[curMap.id] ?? save.config.shopItems ?? []).find((x) => x.id === itemId);
  if (!it) throw new Error("商品不存在");
  const p = save.player;
  const price = Number(it.priceGold ?? 0);
  if (p.gold < price) throw new Error("金币不足");
  p.gold -= price;
  if (it.healHp) p.hp = Math.min(p.hpMax, p.hp + Number(it.healHp));
  if (it.healMp) p.mp = Math.min(p.mpMax, p.mp + Number(it.healMp));
  if (it.grantEquipSlot) {
    const rarity = String(it.grantRarity ?? "white");
    const eq = createShopEquip(save.config, String(it.grantEquipSlot), rarity);
    p.inventory.push(eq);
    pushLog(save, "system", `购买并获得：${formatEquip(save.config, eq)}`);
  } else {
    pushLog(save, "system", `购买并使用：${it.name}`);
  }
}

function calcDamage(atk, def) {
  const base = Math.max(1, atk - def);
  const roll = 0.9 + Math.random() * 0.2;
  return Math.max(1, Math.floor(base * roll));
}

function randInt(min, max) {
  const a = Math.ceil(min);
  const b = Math.floor(max);
  return Math.floor(a + Math.random() * (b - a + 1));
}

function pickWeighted(entries) {
  if (!Array.isArray(entries) || entries.length <= 0) return null;
  const sum = entries.reduce((acc, e) => acc + (e.weight ?? 0), 0);
  if (sum <= 0) return entries[0].id;
  let r = Math.random() * sum;
  for (const e of entries) {
    r -= e.weight ?? 0;
    if (r <= 0) return e.id;
  }
  return entries[entries.length - 1].id;
}

function formatEquip(config, equip) {
  const rarityName = config.rarityName[equip.rarity] ?? equip.rarity;
  const slotName = config.equipSlotNames[equip.slot] ?? equip.slot;
  const { atk = 0, magic = 0, tao = 0, def = 0, hpMax = 0 } = equip.stats ?? {};
  const strengthen = equip.strengthenLevel ? `+${equip.strengthenLevel}` : "";
  return `${equip.name}${strengthen}【${rarityName}·${slotName}】(攻${atk} 术${tao} 魔${magic} 防${def} 血${hpMax})`;
}

function createShopEquip(config, slot, rarity) {
  const base = config.equipBaseBySlot[slot];
  const mul = config.equipRarityMultiplier[rarity] ?? 1.0;
  const stats = {
    atk: Math.floor((base.atk ?? 0) * mul),
    magic: Math.floor((base.magic ?? 0) * mul),
    tao: Math.floor((base.tao ?? 0) * mul),
    def: Math.floor((base.def ?? 0) * mul),
    hpMax: Math.floor((base.hpMax ?? 0) * mul)
  };
  const score = calcPowerScore(stats.atk, stats.def, stats.hpMax);
  return {
    id: crypto.randomUUID(),
    type: "equip",
    slot,
    rarity,
    name: generateEquipName(config, slot, rarity),
    stats,
    score,
    strengthenLevel: 0,
    locked: false,
    equipped: false,
    createdAt: Date.now()
  };
}

function pushLog(save, type, text) {
  save.logs.push({
    id: crypto.randomUUID(),
    ts: Date.now(),
    type,
    text
  });
  const max = save.config.logMax ?? DEFAULT_CONFIG.logMax;
  if (save.logs.length > max) {
    save.logs.splice(0, save.logs.length - max);
  }
}
