import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

import {
  canEnterMap,
  createNewSave,
  createPlayer,
  buyShopItem,
  setActiveSkill,
  useSkillBook,
  equipItem,
  unequipItem,
  migrateSave,
  recycleItems,
  runTicks,
  settleOffline,
  setAutoEquip,
  setAutoRecycle,
  setAutoDrink,
  setRecycleRarityThreshold,
  setCurrentMap,
  setRunning,
  strengthenEquipped
} from "./gameEngine.js";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(process.cwd(), "data");
const SAVE_PATH = path.join(DATA_DIR, "save.json");

let save = createNewSave();

async function ensureDataDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

async function loadSave() {
  try {
    await ensureDataDir();
    const raw = await fs.readFile(SAVE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return;
    save = parsed;
    migrateSave(save);
    if (!save.runtime) save.runtime = { isRunning: false, lastTickAt: Date.now() };
    if (!save.runtime.sessions) save.runtime.sessions = {};
    if (!("lastBattle" in save.runtime)) save.runtime.lastBattle = null;
    if (!("board" in save.runtime)) save.runtime.board = null;
    if (!("lastFrame" in save.runtime)) save.runtime.lastFrame = null;
    if (!save.accounts) save.accounts = {};
    if (!save.logs) save.logs = [];
  } catch (err) {
    if (err?.code !== "ENOENT") {
      console.error("[save] load failed:", err);
    }
  }
}

let saveWritePromise = Promise.resolve();
function queueSaveWrite() {
  saveWritePromise = saveWritePromise
    .then(async () => {
      await ensureDataDir();
      await fs.writeFile(SAVE_PATH, JSON.stringify(save, null, 2), "utf8");
    })
    .catch((err) => console.error("[save] write failed:", err));
  return saveWritePromise;
}

function authUser(req) {
  const token = req.headers["x-auth"];
  if (!token || typeof token !== "string") return null;
  const username = save.runtime.sessions?.[token];
  if (!username) return null;
  return String(username);
}

function requireAuth(req, res, next) {
  const u = authUser(req);
  if (!u) return res.status(401).json({ ok: false, error: "未登录" });
  req.username = u;
  const acc = save.accounts?.[u];
  if (acc) {
    save.player = acc.player ?? null;
  }
  res.on("finish", () => {
    const a = save.accounts?.[u];
    if (a && !req.skipSyncPlayer) a.player = save.player ?? null;
  });
  next();
}

function hashPassword(pw) {
  return crypto.createHash("sha256").update(String(pw)).digest("hex");
}

app.post("/api/auth/register", async (req, res) => {
  try {
    const { username, password } = req.body ?? {};
    const u = String(username || "").trim().slice(0, 20);
    const p = String(password || "").trim();
    if (!u || !p) return res.status(400).json({ ok: false, error: "账号或密码为空" });
    if (save.accounts?.[u]) return res.status(400).json({ ok: false, error: "账号已存在" });
    save.accounts[u] = { passwordHash: hashPassword(p), player: null };
    const token = Math.random().toString(36).slice(2) + Date.now();
    save.runtime.sessions[token] = u;
    await queueSaveWrite();
    return res.json({ ok: true, data: { token } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body ?? {};
    const u = String(username || "").trim().slice(0, 20);
    const p = String(password || "").trim();
    const acc = save.accounts?.[u];
    if (!acc) return res.status(400).json({ ok: false, error: "账号不存在" });
    if (acc.passwordHash !== hashPassword(p)) return res.status(400).json({ ok: false, error: "密码错误" });
    const token = Math.random().toString(36).slice(2) + Date.now();
    save.runtime.sessions[token] = u;
    if (acc.player) {
      save.player = acc.player;
    } else {
      save.player = null;
    }
    await queueSaveWrite();
    return res.json({ ok: true, data: { token } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/auth/logout", requireAuth, async (req, res) => {
  try {
    const token = req.headers["x-auth"];
    delete save.runtime.sessions[token];
    await queueSaveWrite();
    return res.json({ ok: true, data: {} });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

function publicState() {
  const player = save.player;
  const map = save.config.maps.find((m) => m.id === save.progress.currentMapId) ?? save.config.maps[0];
  const runtime = save.runtime
    ? {
        isRunning: !!save.runtime.isRunning,
        lastTickAt: save.runtime.lastTickAt,
        lastBattle: save.runtime.lastBattle ?? null,
        board: save.runtime.board ?? null,
        lastFrame: save.runtime.lastFrame ?? null
      }
    : null;
  const unlockedMaps = save.config.maps.map((m) => {
    const gate = canEnterMap(save, m.id);
    return {
      id: m.id,
      name: m.name,
      recommendPower: m.recommendPower,
      unlocked: gate.ok,
      lockedReason: gate.ok ? null : gate.reason
    };
  });
  return {
    player,
    progress: save.progress,
    runtime,
    currentMap: map ? { id: map.id, name: map.name, recommendPower: map.recommendPower, themeColor: map.themeColor ?? null } : null,
    unlockedMaps,
    shopItems: map?.isTown ? ((save.config.shopByTown?.[map.id] ?? save.config.shopItems) ?? []) : [],
    skillDefs: player ? (save.config.skills?.[player.job] ?? []) : [],
    equipSlots: save.config.equipSlots ?? [],
    equipSlotNames: save.config.equipSlotNames ?? {},
    logs: save.logs
  };
}

function requirePlayer(req, res, next) {
  if (!save.player) return res.status(400).json({ ok: false, error: "未创建角色" });
  next();
}

app.get("/api/state", requireAuth, async (req, res) => {
  try {
    if (save.runtime?.isRunning) {
      settleOffline(save);
      await queueSaveWrite();
    } else if (save.runtime) {
      save.runtime.lastTickAt = Date.now();
    }
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/create", requireAuth, async (req, res) => {
  try {
    const { name, job } = req.body ?? {};
    createPlayer(save, { name, job });
    const u = req.username;
    if (!save.accounts[u]) save.accounts[u] = { passwordHash: "", player: null };
    save.accounts[u].player = save.player;
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/player/reset", requireAuth, async (req, res) => {
  try {
    req.skipSyncPlayer = true;
    save.player = null;
    save.runtime.board = null;
    save.runtime.lastFrame = null;
    save.runtime.isRunning = false;
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/start", requireAuth, requirePlayer, async (req, res) => {
  try {
    setRunning(save, true);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/stop", requireAuth, requirePlayer, async (req, res) => {
  try {
    setRunning(save, false);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/game/tick", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { count } = req.body ?? {};
    const result = runTicks(save, count ?? 1);
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState() } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/map/set", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { mapId } = req.body ?? {};
    setCurrentMap(save, String(mapId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-equip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { enabled } = req.body ?? {};
    setAutoEquip(save, !!enabled);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-recycle", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { enabled } = req.body ?? {};
    setAutoRecycle(save, !!enabled);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/recycle-threshold", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { threshold } = req.body ?? {};
    setRecycleRarityThreshold(save, String(threshold));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/settings/auto-drink", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { hpPct, mpPct } = req.body ?? {};
    setAutoDrink(save, hpPct, mpPct);
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/equip/equip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    equipItem(save, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/equip/unequip", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    unequipItem(save, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/inventory/recycle", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemIds } = req.body ?? {};
    const result = recycleItems(save, itemIds);
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState() } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/skills/use-book", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    useSkillBook(save, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/skills/set-active", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { skillId } = req.body ?? {};
    setActiveSkill(save, String(skillId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/shop/buy", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { itemId } = req.body ?? {};
    buyShopItem(save, String(itemId));
    await queueSaveWrite();
    return res.json({ ok: true, data: publicState() });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.post("/api/forge/strengthen", requireAuth, requirePlayer, async (req, res) => {
  try {
    const { slot } = req.body ?? {};
    const result = strengthenEquipped(save, String(slot));
    await queueSaveWrite();
    return res.json({ ok: true, data: { ...result, state: publicState() } });
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err?.message ?? err) });
  }
});

app.use(express.static(path.join(process.cwd(), "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

await loadSave();

app.listen(PORT, () => {
  console.log(`[server] listening on http://localhost:${PORT}`);
});
