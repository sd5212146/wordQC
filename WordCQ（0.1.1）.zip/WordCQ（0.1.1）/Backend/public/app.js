const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const APP_VERSION = "0.1.1";
window.APP_VERSION = APP_VERSION;
$("#app-version") && ($("#app-version").textContent = `Ver ${APP_VERSION}`);

let state = null;
let currentTab = "map";
let logFilter = "all";
let ticking = false;
let displayLogClearedAt = 0;
let lastFrameId = null;
let lastBattleMapId = null;
let lastNotifiedLogId = null;
let didInitNotifyCursor = false;
let CELL = 128;
let hintMessages = [];

function ensureToastEl() {
  let el = document.querySelector("#toast");
  if (el) return el;
  el = document.createElement("div");
  el.id = "toast";
  el.className = "toast";
  document.body.appendChild(el);
  return el;
}

function showToast(msg) {
  hintMessages.push(String(msg));
  if (hintMessages.length > 50) hintMessages = hintMessages.slice(-50);
  renderRightLogs();
}

function maybeNotifyDrops() {
  const logs = state?.logs ?? [];
  if (logs.length <= 0) return;
  if (!didInitNotifyCursor) {
    lastNotifiedLogId = logs[logs.length - 1]?.id ?? null;
    didInitNotifyCursor = true;
    return;
  }
  let startIdx = -1;
  if (lastNotifiedLogId) {
    startIdx = logs.findIndex((l) => l.id === lastNotifiedLogId);
  }
  const slice = startIdx >= 0 ? logs.slice(startIdx + 1) : logs;
  for (const l of slice) {
    if (l.type !== "loot") continue;
    const text = String(l.text ?? "");
    if (text.includes("掉落")) {
      showToast(text);
    }
  }
  lastNotifiedLogId = logs[logs.length - 1]?.id ?? lastNotifiedLogId;
}

function fmtTime(ts) {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

async function api(path, { method = "GET", body } = {}) {
  const token = localStorage.getItem("authToken") || sessionStorage.getItem("authToken");
  const res = await fetch(path, {
    method,
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { "X-Auth": token } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.ok) {
    const err = data?.error || `请求失败：${res.status}`;
    throw new Error(err);
  }
  return data.data;
}

function showCreateModal(show) {
  $("#modal-create").classList.toggle("hidden", !show);
  $("#create-hint").textContent = "";
}

function showAuthModal(show) {
  $("#modal-auth").classList.toggle("hidden", !show);
  $("#auth-hint").textContent = "";
}

function setActiveTab(tab) {
  currentTab = tab;
  $$(".nav-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $("#view-map").classList.toggle("hidden", tab !== "map");
  $("#view-bag").classList.toggle("hidden", tab !== "bag");
  $("#view-forge").classList.toggle("hidden", tab !== "forge");
  $("#view-shop").classList.toggle("hidden", tab !== "shop");
  $("#view-attr")?.classList.toggle("hidden", tab !== "attr");
  $("#view-skills")?.classList.toggle("hidden", tab !== "skills");
}

function setActiveLogFilter(filter) {
  logFilter = filter === "loot" ? "loot" : "all";
  $$(".chip").forEach((b) => b.classList.toggle("active", b.dataset.log === filter));
  renderRightLogs();
}

function jobName(job) {
  return { warrior: "战士", mage: "法师", taoist: "道士" }[job] ?? job;
}

function jobAttackLabel(job) {
  return { warrior: "攻击", mage: "魔法", taoist: "道术" }[job] ?? "攻击";
}

function jobIcon(job) {
  return { warrior: "🗡️", mage: "🪄", taoist: "📿" }[job] ?? "🧑";
}

function monsterIcon(monsterId) {
  return (
    {
      chicken: "🐔",
      deer: "🦌",
      scarecrow: "🌾",
      rake_cat: "🐱",
      half_orc: "👺",
      multi_hook_cat: "🐾",
      forest_snowman: "⛄",
      wooma_soldier: "🗿",
      wooma_fighter: "🗿",
      red_snake: "🐍",
      tiger_snake: "🐍",
      wolf: "🐺",
      sand_worm: "🪱",
      shell_nipper: "🪲",
      zombie: "🧟",
      zombie_king: "🧟",
      red_boar: "🐗",
      black_boar: "🐗",
      moth: "🦋",
      centipede: "🐛",
      bee: "🐝",
      tongs: "🦂",
      evil_tongs: "🦂",
      zuma_statue: "🗿",
      zuma_guardian: "🗿",
      zuma_archer: "🏹",
      hongmo_boar_guard: "🐗",
      hongmo_scorpion_guard: "🦂",
      moon_spider: "🕷️",
      kiss_spider: "🕷️",
      fang_spider: "🕷️",
      bone_demon: "💀",
      minotaur_warrior: "🐮",
      minotaur_mage: "🐮"
    }[monsterId] ?? "👾"
  );
}

function calcPowerScore(atk, def, hpMax) {
  return Math.floor(atk * 6 + def * 4 + hpMax * 0.6);
}

function render() {
  if (!state) return;
  document.querySelector("#toast")?.remove();
  const player = state.player;
  if (!player) {
    showCreateModal(true);
    return;
  }
  showCreateModal(false);
  renderHintsCard();
  renderAttrView();
  renderSkillsView();
  renderMapView();
  renderBagView();
  renderForgeView();
  renderShopView();
  renderBattleView();
  renderRightLogs();
  maybeNotifyDrops();
  $("#setting-auto-equip") && ($("#setting-auto-equip").checked = !!player.settings?.autoEquip);
  $("#setting-auto-recycle") && ($("#setting-auto-recycle").checked = !!player.settings?.autoRecycle);
  $("#setting-recycle-threshold") &&
    ($("#setting-recycle-threshold").value = String(player.settings?.recycleRarityThreshold ?? "white"));
  $("#setting-auto-hp") && ($("#setting-auto-hp").value = String(player.settings?.autoHpPotionPct ?? 35));
  $("#setting-auto-mp") && ($("#setting-auto-mp").value = String(player.settings?.autoMpPotionPct ?? 35));
  renderLeftStatus();
  renderStartStopUI();
}

function renderHintsCard() {
  const el = $("#card-hints");
  if (!el) return;
  const latest = hintMessages.slice(-8).reverse();
  const html = `
    <div class="card-title">提示</div>
    <div class="list">
      ${
        latest.length
          ? latest
              .map((t) => {
                return `<div class="list-item" style="color: var(--danger); font-weight: 800;">${escapeHtml(t)}</div>`;
              })
              .join("")
          : `<div class="muted">暂无提示</div>`
      }
    </div>
  `;
  el.innerHTML = html;
}
function renderPlayerCard() {
  const player = state.player;
  const map = state.currentMap;
  const expPct = player.expToNext > 0 ? Math.floor((player.exp / player.expToNext) * 100) : 0;
  const html = `
    <div class="card-title">角色</div>
    <div class="kv">
      <div class="k">名字</div><div class="v">${escapeHtml(player.name)}</div>
      <div class="k">职业</div><div class="v">${escapeHtml(jobName(player.job))}</div>
      <div class="k">等级</div><div class="v">Lv.${player.level}</div>
      <div class="k">经验</div><div class="v">${player.exp}/${player.expToNext}（${expPct}%）</div>
      <div class="k">生命</div><div class="v">${player.hp}/${player.hpMax}</div>
      <div class="k">魔法</div><div class="v">${player.mp}/${player.mpMax}</div>
      <div class="k">${jobAttackLabel(player.job)}</div><div class="v">${player.atk}</div>
      <div class="k">防御</div><div class="v">${player.def}</div>
      <div class="k">金币</div><div class="v">${player.gold}</div>
      <div class="k">地图</div><div class="v">${escapeHtml(map?.name ?? "-")}</div>
      <div class="k">挂机</div><div class="v">${state.runtime?.isRunning ? "进行中" : "停止"}</div>
    </div>
    <div class="muted" style="margin-top:8px;">地图推荐战力：${map?.recommendPower ?? "-"}</div>
  `;
  $("#card-player").innerHTML = html;
}

function renderEquipCard() {
  const p = state.player;
  const eq = p.equipped ?? {};
  const slots = (state.equipSlots ?? []).map((id) => ({ id, name: slotName(id) }));
  const html = `
    <div class="card-title">已穿戴</div>
    <div class="list">
      ${slots
        .map((s) => {
          const item = eq[s.id];
          if (!item) {
            return `<div class="list-item"><div class="list-item-title">${s.name}</div><div class="list-item-sub">未穿戴</div></div>`;
          }
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(item.name)}${item.strengthenLevel ? ` +${item.strengthenLevel}` : ""}</div>
              <div class="list-item-sub">攻${item.stats?.atk ?? 0} 术${item.stats?.tao ?? 0} 魔${item.stats?.magic ?? 0} 防${item.stats?.def ?? 0} 血${item.stats?.hpMax ?? 0} · 评分 ${item.score}</div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#card-equip").innerHTML = html;
}

function renderSkillsCard() {
  const el = $("#card-skills");
  if (!el) return;
  const p = state.player;
  const defs = state.skillDefs ?? [];
  const levels = p.skills?.levels ?? {};
  const activeId = p.skills?.activeId ?? null;

  const findDef = (id) => defs.find((d) => d.id === id);
  const fmtLv = (id) => {
    const info = levels[id];
    if (!info) return "Lv.1";
    return `Lv.${info.level ?? 1}（熟练 ${info.exp ?? 0}）`;
  };

  const activeList = Array.from(new Set(p.skills?.activeIds ?? []));
  const passiveList = Array.from(new Set(p.skills?.passiveIds ?? []));
  const books = (p.inventory ?? []).filter((it) => it.type === "skill_book");

  const html = `
    <div class="card-title">技能</div>
    <div class="muted">当前主动：${escapeHtml(findDef(activeId)?.name ?? "普攻")}</div>
    <div class="list" style="margin-top:10px;">
      ${activeList.length
        ? activeList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              const isCur = id === activeId;
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}${isCur ? "（已选）" : ""}</div>
                  <div class="list-item-sub">${escapeHtml(d.style === "ranged" ? "远程" : "近战")} · MP ${d.mpCost ?? 0} · 距离 ${d.range ?? 1} · 学习等级 ${d.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-secondary" data-action="skill-set" data-skill-id="${escapeAttr(id)}" ${isCur ? "disabled" : ""}>设为主动</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习主动技能（当前使用普攻）</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">被动技能（自动生效，不消耗MP）</div>
    <div class="list" style="margin-top:8px;">
      ${passiveList.length
        ? passiveList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}</div>
                  <div class="list-item-sub">学习等级 ${d.learnLevel ?? 1}</div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习被动技能</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">技能书</div>
    <div class="list" style="margin-top:8px;">
      ${books.length
        ? books
            .map((b) => {
              return `
                <div class="list-item">
                  <div class="list-item-title">《${escapeHtml(b.skillName)}》</div>
                  <div class="list-item-sub">需求等级 ${b.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-primary" data-action="book-use" data-item-id="${escapeAttr(b.id)}">学习</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">暂无技能书</div>`}
    </div>
  `;
  el.innerHTML = html;

  $$("#card-skills [data-action='skill-set']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionSetActiveSkill(btn.dataset.skillId);
    });
  });
  $$("#card-skills [data-action='book-use']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionUseSkillBook(btn.dataset.itemId);
    });
  });
}

function renderMapView() {
  const cur = state.currentMap?.id;
  const list = state.unlockedMaps ?? [];
  const html = `
    <div class="card-title">地图列表</div>
    <div class="list">
      ${list
        .map((m) => {
          const locked = !m.unlocked;
          const isCur = m.id === cur;
          return `
            <div class="list-item" data-map-id="${escapeAttr(m.id)}" data-locked="${locked ? "1" : "0"}">
              <div class="list-item-title">${escapeHtml(m.name)}${isCur ? "（当前）" : ""}</div>
              <div class="list-item-sub">推荐战力 ${m.recommendPower}${locked ? ` · <span class="locked-reason">${escapeHtml(m.lockedReason ?? "未解锁")}</span>` : ""}</div>
              <div class="list-item-actions">
                <button class="btn-secondary" data-action="map-go" data-map-id="${escapeAttr(m.id)}" ${isCur ? "disabled" : ""}>前往</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#view-map").innerHTML = html;
  $$("#view-map [data-action='map-go']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const mapId = btn.dataset.mapId;
      const item = btn.closest(".list-item");
      const locked = item?.dataset.locked === "1";
      if (locked) {
        const reasonEl = item.querySelector(".locked-reason");
        if (reasonEl) {
          reasonEl.classList.add("flash");
          setTimeout(() => reasonEl.classList.remove("flash"), 800);
        }
        return;
      }
      try {
        await actionSetMap(mapId);
        triggerBattleRefresh();
      } catch {}
    });
  });
}

function renderBagView() {
  const inv = state.player.inventory ?? [];
  const equips = inv.filter((it) => it.type === "equip");
  const books = inv.filter((it) => it.type === "skill_book");
  const html = `
    <div class="card-title">背包（装备 ${equips.length} · 技能书 ${books.length}）</div>
    <div class="row">
      <button class="btn-secondary" id="btn-recycle-selected">回收选中</button>
    </div>
    ${books.length ? `<div class="muted" style="margin-top:10px;">技能书</div>` : ""}
    <div class="list" style="margin-top:10px;">
      ${books
        .map((b) => {
          return `
            <div class="list-item">
              <div class="list-item-title">《${escapeHtml(b.skillName)}》</div>
              <div class="list-item-sub">需求等级 ${b.learnLevel ?? 1}</div>
              <div class="list-item-actions">
                <button class="btn-primary" data-action="book-use" data-item-id="${escapeAttr(b.id)}">学习</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>
    ${equips.length ? `<div class="muted" style="margin-top:10px;">装备</div>` : ""}
    <div class="list" style="margin-top:10px;">
      ${equips
        .slice()
        .sort((a, b) => (b.score ?? 0) - (a.score ?? 0))
        .map((it) => {
          const equipped = !!it.equipped;
          return `
            <div class="list-item">
              <div class="list-item-title">
                <label style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" data-recycle-id="${escapeAttr(it.id)}" ${equipped ? "disabled" : ""} />
                  <span>${escapeHtml(it.name)}${it.strengthenLevel ? ` +${it.strengthenLevel}` : ""}${equipped ? "（已穿戴）" : ""}</span>
                </label>
              </div>
              <div class="list-item-sub">${escapeHtml(slotName(it.slot))} · 攻${it.stats?.atk ?? 0} 防${it.stats?.def ?? 0} 血${it.stats?.hpMax ?? 0} · 评分 ${it.score}</div>
              <div class="list-item-sub" style="margin-top:4px;">术${it.stats?.tao ?? 0} 魔${it.stats?.magic ?? 0}</div>
              <div class="list-item-actions">
                ${
                  equipped
                    ? `<button class="btn-secondary" data-action="unequip" data-item-id="${escapeAttr(it.id)}">卸下</button>`
                    : `<button class="btn-primary" data-action="equip" data-item-id="${escapeAttr(it.id)}">穿戴</button>`
                }
              </div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#view-bag").innerHTML = html;
  $$("#view-bag [data-action='book-use']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionUseSkillBook(btn.dataset.itemId);
    });
  });
  $$("#view-bag [data-action='equip']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionEquip(btn.dataset.itemId);
    });
  });
  $$("#view-bag [data-action='unequip']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionUnequip(btn.dataset.itemId);
    });
  });
  $("#btn-recycle-selected")?.addEventListener("click", async () => {
    const ids = $$("#view-bag [data-recycle-id]:checked").map((c) => c.dataset.recycleId);
    if (ids.length <= 0) return;
    await actionRecycle(ids);
  });
}

function renderShopView() {
  const items = state.shopItems ?? [];
  const html = `
    <div class="card-title">商店（药品购买后自动使用）</div>
    ${
      items.length
        ? `<div class="list">
      ${items
        .map((it) => {
          const isEquip = !!it.grantEquipSlot;
          const desc = isEquip
            ? `金币 ${it.priceGold} · 装备（${slotName(it.grantEquipSlot)} · ${it.grantRarity ?? "white"}）`
            : `金币 ${it.priceGold} · +HP ${it.healHp ?? 0} · +MP ${it.healMp ?? 0}`;
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(it.name)}</div>
              <div class="list-item-sub">${escapeHtml(desc)}</div>
              <div class="list-item-actions">
                <button class="btn-primary" data-action="shop-buy" data-item-id="${escapeAttr(it.id)}">购买</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>`
        : `<div class="muted">当前地图不可购买（请前往主城）</div>`
    }
  `;
  $("#view-shop").innerHTML = html;
  $$("#view-shop [data-action='shop-buy']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionShopBuy(btn.dataset.itemId);
    });
  });
}

function renderForgeView() {
  const slots = (state.equipSlots ?? []).map((id) => ({ id, name: slotName(id) }));
  const eq = state.player.equipped ?? {};
  const html = `
    <div class="card-title">强化</div>
    <div class="list">
      ${slots
        .map((s) => {
          const item = eq[s.id];
          if (!item) {
            return `
              <div class="list-item">
                <div class="list-item-title">${s.name}</div>
                <div class="list-item-sub">未穿戴装备</div>
              </div>
            `;
          }
          return `
            <div class="list-item">
              <div class="list-item-title">${escapeHtml(item.name)} +${item.strengthenLevel ?? 0}</div>
              <div class="list-item-sub">攻${item.stats?.atk ?? 0} 防${item.stats?.def ?? 0} 血${item.stats?.hpMax ?? 0} · 评分 ${item.score}</div>
              <div class="list-item-actions">
                <button class="btn-primary" data-action="strengthen" data-slot="${escapeAttr(s.id)}">强化 +1</button>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  $("#view-forge").innerHTML = html;
  $$("#view-forge [data-action='strengthen']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionStrengthen(btn.dataset.slot);
    });
  });
}

function renderLeftStatus() {
  const el = $("#left-status");
  if (!el) return;
  const p = state.player;
  const hpPct = Math.max(0, Math.min(100, Math.floor((p.hp / Math.max(1, p.hpMax)) * 100)));
  const mpPct = Math.max(0, Math.min(100, Math.floor((p.mp / Math.max(1, p.mpMax)) * 100)));
  const html = `
    <div class="card-title">状态</div>
    <div class="stat">
      <div class="stat-label">HP ${p.hp}/${p.hpMax}</div>
      <div class="statbar"><div style="width:${hpPct}%"></div></div>
    </div>
    <div class="stat" style="margin-top:8px;">
      <div class="stat-label">MP ${p.mp}/${p.mpMax}</div>
      <div class="statbar mp"><div style="width:${mpPct}%"></div></div>
    </div>
  `;
  el.innerHTML = html;
}
function renderBattleView() {
  const el = $("#battle");
  if (!el) return;
  const player = state.player;
  const runtime = state.runtime;
  const board = runtime?.board;
  const frame = runtime?.lastFrame;
  ensureBattleSkeleton(el);
  syncCellSize();

  const theme = state.currentMap?.themeColor ?? null;
  if (theme) {
    el.style.setProperty("--map-theme", theme);
  }
  const mapId = state.currentMap?.id ?? null;
  if (mapId && mapId !== lastBattleMapId) {
    triggerBattleRefresh();
    lastBattleMapId = mapId;
  }

  const mapName = state.currentMap?.name ?? "-";
  const power = calcPowerScore(player.atk, player.def, player.hpMax);
  const statusBadge = runtime?.isRunning ? "挂机中" : "已停止";

  const hudLeft = el.querySelector("#battle-hud-left");
  const hudRight = el.querySelector("#battle-hud-right");
  if (hudLeft) {
    hudLeft.innerHTML = `
      <span class="badge">地图：${escapeHtml(mapName)}</span>
      <span class="badge">状态：${statusBadge}</span>
      <span class="badge">坐标：${board ? `${board.player.x + 1},${board.player.y + 1}` : "-"}</span>
    `;
  }
  if (hudRight) {
    hudRight.innerHTML = `
      <span class="badge badge-power">战力：${power}</span>
      <span class="badge">金币：${player.gold}</span>
      <span class="badge">魔法：${player.mp}/${player.mpMax}</span>
    `;
  }

  const entitiesRoot = el.querySelector("#battle-entities");
  const layer = el.querySelector("#battle-layer");
  if (!entitiesRoot || !layer) return;

  if (!board) {
    entitiesRoot.innerHTML = "";
    return;
  }

  const moved = new Map();
  const attacks = [];
  const deads = [];
  const revives = [];
  const isNewFrame = frame?.id && frame.id !== lastFrameId;
  if (isNewFrame) {
    for (const ev of frame.events ?? []) {
      if (ev.type === "move") moved.set(ev.entityId, ev);
      if (ev.type === "attack") attacks.push(ev);
      if (ev.type === "dead") deads.push(ev);
      if (ev.type === "revive") revives.push(ev);
    }
    lastFrameId = frame.id;
  }

  const desired = new Map();
  desired.set("player", {
    kind: "player",
    id: "player",
    x: board.player.x,
    y: board.player.y,
    hp: player.hp,
    hpMax: player.hpMax,
    name: player.name,
    level: player.level,
    avatar: jobIcon(player.job),
    sub: jobName(player.job)
  });
  for (const m of board.monsters ?? []) {
    const tag = `${m.isElite ? "精" : ""}${m.isRanged ? "远" : ""}`;
    desired.set(m.id, {
      kind: "monster",
      id: m.id,
      x: m.x,
      y: m.y,
      hp: m.hp,
      hpMax: m.hpMax,
      name: m.name,
      level: m.level,
      avatar: monsterIcon(m.monsterId),
      tag
    });
  }

  const existing = new Map();
  Array.from(entitiesRoot.children).forEach((c) => {
    const id = c.dataset.entityId;
    if (id) existing.set(id, c);
  });

  for (const [id, ent] of desired) {
    let node = existing.get(id);
    if (!node) {
      node = document.createElement("div");
      node.dataset.entityId = id;
      node.className = `ent ${ent.kind === "player" ? "player" : "monster"}`;
      node.innerHTML = `
        <div class="ent-top">
          <span class="ent-lv">Lv.${escapeHtml(ent.level)}</span>
          <span class="ent-tag">${escapeHtml(ent.tag ?? "")}</span>
        </div>
        <div class="ent-avatar">${ent.avatar}</div>
        <div class="ent-name">${escapeHtml(ent.name)}</div>
        <div class="ent-sub">${escapeHtml(ent.sub ?? "")}</div>
        <div class="ent-hp"><div></div></div>
      `;
      entitiesRoot.appendChild(node);
    } else {
      const nameEl = node.querySelector(".ent-name");
      const subEl = node.querySelector(".ent-sub");
      const lvEl = node.querySelector(".ent-lv");
      const tagEl = node.querySelector(".ent-tag");
      const avatarEl = node.querySelector(".ent-avatar");
      if (nameEl) nameEl.textContent = ent.name;
      if (subEl) subEl.textContent = ent.sub ?? "";
      if (lvEl) lvEl.textContent = `Lv.${ent.level}`;
      if (tagEl) tagEl.textContent = ent.tag ?? "";
      if (avatarEl) avatarEl.textContent = ent.avatar;
    }
    const hpPct = Math.max(0, Math.min(100, Math.floor((ent.hp / Math.max(1, ent.hpMax)) * 100)));
    const hpFill = node.querySelector(".ent-hp > div");
    if (hpFill) hpFill.style.width = `${hpPct}%`;
  }

  for (const [id, node] of existing) {
    if (!desired.has(id)) node.remove();
  }

  const setPos = (id, pos, instant) => {
    const node = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(id)}"]`);
    if (!node) return;
    node.style.transition = instant ? "none" : "";
    node.style.left = `${pos.x * CELL}px`;
    node.style.top = `${pos.y * CELL}px`;
    if (instant) {
      node.getBoundingClientRect();
      node.style.transition = "";
    }
  };

  if (isNewFrame) {
    for (const [id, ent] of desired) {
      const mv = moved.get(id);
      if (mv) setPos(id, mv.from, true);
      else setPos(id, { x: ent.x, y: ent.y }, true);
    }
    requestAnimationFrame(() => {
      for (const [id, ent] of desired) {
        const mv = moved.get(id);
        if (mv) setPos(id, mv.to, false);
        else setPos(id, { x: ent.x, y: ent.y }, false);
      }
      for (const ev of attacks) animateAttack(entitiesRoot, layer, ev);
      for (const ev of deads) animateDead(entitiesRoot, ev.entityId);
      for (const ev of revives) animateRevive(entitiesRoot, ev.entityId);
    });
  } else {
    for (const [id, ent] of desired) setPos(id, { x: ent.x, y: ent.y }, false);
  }
}

function syncCellSize() {
  const board = document.querySelector(".battle-board");
  if (!board) return;
  const v = parseInt(getComputedStyle(board).getPropertyValue("--cell"));
  if (!Number.isNaN(v) && v > 0) CELL = v;
}
function triggerBattleRefresh() {
  const board = document.querySelector(".battle-board");
  if (!board) return;
  board.classList.add("refresh");
  setTimeout(() => board.classList.remove("refresh"), 480);
}

function renderAttrView() {
  const el = $("#view-attr");
  if (!el) return;
  const p = state.player;
  const map = state.currentMap;
  const expPct = p.expToNext > 0 ? Math.floor((p.exp / p.expToNext) * 100) : 0;
  const html = `
    <div class="card-title">角色属性</div>
    <div class="kv">
      <div class="k">名字</div><div class="v">${escapeHtml(p.name)}</div>
      <div class="k">职业</div><div class="v">${escapeHtml(jobName(p.job))}</div>
      <div class="k">等级</div><div class="v">Lv.${p.level}</div>
      <div class="k">经验</div><div class="v">${p.exp}/${p.expToNext}（${expPct}%）</div>
      <div class="k">生命</div><div class="v">${p.hp}/${p.hpMax}</div>
      <div class="k">魔法</div><div class="v">${p.mp}/${p.mpMax}</div>
      <div class="k">攻击</div><div class="v">${p.atk}</div>
      <div class="k">防御</div><div class="v">${p.def}</div>
      <div class="k">金币</div><div class="v">${p.gold}</div>
      <div class="k">当前地图</div><div class="v">${escapeHtml(map?.name ?? "-")}</div>
      <div class="k">推荐战力</div><div class="v">${map?.recommendPower ?? "-"}</div>
    </div>
  `;
  el.innerHTML = html;
}

function renderSkillsView() {
  const el = $("#view-skills");
  if (!el) return;
  const p = state.player;
  const defs = state.skillDefs ?? [];
  const levels = p.skills?.levels ?? {};
  const activeId = p.skills?.activeId ?? null;
  const findDef = (id) => defs.find((d) => d.id === id);
  const fmtLv = (id) => {
    const info = levels[id];
    if (!info) return "Lv.1";
    return `Lv.${info.level ?? 1}（熟练 ${info.exp ?? 0}）`;
  };
  const activeList = Array.from(new Set(p.skills?.activeIds ?? []));
  const passiveList = Array.from(new Set(p.skills?.passiveIds ?? []));
  const books = (p.inventory ?? []).filter((it) => it.type === "skill_book");
  const html = `
    <div class="card-title">技能</div>
    <div class="muted">当前主动：${escapeHtml(findDef(activeId)?.name ?? "普攻")}</div>
    <div class="list" style="margin-top:10px;">
      ${activeList.length
        ? activeList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              const isCur = id === activeId;
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}${isCur ? "（已选）" : ""}</div>
                  <div class="list-item-sub">${escapeHtml(d.style === "ranged" ? "远程" : "近战")} · MP ${d.mpCost ?? 0} · 距离 ${d.range ?? 1} · 学习等级 ${d.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-secondary" data-action="skill-set" data-skill-id="${escapeAttr(id)}" ${isCur ? "disabled" : ""}>设为主动</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习主动技能（当前使用普攻）</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">被动技能（自动生效，不消耗MP）</div>
    <div class="list" style="margin-top:8px;">
      ${passiveList.length
        ? passiveList
            .map((id) => {
              const d = findDef(id);
              if (!d) return "";
              return `
                <div class="list-item">
                  <div class="list-item-title">${escapeHtml(d.name)} ${escapeHtml(fmtLv(id))}</div>
                  <div class="list-item-sub">学习等级 ${d.learnLevel ?? 1}</div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">尚未学习被动技能</div>`}
    </div>
    <div class="muted" style="margin-top:10px;">技能书</div>
    <div class="list" style="margin-top:8px;">
      ${books.length
        ? books
            .map((b) => {
              return `
                <div class="list-item">
                  <div class="list-item-title">《${escapeHtml(b.skillName)}》</div>
                  <div class="list-item-sub">需求等级 ${b.learnLevel ?? 1}</div>
                  <div class="list-item-actions">
                    <button class="btn-primary" data-action="book-use" data-item-id="${escapeAttr(b.id)}">学习</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="muted">暂无技能书</div>`}
    </div>
  `;
  el.innerHTML = html;
  $$("#view-skills [data-action='skill-set']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionSetActiveSkill(btn.dataset.skillId);
    });
  });
  $$("#view-skills [data-action='book-use']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await actionUseSkillBook(btn.dataset.itemId);
    });
  });
}
function ensureBattleSkeleton(root) {
  if (root.dataset.inited === "1") return;
  const cells = Array.from({ length: 36 }, (_, i) => {
    const x = i % 6;
    const y = Math.floor(i / 6);
    return `<div class="battle-cell" data-x="${x}" data-y="${y}"></div>`;
  }).join("");
  root.innerHTML = `
    <div class="battle-hud">
      <div class="battle-hud-left" id="battle-hud-left"></div>
      <div class="battle-hud-right" id="battle-hud-right"></div>
    </div>
    <div class="battle-board">
      <div class="battle-grid">${cells}</div>
      <div class="battle-entities" id="battle-entities"></div>
      <div class="battle-layer" id="battle-layer"></div>
    </div>
  `;
  root.dataset.inited = "1";
}

function animateAttack(entitiesRoot, layer, ev) {
  const attackerId = ev.attackerId;
  const attackerEl = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(attackerId)}"]`);
  if (!attackerEl) return;
  const dx = (ev.to.x - ev.from.x) * CELL;
  const dy = (ev.to.y - ev.from.y) * CELL;

  try {
    if (ev.style === "ranged") {
      attackerEl.animate(
        [
          { transform: "translate3d(0,0,0)" },
          { transform: "translate3d(0,-10px,0)" },
          { transform: "translate3d(0,0,0)" }
        ],
        { duration: 240, easing: "cubic-bezier(.2,.8,.2,1)" }
      );
      spawnProjectile(layer, ev.from, ev.to);
    } else {
      attackerEl.animate(
        [
          { transform: "translate3d(0,0,0)" },
          { transform: "translate3d(0,-12px,0)" },
          { transform: `translate3d(${dx}px,${dy - 12}px,0)` },
          { transform: `translate3d(${dx}px,${dy}px,0)` },
          { transform: "translate3d(0,0,0)" }
        ],
        { duration: 360, easing: "cubic-bezier(.2,.8,.2,1)" }
      );
      spawnSlash(layer, ev.to);
    }
  } catch {}

  const fx = ev.to.x * CELL + CELL / 2;
  const fy = ev.to.y * CELL + 18;
  const type = ev.targetId === "player" ? "monster" : "player";
  spawnFloat(layer, type, `-${ev.damage}`, fx, fy);
}

function spawnSlash(layer, pos) {
  const el = document.createElement("div");
  el.className = "slash";
  el.style.left = `${pos.x * CELL + CELL / 2}px`;
  el.style.top = `${pos.y * CELL + 18}px`;
  layer.appendChild(el);
  setTimeout(() => el.remove(), 260);
}

function spawnProjectile(layer, from, to) {
  const el = document.createElement("div");
  el.className = "projectile";
  const sx = from.x * CELL + CELL / 2;
  const sy = from.y * CELL + 18;
  const tx = to.x * CELL + CELL / 2;
  const ty = to.y * CELL + 18;
  el.style.left = `${sx}px`;
  el.style.top = `${sy}px`;
  layer.appendChild(el);
  try {
    el.animate([{ transform: "translate3d(0,0,0)" }, { transform: `translate3d(${tx - sx}px,${ty - sy}px,0)` }], {
      duration: 260,
      easing: "cubic-bezier(.2,.8,.2,1)"
    });
  } catch {}
  setTimeout(() => el.remove(), 300);
}
function animateDead(entitiesRoot, entityId) {
  const el = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(entityId)}"]`);
  if (!el) return;
  try {
    el.animate([{ opacity: 1, transform: "scale(1)" }, { opacity: 0, transform: "scale(0.9)" }], { duration: 240, easing: "ease-out" });
  } catch {}
  setTimeout(() => el.remove(), 260);
}

function animateRevive(entitiesRoot, entityId) {
  const el = entitiesRoot.querySelector(`[data-entity-id="${CSS.escape(entityId)}"]`);
  if (!el) return;
  try {
    el.animate(
      [
        { boxShadow: "0 0 0 rgba(16,185,129,0)" },
        { boxShadow: "0 0 18px rgba(16,185,129,0.45)" },
        { boxShadow: "0 0 0 rgba(16,185,129,0)" }
      ],
      { duration: 520, easing: "ease-out" }
    );
  } catch {}
}

function spawnFloat(layer, type, text, x, y) {
  const div = document.createElement("div");
  div.className = `float-dmg ${type}`;
  div.textContent = text;
  div.style.left = `${x}px`;
  div.style.top = `${y}px`;
  layer.appendChild(div);
  setTimeout(() => div.remove(), 900);
}

function renderRightLogs() {
  const logs = state?.logs ?? [];
  const filteredRaw = logs.filter((l) => l.ts >= displayLogClearedAt);
  const filtered =
    logFilter === "loot"
      ? filteredRaw.filter((l) => l.type === "loot")
      : filteredRaw.filter((l) => {
          if (l.type !== "battle") return true;
          const t = String(l.text ?? "");
          return t.includes("复活") || t.includes("被击败");
        });
  const el = $("#card-hints");
  if (!el) return;
  const latest = filtered.slice(-50); // 保留最近50条，按时间正序显示
  const content = latest
    .map((l) => {
      return `<div class="log-item ${escapeAttr(l.type)}"><span class="meta">${fmtTime(l.ts)} · ${escapeHtml(l.type)}</span>${escapeHtml(l.text)}</div>`;
    })
    .join("");
  const html = `
    <div class="card-title">提示</div>
    <div class="list hints-scroll">
      ${content || `<div class="muted">暂无日志</div>`}
    </div>
  `;
  el.innerHTML = html;
  const sc = el.querySelector(".hints-scroll");
  if (sc) {
    try {
      sc.scrollTop = sc.scrollHeight; // 滚动到底部
    } catch {}
  }
}

function slotName(slot) {
  const names = state?.equipSlotNames ?? null;
  if (names && names[slot]) return names[slot];
  return slot;
}

async function refreshState() {
  try {
    state = await api("/api/state");
    showAuthModal(false);
    render();
  } catch (err) {
    const msg = String(err?.message ?? err);
    if (msg.includes("未登录")) {
      showAuthModal(true);
      return;
    }
    console.error(err);
  }
}

async function actionCreatePlayer() {
  const name = $("#create-name").value;
  const job = $("#create-job").value;
  $("#create-hint").textContent = "";
  try {
    state = await api("/api/player/create", { method: "POST", body: { name, job } });
    state = await api("/api/game/start", { method: "POST" });
    render();
    maybeStartTickLoop();
  } catch (err) {
    $("#create-hint").textContent = err?.message ?? String(err);
  }
}

async function actionResume() {
  try {
    state = await api("/api/game/start", { method: "POST" });
    render();
    maybeStartTickLoop();
    showCreateModal(false);
  } catch (err) {
    $("#create-hint").textContent = err?.message ?? String(err);
  }
}

async function actionStart() {
  if (!state?.runtime?.isRunning) {
    state = await api("/api/game/start", { method: "POST" });
  } else {
    state = await api("/api/game/stop", { method: "POST" });
  }
  render();
  maybeStartTickLoop();
}

async function actionStop() {
  state = await api("/api/game/stop", { method: "POST" });
  render();
}

async function actionTick() {
  const data = await api("/api/game/tick", { method: "POST", body: { count: 1 } });
  state = data.state;
  render();
}

async function actionSetMap(mapId) {
  state = await api("/api/map/set", { method: "POST", body: { mapId } });
  render();
}

async function actionEquip(itemId) {
  state = await api("/api/equip/equip", { method: "POST", body: { itemId } });
  render();
}

async function actionUnequip(itemId) {
  state = await api("/api/equip/unequip", { method: "POST", body: { itemId } });
  render();
}

async function actionRecycle(itemIds) {
  const data = await api("/api/inventory/recycle", { method: "POST", body: { itemIds } });
  state = data.state;
  render();
}

async function actionStrengthen(slot) {
  const data = await api("/api/forge/strengthen", { method: "POST", body: { slot } });
  state = data.state;
  render();
}

async function actionAutoEquipToggle(enabled) {
  state = await api("/api/settings/auto-equip", { method: "POST", body: { enabled } });
  render();
}

async function actionAutoRecycleToggle(enabled) {
  state = await api("/api/settings/auto-recycle", { method: "POST", body: { enabled } });
  render();
}

async function actionRecycleThresholdUpdate(threshold) {
  state = await api("/api/settings/recycle-threshold", { method: "POST", body: { threshold } });
  render();
}

async function actionAutoDrinkUpdate(hpPct, mpPct) {
  state = await api("/api/settings/auto-drink", { method: "POST", body: { hpPct, mpPct } });
  render();
}

async function actionUseSkillBook(itemId) {
  state = await api("/api/skills/use-book", { method: "POST", body: { itemId } });
  render();
}

async function actionSetActiveSkill(skillId) {
  state = await api("/api/skills/set-active", { method: "POST", body: { skillId } });
  render();
}

async function actionShopBuy(itemId) {
  state = await api("/api/shop/buy", { method: "POST", body: { itemId } });
  render();
}

function maybeStartTickLoop() {
  if (ticking) return;
  if (!state?.runtime?.isRunning) return;
  ticking = true;
  const loop = async () => {
    if (!state?.runtime?.isRunning) {
      ticking = false;
      return;
    }
    try {
      await actionTick();
    } catch (err) {
      console.error(err);
      ticking = false;
      return;
    }
    setTimeout(loop, 1500);
  };
  setTimeout(loop, 200);
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttr(s) {
  return escapeHtml(s).replaceAll(" ", "_");
}

function bindEvents() {
  $$(".nav-btn").forEach((b) => {
    b.addEventListener("click", () => setActiveTab(b.dataset.tab));
  });
  $$(".chip").forEach((b) => {
    b.addEventListener("click", () => setActiveLogFilter(b.dataset.log));
  });
  $("#btn-clear-log").addEventListener("click", () => {
    displayLogClearedAt = Date.now();
    renderRightLogs();
  });
  $("#btn-resume")?.addEventListener("click", actionResume);
  $("#btn-create").addEventListener("click", actionCreatePlayer);
  $("#btn-cancel-create")?.addEventListener("click", () => {
    showCreateModal(false);
    $("#create-hint").textContent = "已取消创建";
  });
  $("#btn-start").addEventListener("click", actionStart);
  $("#btn-stop").addEventListener("click", actionStop);
  $("#btn-reset-player").addEventListener("click", async () => {
    state = await api("/api/player/reset", { method: "POST" });
    render();
  });
  $("#setting-auto-equip")?.addEventListener("change", async (e) => {
    await actionAutoEquipToggle(e.target.checked);
  });
  $("#setting-auto-recycle")?.addEventListener("change", async (e) => {
    await actionAutoRecycleToggle(e.target.checked);
  });
  $("#setting-recycle-threshold")?.addEventListener("change", async (e) => {
    await actionRecycleThresholdUpdate(e.target.value);
  });
  const syncAutoDrink = async () => {
    const hpPct = Number($("#setting-auto-hp")?.value ?? 0);
    const mpPct = Number($("#setting-auto-mp")?.value ?? 0);
    await actionAutoDrinkUpdate(hpPct, mpPct);
  };
  $("#setting-auto-hp")?.addEventListener("change", syncAutoDrink);
  $("#setting-auto-mp")?.addEventListener("change", syncAutoDrink);
  $("#btn-login").addEventListener("click", async () => {
    const username = $("#auth-username").value.trim();
    const password = $("#auth-password").value.trim();
    const remember = $("#auth-remember").checked;
    try {
      const data = await api("/api/auth/login", { method: "POST", body: { username, password } });
      if (remember) {
        localStorage.setItem("authToken", data.token);
        sessionStorage.removeItem("authToken");
      } else {
        sessionStorage.setItem("authToken", data.token);
        localStorage.removeItem("authToken");
      }
      $("#auth-hint").textContent = "";
      $("#modal-auth").classList.add("hidden");
      await refreshState();
      maybeStartTickLoop();
    } catch (err) {
      $("#auth-hint").textContent = err?.message ?? String(err);
    }
  });
  $("#btn-register").addEventListener("click", async () => {
    const username = $("#auth-username").value.trim();
    const password = $("#auth-password").value.trim();
    const remember = $("#auth-remember").checked;
    try {
      const data = await api("/api/auth/register", { method: "POST", body: { username, password } });
      if (remember) {
        localStorage.setItem("authToken", data.token);
        sessionStorage.removeItem("authToken");
      } else {
        sessionStorage.setItem("authToken", data.token);
        localStorage.removeItem("authToken");
      }
      $("#auth-hint").textContent = "";
      $("#modal-auth").classList.add("hidden");
      await refreshState();
    } catch (err) {
      $("#auth-hint").textContent = err?.message ?? String(err);
    }
  });
}

bindEvents();
setActiveTab("map");
setActiveLogFilter("all");
refreshState().then(() => maybeStartTickLoop());

function renderStartStopUI() {
  const running = !!state?.runtime?.isRunning;
  const btn = $("#btn-start");
  if (!btn) return;
  btn.textContent = running ? "停止挂机" : "开始挂机";
  btn.classList.toggle("btn-danger", running);
}
